#include <deal.II/base/quadrature_lib.h>
#include <deal.II/base/function.h>

#include <deal.II/lac/solver_cg.h>
#include <deal.II/lac/solver_gmres.h>
#include <deal.II/lac/solver_minres.h>
#include <deal.II/lac/constraint_matrix.h>
#include <deal.II/lac/block_sparsity_pattern.h>
#include <deal.II/lac/trilinos_block_vector.h>
#include <deal.II/lac/trilinos_sparse_matrix.h>
#include <deal.II/lac/trilinos_block_sparse_matrix.h>
/*For PreconditionAMG */
#include <deal.II/lac/trilinos_precondition.h>
/*For PreconditionIdentity*/
#include <deal.II/lac/precondition.h>

#include <deal.II/grid/tria.h>
#include <deal.II/grid/grid_generator.h>
#include <deal.II/grid/tria_accessor.h>
#include <deal.II/grid/tria_iterator.h>

#include <deal.II/dofs/dof_handler.h>
#include <deal.II/dofs/dof_renumbering.h>
#include <deal.II/dofs/dof_accessor.h>
#include <deal.II/dofs/dof_tools.h>

#include <deal.II/fe/fe_q.h>
#include <deal.II/fe/fe_system.h>
#include <deal.II/fe/fe_values.h>

/*Vector and Matrix tools */
#include <deal.II/numerics/vector_tools.h>
#include <deal.II/numerics/matrix_tools.h>


#include <fstream>
#include <iostream>
#include <string>
#include <deal.II/numerics/data_out.h>
#include <deal.II/lac/lapack_full_matrix.h>


/*for iterative inverse*/
#include <deal.II/lac/iterative_inverse.h>

/* For convergence table out put */
#include <deal.II/base/table_handler.h>

/* The timer class header */
#include <deal.II/base/timer.h>
#include "../solver_impl.hh"
#include "../data.hh"
#include "../MiscUtilities.hh"

#include <deal.II/base/std_cxx1x/thread.h>



using namespace dealii;



namespace EquationData
{

  double beta;
}




  /*End of Inverse Matrix */

    template <class PreconditionerA, class PreconditionerB>
    class BlockPreconditioner : public Subscriptor
    {
      public:
        BlockPreconditioner (const TrilinosWrappers::BlockSparseMatrix  &S,
                             const LinearSolvers::InverseMatrix<TrilinosWrappers::SparseMatrix, PreconditionerB> &preconditioner_inv,
                             const LinearSolvers::InverseMatrix<TrilinosWrappers::SparseMatrix, PreconditionerA> &amg_inv
                             );

        void vmult (TrilinosWrappers::BlockVector &dst,
                    const TrilinosWrappers::BlockVector &src) const;

        void implement_P5withS1orS2(TrilinosWrappers::BlockVector &dst,
                               const TrilinosWrappers::BlockVector &src) const;
        void implement_P7withS1orS2(TrilinosWrappers::BlockVector &dst,
                               const TrilinosWrappers::BlockVector &src) const;

      private:
        const SmartPointer<const TrilinosWrappers::BlockSparseMatrix> preconditioner_matrix;
        const SmartPointer<const LinearSolvers::InverseMatrix<TrilinosWrappers::SparseMatrix, PreconditionerB> > m_inv;
        const SmartPointer<const LinearSolvers::InverseMatrix<TrilinosWrappers::SparseMatrix, PreconditionerA> > amg;
        const unsigned int n_t;

        mutable TrilinosWrappers::Vector y, u, p;
        mutable TrilinosWrappers::Vector g1, g2, g3;

    };

    template <class PreconditionerA, class PreconditionerB>
    BlockPreconditioner<PreconditionerA, PreconditionerB>::
    BlockPreconditioner(const TrilinosWrappers::BlockSparseMatrix  &S,
                        const LinearSolvers::InverseMatrix<TrilinosWrappers::SparseMatrix, PreconditionerB> &_m_inv,
                        const LinearSolvers::InverseMatrix<TrilinosWrappers::SparseMatrix, PreconditionerA> &_amg)
                    :
                    preconditioner_matrix   (&S),
                    m_inv                   (&_m_inv),
                    amg                     (&_amg),
                    g1                      (preconditioner_matrix->block(0,0).m()),
                    g2                      (preconditioner_matrix->block(0,0).m()),
                    g3                      (preconditioner_matrix->block(0,0).m()),
                    y                       (preconditioner_matrix->block(0,0).m()),
                    u                       (preconditioner_matrix->block(0,0).m()),
                    p                       (preconditioner_matrix->block(0,0).m()),
                    n_t                     (preconditioner_matrix->block(0,0).m())
 {}


    template <class PreconditionerA, class PreconditionerB>
    void BlockPreconditioner<PreconditionerA, PreconditionerB >::vmult (
      TrilinosWrappers::BlockVector &dst,
      const TrilinosWrappers::BlockVector &src) const
    {


          if(Poisson::p_type==Poisson::PreconditionerType::BD_SCHUR_BASED)
             implement_P5withS1orS2(dst, src);

          if(Poisson::p_type==Poisson::PreconditionerType::BLT_SCHUR_BASED)
             implement_P7withS1orS2(dst, src);


    }


    //preconditioner P5=[M_hat       0       0]
    //                     0     BM_hat      0
    //                     0         0    S_hat]   S_hat=K M^-1 K

    template <class PreconditionerA, class PreconditionerB>
    void BlockPreconditioner<PreconditionerA, PreconditionerB >::implement_P5withS1orS2(
                                                                                    TrilinosWrappers::BlockVector &dst,
                                                                                    const TrilinosWrappers::BlockVector &src) const
    {
            y = 0;
            u = 0;
            p = 0;

            g1=0;
            g2=0;



            m_inv->vmult(y, src.block(0));
            m_inv->vmult(u, src.block(1));
            u *= 1.0/EquationData::beta;

            amg->vmult(g1,src.block(2));

            //g2=M*g1
            preconditioner_matrix->block(0,0).vmult (g2, g1);

            amg->vmult(p, g2);

            dst.block(0) = y;
            dst.block(1) = u;
            dst.block(2) = p;
        }

        //preconditioner P5=[M_hat       0        0]
        //                     0     BM_hat       0
        //                     K        -M   -S_hat]   S_hat=K M^-1 K or  S_hat = (K+1/sqrt(B)*M) M^-1 (K+1/sqrt(B)*M)
        template <class PreconditionerA, class PreconditionerB>
        void BlockPreconditioner<PreconditionerA, PreconditionerB >::implement_P7withS1orS2(
                                                                                        TrilinosWrappers::BlockVector &dst,
                                                                                        const TrilinosWrappers::BlockVector &src) const
        {
            y = 0;
            u = 0;
            p = 0;


            m_inv->vmult(y, src.block(0));
            m_inv->vmult(u, src.block(1));

            /*for (unsigned int i=0; i<n_t;i++){
                y[i] =src.block(0)[i]/preconditioner_matrix->block(0, 0).diag_element(i);
                u[i] =src.block(1)[i]/preconditioner_matrix->block(0, 0).diag_element(i);

            }*/
            u *= 1.0/EquationData::beta;

            //calculate p

            //K*p
            preconditioner_matrix->block(2,0).vmult(g1, y);
            //-M*u
            preconditioner_matrix->block(2,1).vmult(g2, u);

            g3 =src.block(2);
            //invert the sign of the last equation such that Ky - Mu -S_hat p  =d -->-Ky + Mu + S_hat p =-d  to make S_hat +ve          

            //Add Ky
            g3 -= g1;
            //add Mu
            g3 -= g2;

            g1 =0;
            g2 =0;

            amg->vmult(g2,g3);
            //g1=M*g2
            preconditioner_matrix->block(0,0).vmult (g1, g2);
            amg->vmult(p, g1);

            p *=-1;
            dst.block(0) = y;
            dst.block(1) = u;
            dst.block(2) = p;
        }



/*The main class*/
template <int dim>
class PoissonControl
{
  public:
    PoissonControl (const unsigned int degree);
    void  init_parameters();
    void run ();

  private:
    void make_grid_and_dofs (const double n_refinement_steps);
    void assemble_constant_matrix_equation();
    void assemble_constant_matrix ();
    void solve();
    void compute_errors ();
    void output_results() const;
    void set_labels();
    void print_tables();
    void push_table_data(unsigned int iterations, double time);


    void initialize_preconditioner();
    void process_solution(TableHandler &table, double l_infinity, unsigned int iterations, double tolerance, double time);


    dealii::Triangulation<dim>   triangulation;

    FESystem<dim>     system_fe;
    DoFHandler<dim>   system_dof_handler;
    DoFHandler<dim>   dof_handler;

    TrilinosWrappers::BlockSparsityPattern sparsity_pattern;
    TrilinosWrappers::BlockSparsityPattern pre_sparsity_pattern;

    double h;
    double n_refs;

    TrilinosWrappers::BlockSparseMatrix system_matrix;
    TrilinosWrappers::BlockSparseMatrix preconditioner_matrix;
    ConstraintMatrix  matrix_constraints;
    ConstraintMatrix  preconditioner_constraints;

    std::vector<types::global_dof_index> system_block_sizes;

    TrilinosWrappers::BlockVector solution;
    TrilinosWrappers::BlockVector system_rhs;
    TrilinosWrappers::BlockVector zero_vector;
    double u_l2_norm;
    double y_yd_l2_norm;
    double rel_y_yd_l2_norm;
    double cost_functional_J;
    unsigned int n_y;
    unsigned int n_u;
    unsigned int n_p;


    const unsigned int degree;

    std::vector< MiscUtilities::TableData> table_data_list;

    std_cxx1x::shared_ptr<TrilinosWrappers::PreconditionAMG>  Amg_preconditioner;
    std_cxx1x::shared_ptr<TrilinosWrappers::PreconditionChebyshev> IC_preconditioner;


    TableHandler table_1;
    std::string tex_table_caption;
    std::string tex_file_name;
    std::string text_table_file_name;
    std::string vtk_tile_name;


    std::vector<double> beta_values;
    std::vector<int> refinements;
    std::vector<double> inner_tolerance;
    Timer timer;
    Timer total_time;
    SolverType s;

};

 template <int dim>
 PoissonControl<dim>::PoissonControl(const unsigned int degree)
        :
        degree(degree),
        triangulation (Triangulation<dim>::none),
        system_fe(FE_Q<dim>(degree),3),
        system_dof_handler(triangulation),
        dof_handler(triangulation)

 {

 }

 /////////////////////make_grid_and_dofs////////////////////////////////
template <int dim>
 void PoissonControl<dim>::make_grid_and_dofs (const double n_refinement_steps)
 {

        if(Poisson::solve_problem_type==Poisson::Problem_Type::HEAT_FLOW_1 || Poisson::solve_problem_type==Poisson::Problem_Type::HEAT_FLOW_2){
           GridGenerator::hyper_cube (triangulation, 0, 1);

           triangulation.refine_global (n_refinement_steps);


           //Set boundary indicator
           for (typename Triangulation<dim>::active_cell_iterator
            cell = triangulation.begin_active();
            cell != triangulation.end(); ++cell)
            for (unsigned int f=0; f<GeometryInfo<dim>::faces_per_cell; ++f)

                    if ((cell->face(f)->center()(0) <= 0.5 && cell->face(f)->center()(1)==0.0) ||
                        (cell->face(f)->center()(1) <= 0.5 && cell->face(f)->center()(0)==0.0)
                        )
                         cell->face(f)->set_boundary_indicator(1);
        }


system_dof_handler.distribute_dofs (system_fe);
   std::vector<unsigned int> pde_sub_blocks (3,0);
   pde_sub_blocks[0]=0;
   pde_sub_blocks[1]=1;
   pde_sub_blocks[2]=2;

   DoFRenumbering::component_wise (system_dof_handler, pde_sub_blocks);
   cout<<"Sub Blocks ititialized "<<endl;
   cout<<"Done till here ... "<<endl;
   /*The next thing is that we want to figure out the sizes of these blocks,
    so that we can allocate an appropriate amount of space. */
   std::vector<types::global_dof_index> dofs_per_component (3);
   DoFTools::count_dofs_per_component (system_dof_handler, dofs_per_component);
   n_y = dofs_per_component[0];
   n_u = dofs_per_component[1];
   n_p = dofs_per_component[2];

   cout << "Number of active cells: "
             << triangulation.n_active_cells()
             << std::endl
             << "Number of degrees of freedom y: "
             << n_y
             << std::endl
             << "Number of degrees of freedom u: "
             << n_u
             << std::endl
             << "Number of degrees of freedom p: "
            << n_p
            << std::endl
            << "Total degrees: "
            << (n_y+n_u+n_p)
            << std::endl;

   system_block_sizes.resize (3);
   system_block_sizes[0] = n_y;
   system_block_sizes[1] = n_u;
   system_block_sizes[2] = n_p;

   /*Apply Dirichelet to the whole matrix*/
   matrix_constraints.clear ();
   const FEValuesExtractors::Scalar component_y(0);
   const FEValuesExtractors::Scalar component_u(1);
   const FEValuesExtractors::Scalar component_p(2);

   VectorTools::interpolate_boundary_values (system_dof_handler,0, ZeroFunction<dim>(3),  matrix_constraints, system_fe.component_mask(component_y));
   VectorTools::interpolate_boundary_values (system_dof_handler,0, ZeroFunction<dim>(3),  matrix_constraints, system_fe.component_mask(component_u));
   VectorTools::interpolate_boundary_values (system_dof_handler,0, ZeroFunction<dim>(3),  matrix_constraints, system_fe.component_mask(component_p));

   VectorTools::interpolate_boundary_values (system_dof_handler,1, Poisson::BoundaryValues<dim>(3), matrix_constraints, system_fe.component_mask(component_y)); 
   VectorTools::interpolate_boundary_values (system_dof_handler,1, ZeroFunction<dim>(3),  matrix_constraints, system_fe.component_mask(component_u));
   VectorTools::interpolate_boundary_values (system_dof_handler,1, ZeroFunction<dim>(3),  matrix_constraints, system_fe.component_mask(component_p));
   //VectorTools::interpolate_boundary_values (system_dof_handler,0, ZeroFunction<dim>(3), matrix_constraints);
   matrix_constraints.close ();

   preconditioner_constraints.clear ();

   VectorTools::interpolate_boundary_values (system_dof_handler,0, ZeroFunction<dim>(3),  preconditioner_constraints,  system_fe.component_mask(component_y));
   VectorTools::interpolate_boundary_values (system_dof_handler,0, ZeroFunction<dim>(3),  preconditioner_constraints, system_fe.component_mask(component_u));
   VectorTools::interpolate_boundary_values (system_dof_handler,0, ZeroFunction<dim>(3),  preconditioner_constraints, system_fe.component_mask(component_p));

   VectorTools::interpolate_boundary_values (system_dof_handler,1, Poisson::BoundaryValues<dim>(3),  preconditioner_constraints, system_fe.component_mask(component_y));
   VectorTools::interpolate_boundary_values (system_dof_handler,1, ZeroFunction<dim>(3),  preconditioner_constraints, system_fe.component_mask(component_u));
   VectorTools::interpolate_boundary_values (system_dof_handler,1, ZeroFunction<dim>(3),  preconditioner_constraints, system_fe.component_mask(component_p));

   //VectorTools::interpolate_boundary_values (system_dof_handler,0, ZeroFunction<dim>(3),  preconditioner_constraints);

   preconditioner_constraints.close ();
   cout<<"Dirichlet condition applied "<<endl;

   /*Sparsity Pattern for the System Matrix */
   {
   system_matrix.clear ();
   sparsity_pattern.reinit (3,3);
   const unsigned int n_couplings = system_dof_handler.max_couplings_between_dofs();
   sparsity_pattern.block(0,0).reinit (n_y, n_y, n_couplings);
   sparsity_pattern.block(1,0).reinit (n_u, n_y, n_couplings);
   sparsity_pattern.block(2,0).reinit (n_p, n_y, n_couplings);
   sparsity_pattern.block(0,1).reinit (n_y, n_u, n_couplings);
   sparsity_pattern.block(1,1).reinit (n_u, n_u, n_couplings);
   sparsity_pattern.block(2,1).reinit (n_p, n_u, n_couplings);
   sparsity_pattern.block(0,2).reinit (n_y, n_p, n_couplings);
   sparsity_pattern.block(1,2).reinit (n_u, n_p, n_couplings);
   sparsity_pattern.block(2,2).reinit (n_p, n_p, n_couplings);
   sparsity_pattern.collect_sizes();  //what is this for? yes, needed when we touch each block separately!,

   DoFTools::make_sparsity_pattern (system_dof_handler,
                     sparsity_pattern,
                     matrix_constraints,
                     false);


    sparsity_pattern.compress();
    system_matrix.reinit (sparsity_pattern);

}

   /*Sparsity Pattern for the System Matrix */
   {
   preconditioner_matrix.clear ();
   pre_sparsity_pattern.reinit (3,3);
   const unsigned int n_couplings = system_dof_handler.max_couplings_between_dofs();
   pre_sparsity_pattern.block(0,0).reinit (n_y, n_y, n_couplings);
   pre_sparsity_pattern.block(1,0).reinit (n_u, n_y, n_couplings);
   pre_sparsity_pattern.block(2,0).reinit (n_p, n_y, n_couplings);
   pre_sparsity_pattern.block(0,1).reinit (n_y, n_u, n_couplings);
   pre_sparsity_pattern.block(1,1).reinit (n_u, n_u, n_couplings);
   pre_sparsity_pattern.block(2,1).reinit (n_p, n_u, n_couplings);
   pre_sparsity_pattern.block(0,2).reinit (n_y, n_p, n_couplings);
   pre_sparsity_pattern.block(1,2).reinit (n_u, n_p, n_couplings);
   pre_sparsity_pattern.block(2,2).reinit (n_p, n_p, n_couplings);
   pre_sparsity_pattern.collect_sizes();  //what is this for? yes, needed when we touch each block separately!,

   DoFTools::make_sparsity_pattern (system_dof_handler,
                     pre_sparsity_pattern,
                     preconditioner_constraints,
                     false);


    pre_sparsity_pattern.compress();
    preconditioner_matrix.reinit(pre_sparsity_pattern);
}

   solution.reinit (3);
   solution.block(0).reinit (n_y);
   solution.block(1).reinit (n_u);
   solution.block(2).reinit (n_p);
   solution.collect_sizes ();

   system_rhs.reinit (3);
   system_rhs.block(0).reinit (n_y);
   system_rhs.block(1).reinit (n_u);
   system_rhs.block(2).reinit (n_p);
   system_rhs.collect_sizes ();

   zero_vector.reinit (3);
   zero_vector.block(0).reinit (n_y);
   zero_vector.block(1).reinit (n_u);
   zero_vector.block(2).reinit (n_p);
   zero_vector.collect_sizes ();
   zero_vector=0;


 }

 /////////////////////assemble_constant_matrix(K,M)///////////////
 template <int dim>
 void PoissonControl<dim>::assemble_constant_matrix_equation ()
 {

     system_matrix = 0;

     preconditioner_matrix = 0;

     system_rhs = 0;


     const FEValuesExtractors::Scalar component_y(0);
     const FEValuesExtractors::Scalar component_u(1);
     const FEValuesExtractors::Scalar component_p(2);


     const unsigned int   dofs_per_cell   = system_fe.dofs_per_cell;
     FullMatrix<double>   local_00_matrix(dofs_per_cell, dofs_per_cell),
                          local_11_matrix(dofs_per_cell, dofs_per_cell),
                          local_02_matrix(dofs_per_cell, dofs_per_cell),
                          local_20_matrix(dofs_per_cell, dofs_per_cell),
                          local_12_matrix(dofs_per_cell, dofs_per_cell),
                          local_21_matrix(dofs_per_cell, dofs_per_cell),
                          local_matrix(dofs_per_cell, dofs_per_cell),
                          local_pre_matrix(dofs_per_cell, dofs_per_cell),
                          local_22_matrix(dofs_per_cell, dofs_per_cell);

    Vector<double>         local_rhs (dofs_per_cell);

    QGauss<dim>   quadrature_formula (degree+2);
    FEValues<dim> fe_values (system_fe, quadrature_formula,
                                        update_values    | update_gradients | update_quadrature_points |
                                        update_JxW_values);

   const unsigned int   n_q_points      = quadrature_formula.size();

   std::vector<unsigned int> local_dof_indices (dofs_per_cell);


   double component_0_phi_i(dofs_per_cell),
          component_1_phi_i(dofs_per_cell),
          component_2_phi_i(dofs_per_cell),
          component_0_phi_j(dofs_per_cell),
          component_1_phi_j(dofs_per_cell),
          component_2_phi_j(dofs_per_cell);


   Tensor<1,dim>    component_0_grad_phi_i  (dofs_per_cell),
                    component_1_grad_phi_i  (dofs_per_cell),
                    component_2_grad_phi_i  (dofs_per_cell),
                    component_0_grad_phi_j  (dofs_per_cell),
                    component_1_grad_phi_j  (dofs_per_cell),
                    component_2_grad_phi_j  (dofs_per_cell);

   const Poisson::ControlValues<dim> poisson_control_values(2);
   std::vector<double> control_values (n_q_points);

   cout<<"n_q_points "<<n_q_points<<endl;

   typename DoFHandler<dim>::active_cell_iterator
   cell = system_dof_handler.begin_active(),
   endc = system_dof_handler.end();

   for (; cell!=endc; ++cell)
     {
       /*Reinitialize the cell */
       fe_values.reinit (cell);

       std::vector<Point<dim>> p_list=fe_values.get_quadrature_points();
       poisson_control_values.value_list (p_list, control_values);


       local_00_matrix  = 0;
       local_11_matrix  = 0;
       local_02_matrix  = 0;
       local_20_matrix  = 0;
       local_12_matrix  = 0;
       local_21_matrix  = 0;

       local_22_matrix  = 0;
       local_pre_matrix = 0;

       local_matrix     = 0;

       local_rhs=0;

       for (unsigned int q=0; q<n_q_points; ++q){

           /*creating the matrix
             A=[M  0  K
                0 BM -M
                K -M  0
                where M is mass and K is stiffnexx matrix
               */

           for (unsigned int i=0; i<dofs_per_cell; ++i){

               component_0_phi_i      = fe_values[component_y].value (i, q);
               component_1_phi_i      = fe_values[component_u].value (i, q);
               component_2_phi_i      = fe_values[component_p].value (i, q);

               component_0_grad_phi_i = fe_values[component_y].gradient(i,q);
               component_1_grad_phi_i = fe_values[component_u].gradient(i,q);
               component_2_grad_phi_i = fe_values[component_p].gradient(i,q);


             for (unsigned int j=0; j<dofs_per_cell; ++j)
               {
                 component_0_phi_j      = fe_values[component_y].value (j, q);
                 component_1_phi_j      = fe_values[component_u].value (j, q);
                 component_2_phi_j      = fe_values[component_p].value (j, q);


                 component_0_grad_phi_j = fe_values[component_y].gradient(j,q);
                 component_1_grad_phi_j = fe_values[component_u].gradient(j,q);
                 component_2_grad_phi_j = fe_values[component_p].gradient(j,q);



                 local_00_matrix(i, j) =(component_0_phi_i * component_0_phi_j)*fe_values.JxW(q);
                 local_02_matrix(i, j) =(component_0_grad_phi_i * component_2_grad_phi_j)*fe_values.JxW(q);

                 local_11_matrix(i, j) =EquationData::beta*(component_1_phi_i * component_1_phi_j)*fe_values.JxW(q);
                 local_12_matrix(i, j) =-(component_1_phi_i * component_2_phi_j)*fe_values.JxW(q);
                 local_20_matrix(i, j) =(component_2_grad_phi_i * component_0_grad_phi_j)*fe_values.JxW(q);
                 local_21_matrix(i, j) =-(component_2_phi_i * component_1_phi_j)*fe_values.JxW(q);

                 local_22_matrix(i, j) =((component_2_grad_phi_i * component_2_grad_phi_j)+
                                         1.0/sqrt(EquationData::beta)*(component_2_phi_i*component_2_phi_j))
                                         *fe_values.JxW(q);

                 local_matrix(i,j) += local_00_matrix(i, j)+local_02_matrix(i, j)+
                                      local_11_matrix(i, j)+local_12_matrix(i, j)+
                                      local_20_matrix(i, j)+local_21_matrix(i, j);

                 local_pre_matrix(i,j) += local_00_matrix(i, j)+
                                          local_11_matrix(i, j)+
                                          local_20_matrix(i, j)+local_21_matrix(i, j)+local_22_matrix(i, j);

             }

            /*Creating RHS
             [b
              0
              d] where d=0*/

            local_rhs(i) +=   ((component_0_phi_i)*
                               control_values [q] *
                               fe_values.JxW(q));


           }


       }

           cell->get_dof_indices (local_dof_indices);

           matrix_constraints.distribute_local_to_global (local_matrix,
                                                          local_rhs,
                                                          local_dof_indices,
                                                          system_matrix,
                                                          system_rhs);


           preconditioner_constraints.distribute_local_to_global (local_pre_matrix,
                                                          local_dof_indices,
                                                          preconditioner_matrix
                                                          );
     }




     system_matrix.compress(VectorOperation::add);
     preconditioner_matrix.compress(VectorOperation::add);
     cout<<"system assembled... "<<endl;

 }



template <int dim>
void PoissonControl<dim>::solve ()
{

        /*set the Preconditioner */
        const LinearSolvers::InverseMatrix<TrilinosWrappers::SparseMatrix, TrilinosWrappers::PreconditionChebyshev> m_inverse (preconditioner_matrix.block(0,0),*IC_preconditioner, Iterations::CHEBYCHEV,ToleranceLimits::inner_solver_chb);
        //cout<<"1"<<endl;
        const LinearSolvers::InverseMatrix<TrilinosWrappers::SparseMatrix, TrilinosWrappers::PreconditionAMG> s_inverse (preconditioner_matrix.block(2,2),*Amg_preconditioner, Iterations::AMG,ToleranceLimits::inner_solver_amg);
        //cout<<"2"<<endl;
        const BlockPreconditioner<TrilinosWrappers::PreconditionAMG, TrilinosWrappers::PreconditionChebyshev> preconditioner (preconditioner_matrix, m_inverse, s_inverse);
        //cout<<"3"<<endl;
        double tolerance_level = system_rhs.l2_norm()*ToleranceLimits::outer_solver;

            cout<<"computed tolerence Level is "<<tolerance_level<<endl
                <<"norm of RHS "<<system_rhs.l2_norm()<<endl;
        /*Initialize the SolverControl */
        /*Initialize the SolverControl */
        SolverControl solver_control (system_matrix.m(), tolerance_level ,false,false);
        SolverFGMRES<TrilinosWrappers::BlockVector> fgmres (solver_control);//, SolverFGMRES<TrilinosWrappers::BlockVector >::AdditionalData(70, true));
        SolverMinRes<TrilinosWrappers::BlockVector> minres (solver_control);

        solution = 0;
        double time=0;

        try{

            if(s==SolverType::GMRES){
            timer.restart();
             fgmres.solve(system_matrix, solution, system_rhs, preconditioner);
            time=timer.wall_time();
            }else{
                timer.restart();
                minres.solve(system_matrix, solution, system_rhs, preconditioner);
                time=timer.wall_time();
            }


            matrix_constraints.distribute (solution.block(0));

       }catch (std::exception &e){
           Assert(true, ExcMessage(e.what()));
       }

        cout << "   "

             << solver_control.last_step() //<<"("<<LinearSolvers::cb_it<<"/"<<LinearSolvers::amg_it<<")"
             << " GMRES iterations for system."
             << std::endl
             << LinearSolvers::cb_it/solver_control.last_step()
             << " avg inner chebishev iterations for system."
             << std::endl
             << LinearSolvers::amg_it/solver_control.last_step()
             << " avg inner amg iterations for system."
             << std::endl
             << LinearSolvers::cg_it/solver_control.last_step()
             << " avg inner solver iterations for system."
             << std::endl
             << "time "<<time //<<"("<<LinearSolvers::cb_timer_in_sec<<"/"<<LinearSolvers::amg_timer_in_sec<<")"
             << std::endl
             << "done ...."
             << std::endl;

        compute_errors();

        process_solution(table_1, solution.block(1).linfty_norm(), solver_control.last_step(), tolerance_level, time);

}

template <int dim>
void PoissonControl<dim>::output_results () const
{
  /*std::ofstream output1;
  output1.open ("A.txt");
  system_matrix.block(0,0).print(output1);
  output1.close();

  std::ofstream output2;
  output2.open ("B.txt");
  system_matrix.block(0,1).print(output2);
  output2.close();

  std::ofstream output3;
  output3.open ("C.txt");
  system_matrix.block(0,2).print(output3);

  output3.close();


  std::ofstream output14;
  output14.open ("D.txt");
  system_matrix.block(1,0).print(output14);
  output14.close();


  output14.open ("E.txt");
  system_matrix.block(1,1).print(output14);
  output14.close();


  output14.open ("F.txt");
  system_matrix.block(1,2).print(output14);
  output14.close();


  output14.open ("G.txt");
  system_matrix.block(2,0).print(output14);
  output14.close();

  output14.open ("H.txt");
  system_matrix.block(2,1).print(output14);
  output14.close();

  output14.open ("I.txt");
  system_matrix.block(2,2).print(output14);
  output14.close();

  std::ofstream output5;
  output5.open ("J.txt");
  system_rhs.block(0).print(output5);
  output5.close();

  std::ofstream output6;
  output6.open ("K.txt");
  system_rhs.block(1).print(output6);
  output6.close();

  output6.open ("L.txt");
  system_rhs.block(2).print(output6);
  output6.close();


 /* output6.open ("s_y.txt");
  solution.block(0).print(output6);
  output6.close();
  output6.open ("s_u.txt");
  solution.block(1).print(output6);
  output6.close();

  output6.open ("s_p.txt");
  solution.block(2).print(output6);
  output6.close();

  output6.open ("rhs.txt");
  system_rhs.print(output6);
  output6.close();


  output6.open ("M00.txt");
  preconditioner_matrix.block(0,0).print(output6);
  output6.close();

  output6.open ("P02.txt");
  preconditioner_matrix.block(0,2).print(output6);
  output6.close();
  output6.open ("AMG.txt");
  preconditioner_matrix.block(2,2).print(output6);
  output6.close();

  output6.open ("points.txt");

  for(int i=0;i<point_list.size();i++){
  PointData p=(PointData)point_list[i];
  output6 << p;
  }
  output6.close();*/

    std::vector<std::string> solution_names;
    switch (dim)
    {
    case 2:
            solution_names.push_back ("state(y)");
            solution_names.push_back ("control(u)");
            solution_names.push_back ("p");
    break;
    case 3:
            solution_names.push_back ("y");
            solution_names.push_back ("u");
            solution_names.push_back ("p");

     break;
    default:
    Assert (false, ExcNotImplemented());
 }

    DataOut<dim> data_out;
    data_out.attach_dof_handler (system_dof_handler);
    data_out.add_data_vector (solution, solution_names);
    data_out.build_patches ();
   std::ostringstream filename;
   filename << "solution-"
               << vtk_tile_name
               <<".vtk";
        std::ofstream output (filename.str().c_str());
        data_out.write_vtk (output);

}

template <int dim>
void PoissonControl<dim>::initialize_preconditioner(){
        /*Defing the AMG Preconditioner */
        Amg_preconditioner = std_cxx1x::shared_ptr<TrilinosWrappers::PreconditionAMG> (new TrilinosWrappers::PreconditionAMG());
        TrilinosWrappers::PreconditionAMG::AdditionalData Amg_data;
        Amg_data.elliptic = true;
        Amg_data.smoother_sweeps = 2;
        Amg_data.aggregation_threshold = 0.5;
        Amg_data.smoother_type="symmetric Gauss-Seidel";

        Amg_preconditioner->initialize(preconditioner_matrix.block(2,2), Amg_data);
        /*defining IC */
        TrilinosWrappers::PreconditionChebyshev::AdditionalData cb1_data;
        cb1_data.max_eigenvalue=9.0/4.0;
        cb1_data.min_eigenvalue=1.0/4.0;
        IC_preconditioner = std_cxx1x::shared_ptr<TrilinosWrappers::PreconditionChebyshev> (new TrilinosWrappers::PreconditionChebyshev());
        IC_preconditioner->initialize(preconditioner_matrix.block(0,0), cb1_data);


}

template <int dim>
void PoissonControl<dim>::run ()
{


    int beta_values_length =beta_values.size();
    int refinements_length =refinements.size();


    table_1.clear();
    set_labels();

    for (unsigned int i=0;i<beta_values_length;i++)

    for (unsigned int j=0;j<refinements_length;j++){

        n_refs=double(refinements[j]);
        EquationData::beta= double(beta_values[i]);    
        h = std::pow(0.5, (n_refs));
        cout << "mesh size: " << h<< std::endl<<
                "number of refinements: " <<n_refs<< std::endl<<
                "beta: " <<EquationData::beta<< std::endl;
     make_grid_and_dofs (n_refs);
     assemble_constant_matrix_equation ();

     initialize_preconditioner();
     solve ();

     output_results ();
     triangulation.clear();
     Amg_preconditioner->clear();
     IC_preconditioner->clear();
     LinearSolvers::cg_it=0;
     LinearSolvers::cb_it=0;
     LinearSolvers::amg_it=0;
     }


        MiscUtilities::print_tex_tables(tex_file_name, s, table_1);
        MiscUtilities::print_table_data (text_table_file_name, beta_values_length, refinements_length, table_data_list);
        table_data_list.clear();


}

template <int dim>
void PoissonControl<dim>::set_labels(){

    if(Poisson::p_type==Poisson::PreconditionerType::BD_SCHUR_BASED){
        std::stringstream ss;
        ss << std::scientific << std::setprecision(1) << EquationData::beta;
        string caption ="Problem("+std::to_string(Poisson::solve_problem_type)+"): "+"$P_{bd}:\\beta="+ss.str()+"$";
        tex_table_caption=caption;

        tex_file_name="bd_schur";
        text_table_file_name="bd_schur";
        vtk_tile_name="BD_SCHUR";
    }

    if(Poisson::p_type==Poisson::PreconditionerType::BLT_SCHUR_BASED){
           std::stringstream ss;
           ss << std::scientific << std::setprecision(1) << EquationData::beta;
           string caption ="Problem("+std::to_string(Poisson::solve_problem_type)+"): "+"$P_{blt}:\\beta="+ss.str()+"$";
           tex_table_caption=caption;

           tex_file_name="blt_schur";
           text_table_file_name="blt_schur";
           vtk_tile_name="BLT_SCHUR";
         }


    }

template <int dim>
void PoissonControl<dim>::process_solution(TableHandler &table, double l_infinity, unsigned int iterations, double tolerance, double time){

    //Set the text table file
    MiscUtilities::TableData td;
    td.dofs=system_dof_handler.n_dofs();
    td.beta=EquationData::beta;
    td.iterations=iterations;
    td.m_iterations=Iterations::CHEBYCHEV*2;
    td.k_iterations=LinearSolvers::amg_it/(iterations+1);
    td.time=time;
    table_data_list.push_back(td);


    //Set the table !
    table.add_value("dofs", n_y+n_p);

    table.add_value("ref", n_refs);
    table.add_value("$\\beta$",EquationData::beta);
    table.add_value("$\\widetilde{\\beta}$",0);

    table.add_value("iter",iterations);

    table.add_value("$\\hat{M}$",Iterations::CHEBYCHEV*2);
    table.add_value("$\\hat{S}$",LinearSolvers::amg_it/(iterations+1));
    table.add_value("$|u|_{2}$",u_l2_norm);
    table.add_value("$\|u\|_{\\infty}$",l_infinity);
    table.add_value("$\|y-\\hat{y}\|$",y_yd_l2_norm);
    table.add_value("$\|y-\\hat{y}\|/|\\hat{y}\|$",rel_y_yd_l2_norm);
    table.add_value("$J$",cost_functional_J);
    table.add_value("Tol",tolerance);
    table.add_value("time",time);
}

template <int dim>
void PoissonControl<dim>::init_parameters(){
   // beta_values = {pow(10,-2), pow(10,-3), pow(10,-4), pow(10,-5), pow(10,-6), pow(10,-7), pow(10,-8), pow(10,-9), pow(10,-10)};
    refinements =  {4, 5, 6, 7, 8};
    //beta_values = {2.0*pow(10,-3), 2.0*pow(10,-4), 2.0*pow(10,-5),2.0*pow(10,-6)};
    //beta_values = {2*pow(10,-2), 2*pow(10,-3), 2*pow(10,-4), 2*pow(10,-5), 2*pow(10,-6), pow(10,-7), 2*pow(10,-8), 2*pow(10,-9), 2*pow(10,-10)};
    refinements =  {6};
    beta_values = {2*pow(10,-6)};
     Poisson::solve_problem_type=Poisson::Problem_Type::HEAT_FLOW_1;
    total_time.restart();


    cout<<"using Block Lower Triangular preconditioner... "<<endl;
    Poisson::p_type=Poisson::PreconditionerType::BLT_SCHUR_BASED;
    s=SolverType::GMRES;
    run ();

    cout<<"using Block Diagonal preconditioner... "<<endl;
    s=SolverType::MINRES;
    Poisson::p_type=Poisson::PreconditionerType::BD_SCHUR_BASED;
    run ();

    cout<<"ALL COMPUTATIONS ENDED "<<total_time.wall_time()/60.0<<endl;


}
template <int dim>
void PoissonControl<dim>::compute_errors ()
{
    const ComponentSelectFunction<dim> y_mask (0, 3);

    Poisson::ControlValues<dim> desired_solution(3);
    unsigned int n_cells=triangulation.n_active_cells();
    Vector<double> cellwise_errors (n_cells);
    QTrapez<1> q_trapez;
    QIterated<dim> quadrature (q_trapez, degree+2);

    VectorTools::integrate_difference (system_dof_handler,
                                       solution,
                                       desired_solution,
                                       cellwise_errors,
                                       quadrature,
                                       VectorTools::L2_norm,
                                       &y_mask);
    y_yd_l2_norm= cellwise_errors.l2_norm();

    VectorTools::integrate_difference (system_dof_handler,
                                       zero_vector,
                                       desired_solution,
                                       cellwise_errors,
                                       quadrature,
                                       VectorTools::L2_norm,
                                       &y_mask);



   rel_y_yd_l2_norm =y_yd_l2_norm/cellwise_errors.l2_norm();
   u_l2_norm=solution.block(1).l2_norm();


    cost_functional_J =0.5*(y_yd_l2_norm*y_yd_l2_norm)+0.5*EquationData::beta*(u_l2_norm*u_l2_norm);
    cout<<"cost functional J = "<<cost_functional_J<<endl<<
          "||y-yd||       = "<< y_yd_l2_norm<<endl<<
          "||y-yd||/yd    = "<< rel_y_yd_l2_norm<<endl<<
          "||u||          = "<<u_l2_norm<<endl;

}



int main (int argc, char *argv[])
{
  Utilities::MPI::MPI_InitFinalize mpi_initialization(argc, argv);

  deallog.depth_console(0);
  PoissonControl<2> p_control(1);
  p_control.init_parameters();

  //SET PRECONDITIONER TYPE

  return 0;
}

