#include <deal.II/base/quadrature_lib.h>
#include <deal.II/base/function.h>

#include <deal.II/lac/solver_cg.h>
#include <deal.II/lac/solver_gmres.h>
#include <deal.II/lac/solver_minres.h>
#include <deal.II/lac/constraint_matrix.h>
#include <deal.II/lac/block_sparsity_pattern.h>
#include <deal.II/lac/trilinos_block_vector.h>
#include <deal.II/lac/trilinos_sparse_matrix.h>
#include <deal.II/lac/trilinos_block_sparse_matrix.h>
/*For PreconditionAMG */
#include <deal.II/lac/trilinos_precondition.h>
/*For PreconditionIdentity*/
#include <deal.II/lac/precondition.h>

#include <deal.II/grid/tria.h>
#include <deal.II/grid/grid_generator.h>
#include <deal.II/grid/tria_accessor.h>
#include <deal.II/grid/tria_iterator.h>

#include <deal.II/dofs/dof_handler.h>
#include <deal.II/dofs/dof_renumbering.h>
#include <deal.II/dofs/dof_accessor.h>
#include <deal.II/dofs/dof_tools.h>

#include <deal.II/fe/fe_q.h>
#include <deal.II/fe/fe_system.h>
#include <deal.II/fe/fe_values.h>

/*Vector and Matrix tools */
#include <deal.II/numerics/vector_tools.h>
#include <deal.II/numerics/matrix_tools.h>


#include <fstream>
#include <iostream>
#include <string>
#include <deal.II/numerics/data_out.h>
#include <deal.II/lac/lapack_full_matrix.h>
#include <deal.II/lac/transpose_matrix.h>

/*for iterative inverse*/
#include <deal.II/lac/iterative_inverse.h>

/* For convergence table out put */
#include <deal.II/base/table_handler.h>
#include <deal.II/grid/intergrid_map.h>
/* The timer class header */
#include <deal.II/base/timer.h>
#include "../solver_impl.hh"
#include "../data.hh"
#include "../MiscUtilities.hh"

#include <deal.II/base/std_cxx1x/thread.h>
#include <deal.II/lac/matrix_out.h>
#include <deal.II/grid/grid_tools.h>
#include <deal.II/fe/fe_dgq.h>

using namespace dealii;


namespace EquationData
{

  double beta;
  const double epsilon=1.0/500.0;
}


template <class PreconditionerA, class PreconditionerB>
class BlockPreconditioner : public Subscriptor
{
  public:
    BlockPreconditioner (const TrilinosWrappers::BlockSparseMatrix  &system_matrix,
                         const LinearSolvers::InverseMatrix<TrilinosWrappers::SparseMatrix, PreconditionerB> &chb_1,
                         const LinearSolvers::InverseMatrix<TrilinosWrappers::SparseMatrix, PreconditionerA> &amg_1,
                         const LinearSolvers::InverseMatrix<TrilinosWrappers::SparseMatrix, PreconditionerA> &amg_2,
                         unsigned const int n_y
                         );

    void vmult (TrilinosWrappers::BlockVector &dst,
                const TrilinosWrappers::BlockVector &src) const;

    void implement_ns_block_factorization_unscaled(TrilinosWrappers::BlockVector &dst,
                           const TrilinosWrappers::BlockVector &src) const;


    void implement_bd_preconditioner_schur_approx(TrilinosWrappers::BlockVector &dst,
                           const TrilinosWrappers::BlockVector &src) const;


    void implement_bd_non_standard_norm_unscaled(TrilinosWrappers::BlockVector &dst,
                                           const TrilinosWrappers::BlockVector &src) const;


    void implement_blt_preconditioner_schur_approx(TrilinosWrappers::BlockVector &dst,
                                                    const TrilinosWrappers::BlockVector &src) const;

    void implement_blt_non_standard_norm_unscaled(TrilinosWrappers::BlockVector &dst,
                                                  const TrilinosWrappers::BlockVector &src) const;


  private:

    const SmartPointer<const TrilinosWrappers::BlockSparseMatrix> system_matrix;
    const SmartPointer<const LinearSolvers::InverseMatrix<TrilinosWrappers::SparseMatrix, PreconditionerB> > chb_1;
    const SmartPointer<const LinearSolvers::InverseMatrix<TrilinosWrappers::SparseMatrix, PreconditionerA> > amg_1;
    const SmartPointer<const LinearSolvers::InverseMatrix<TrilinosWrappers::SparseMatrix, PreconditionerA> > amg_2;

    unsigned const int n_y;

    mutable TrilinosWrappers::Vector y, p, f_1, f_2;


};

template <class PreconditionerA, class PreconditionerB>
BlockPreconditioner<PreconditionerA, PreconditionerB>::
BlockPreconditioner(const TrilinosWrappers::BlockSparseMatrix  &_system_matrix,
                    const LinearSolvers::InverseMatrix<TrilinosWrappers::SparseMatrix, PreconditionerB> &_chb_1,
                    const LinearSolvers::InverseMatrix<TrilinosWrappers::SparseMatrix, PreconditionerA> &_amg_1,
                    const LinearSolvers::InverseMatrix<TrilinosWrappers::SparseMatrix, PreconditionerA> &_amg_2,
                    unsigned const int _n_y)
                :
                system_matrix   (&_system_matrix),
                chb_1                   (&_chb_1),
                amg_1                   (&_amg_1),
                amg_2                   (&_amg_2),
                n_y                     (_n_y),
                f_1                     (n_y),
                f_2                     (n_y),
                y                       (n_y),
                p                       (n_y)
{


}

template <class PreconditionerA, class PreconditionerB>
void BlockPreconditioner<PreconditionerA, PreconditionerB >::vmult (
  TrilinosWrappers::BlockVector &dst,
  const TrilinosWrappers::BlockVector &src) const
{

  if(ConvectionDiffusion::p_type==ConvectionDiffusion::PreconditionerType::BD_NORM_BASED)
      implement_bd_non_standard_norm_unscaled(dst, src);
  if(ConvectionDiffusion::p_type==ConvectionDiffusion::PreconditionerType::B_FACTORIZATION)
     implement_ns_block_factorization_unscaled(dst, src);

   if(ConvectionDiffusion::p_type==ConvectionDiffusion::PreconditionerType::BD_SCHUR_BASED)
   implement_bd_preconditioner_schur_approx(dst, src);

   if(ConvectionDiffusion::p_type==ConvectionDiffusion::PreconditionerType::BLT_SCHUR_BASED)
   implement_blt_preconditioner_schur_approx(dst, src);


   if(ConvectionDiffusion::p_type==ConvectionDiffusion::PreconditionerType::BLT_NORM_BASED)
   implement_blt_non_standard_norm_unscaled(dst, src);

}

//preconditioner P5=[M  -beta*K ]
//                   K        M ]   S_hat=


template <class PreconditionerA, class PreconditionerB>
void BlockPreconditioner<PreconditionerA, PreconditionerB >::implement_blt_non_standard_norm_unscaled(TrilinosWrappers::BlockVector &dst,
                                       const TrilinosWrappers::BlockVector &src) const
{

    y    = 0;
    p    = 0;
    f_1  = 0;

    amg_2->vmult(y,src.block(0));
    system_matrix->block(1, 0).vmult(f_1, y);
    f_2 =src.block(1);
    f_2-=f_1;

    amg_1->vmult(p,f_2);
    p *=EquationData::beta;
    //p *=-1.0;
    dst.block(0) =  y;
    dst.block(1) =  p;

}


template <class PreconditionerA, class PreconditionerB>
void BlockPreconditioner<PreconditionerA, PreconditionerB >::implement_bd_preconditioner_schur_approx(TrilinosWrappers::BlockVector &dst,
                                       const TrilinosWrappers::BlockVector &src) const
{
    y = 0;
    p = 0;

    f_1=0;
    f_2=0;

    chb_1->vmult(y, src.block(0));
    amg_2->vmult(f_1,src.block(1));
    system_matrix->block(0,0).vmult (f_2, f_1);
    amg_1->vmult(p, f_2);


    dst.block(0) = y;
    dst.block(1) = p;

}

template <class PreconditionerA, class PreconditionerB>
void BlockPreconditioner<PreconditionerA, PreconditionerB >::implement_blt_preconditioner_schur_approx(
                                                                                TrilinosWrappers::BlockVector &dst,
                                                                                const TrilinosWrappers::BlockVector &src) const
{
    y = 0;
    p = 0;

    chb_1->vmult(y, src.block(0));
    //K*p
    system_matrix->block(1,0).vmult(f_1, y);
    //-M*u
    f_2 =src.block(1);

    //Add Ky
    f_2 -= f_1;
    //add Mu

    amg_2->vmult(f_1,f_2);
    //g1=M*g2
    system_matrix->block(0,0).vmult (f_2, f_1);
    amg_1->vmult(p, f_2);
    p *=-1.0;
    dst.block(0) = y;
    dst.block(1) = p;
}



template <class PreconditionerA, class PreconditionerB>
void BlockPreconditioner<PreconditionerA, PreconditionerB >::implement_bd_non_standard_norm_unscaled(TrilinosWrappers::BlockVector &dst,
                                       const TrilinosWrappers::BlockVector &src) const
{

    y    = 0;
    p    = 0;

    amg_2->vmult(y,src.block(0));
    amg_1->vmult(p,src.block(1));
    p *=EquationData::beta;

    dst.block(0) =  y;
    dst.block(1) =  p;

}

template <class PreconditionerA, class PreconditionerB>
void BlockPreconditioner<PreconditionerA, PreconditionerB >::implement_ns_block_factorization_unscaled(
                                                                                TrilinosWrappers::BlockVector &dst,
                                                                                const TrilinosWrappers::BlockVector &src) const
 {


    TrilinosWrappers::Vector g_1(n_y);
    TrilinosWrappers::Vector g(n_y);
    TrilinosWrappers::Vector m_g(n_y);
    TrilinosWrappers::Vector w(n_y);
    g_1=0;

    double rho=sqrt(EquationData::beta);
    f_1 = src.block(0);
    f_2 = src.block(1);

    f_2  *= rho;
    g_1  += f_1;
    g_1  +=f_2;

    amg_1->vmult (g, g_1);
    system_matrix->block(0,0).vmult (m_g, g);
    m_g *=-1.0;
    g_1  =f_1;
    g_1 +=m_g;
    amg_2->vmult(w, g_1);
    dst.block(0)  = g;
    dst.block(0) += w;
    w *=-1.0/rho;
    dst.block(1) =w;

}



/*The main class*/
template <int dim>
class OptimalControl
{
  public:
    OptimalControl (const unsigned int degree);
    void  init_parameters();
    void run ();

  private:
    void make_grid_and_dofs (const double n_refinement_steps);
    void assemble_constant_matrix_equation();
    void set_labels();
    void solve(unsigned int iteration);

    void compute_errors (TrilinosWrappers::BlockVector e_solution_VH);
    void output_results() const;

    void print_tables();
    void push_table_data(unsigned int iterations, double time);


    void initialize_preconditioner();
    void process_solution(TableHandler &table,  double l_infinity, unsigned int iterations, double tolerance, double time);


    dealii::Triangulation<dim>   triangulation_VH;
    dealii::Triangulation<dim>   triangulation_Vh;

    FESystem<dim>    system_fe_phi;
    FESystem<dim>    system_fe_PSI;


    DoFHandler<dim>   system_dof_handler_Vh;
    DoFHandler<dim>   system_dof_handler_VH;
    DoFHandler<dim>   dof_handler_Vh;

    //Sparsity pattern
    TrilinosWrappers::BlockSparsityPattern sparsity_pattern;
    TrilinosWrappers::SparsityPattern proj_sparsity_pattern;
    TrilinosWrappers::BlockSparsityPattern pre_sparsity_pattern;

    double h;
    double n_refs;
    //Matrices
    TrilinosWrappers::BlockSparseMatrix system_matrix;
    TrilinosWrappers::BlockSparseMatrix system_matrix_VH;
    TrilinosWrappers::BlockSparseMatrix preconditioner_matrix;
    TrilinosWrappers::SparseMatrix matrix_K_01;
    TrilinosWrappers::SparseMatrix matrix_K_10;
    TrilinosWrappers::SparseMatrix matrix_M_11;
    //constraints
    ConstraintMatrix  matrix_constraints;
    ConstraintMatrix  preconditioner_constraints;
    ConstraintMatrix  matrix_constraints_VH;

    std::vector<types::global_dof_index> system_block_sizes;




    TrilinosWrappers::BlockVector solution_Vh;
    TrilinosWrappers::BlockVector interp_solution_Vh;

    TrilinosWrappers::BlockVector system_rhs;
    TrilinosWrappers::BlockVector system_rhs_VH;
    TrilinosWrappers::BlockVector solution_VH;
    TrilinosWrappers::BlockVector zero_vector;



    double u_l2_norm;
    double y_yd_l2_norm;
    double rel_y_yd_l2_norm;
    double cost_functional_J;
    unsigned int n_y;
    unsigned int n_p;


    const unsigned int degree;

    std::vector< MiscUtilities::TableData> table_data_list;

    std_cxx1x::shared_ptr<TrilinosWrappers::PreconditionAMG> amg_preconditioner_1;
    std_cxx1x::shared_ptr<TrilinosWrappers::PreconditionAMG> amg_preconditioner_2;

    std_cxx1x::shared_ptr<TrilinosWrappers::PreconditionChebyshev> cb_preconditioner;


    TableHandler table_1;
    std::string tex_table_caption;
    std::string tex_file_name;
    std::string text_table_file_name;
    std::string vtk_tile_name;


    std::vector<double> beta_values;
    std::vector<int> refinements;
    std::vector<double> inner_tolerance;
    Timer timer;
    Timer total_time;
    SolverType s;



};

 template <int dim>
 OptimalControl<dim>::OptimalControl(const unsigned int degree)
        :
        degree(degree),
        triangulation_Vh (Triangulation<dim>::none),
        triangulation_VH (Triangulation<dim>::none),
        system_fe_phi(FE_Q<dim>(degree),2),
        system_fe_PSI(FE_DGQ<dim>(0),2),
        system_dof_handler_Vh(triangulation_Vh),
        system_dof_handler_VH(triangulation_VH)


 {

 }

 /////////////////////make_grid_and_dofs////////////////////////////////
template <int dim>
 void OptimalControl<dim>::make_grid_and_dofs (const double n_refinement_steps)
 {

  if(ConvectionDiffusion::solve_problem_type==ConvectionDiffusion::Problem_Type::DOUBLE_GLAZING_1){
     GridGenerator::hyper_cube (triangulation_Vh, -1, 1);
     GridGenerator::hyper_cube (triangulation_VH, -1, 1);
  }
  else if(ConvectionDiffusion::solve_problem_type==ConvectionDiffusion::Problem_Type::CONST_WIND_1 || ConvectionDiffusion::solve_problem_type==ConvectionDiffusion::Problem_Type::CONST_WIND_2){
     GridGenerator::hyper_cube (triangulation_Vh, 0, 1);
     GridGenerator::hyper_cube (triangulation_VH, 0, 1);
  }
   triangulation_Vh.refine_global (n_refinement_steps);
   triangulation_VH.refine_global (n_refinement_steps);

  //set the boundary indicator
   if(ConvectionDiffusion::solve_problem_type==ConvectionDiffusion::Problem_Type::CONST_WIND_1){
     for (typename Triangulation<dim>::active_cell_iterator
     cell = triangulation_Vh.begin_active();
     cell != triangulation_Vh.end(); ++cell)
     for (unsigned int f=0; f<GeometryInfo<dim>::faces_per_cell; ++f)

            if ((cell->face(f)->center()(0) <= 0.5 && cell->face(f)->center()(1)==0.0) ||
                (cell->face(f)->center()(1) <= 0.5 && cell->face(f)->center()(0)==0.0)
                )              
                cell->face(f)->set_boundary_indicator(1);

   }  else if(ConvectionDiffusion::solve_problem_type== ConvectionDiffusion::Problem_Type::CONST_WIND_2){
       //Set boundary indicator
        for (typename Triangulation<dim>::active_cell_iterator
         cell = triangulation_Vh.begin_active();
         cell != triangulation_Vh.end(); ++cell)
         for (unsigned int f=0; f<GeometryInfo<dim>::faces_per_cell; ++f)
             if ((fabs(cell->face(f)->center()(1)-1.0) <= 1e-10))
                      cell->face(f)->set_boundary_indicator(1);
     }else if(ConvectionDiffusion::solve_problem_type== ConvectionDiffusion::Problem_Type::DOUBLE_GLAZING_1){
      //Set boundary indicator
       for (typename Triangulation<dim>::active_cell_iterator
        cell = triangulation_Vh.begin_active();
        cell != triangulation_Vh.end(); ++cell)
        for (unsigned int f=0; f<GeometryInfo<dim>::faces_per_cell; ++f)
            if ((fabs(cell->face(f)->center()(1)-1.0) <= 1e-10))
                     cell->face(f)->set_boundary_indicator(1);



    }


   system_dof_handler_Vh.distribute_dofs (system_fe_phi);
   system_dof_handler_VH.distribute_dofs (system_fe_PSI);


   std::vector<unsigned int> pde_sub_blocks (2,0);
   pde_sub_blocks[0]=0;
   pde_sub_blocks[1]=1;


   DoFRenumbering::component_wise (system_dof_handler_Vh, pde_sub_blocks);
   DoFRenumbering::component_wise (system_dof_handler_VH, pde_sub_blocks);
   cout<<"Sub Blocks ititialized "<<endl;
   cout<<"Done till here ... "<<endl;
   /*The next thing is that we want to figure out the sizes of these blocks,
    so that we can allocate an appropriate amount of space. */
   std::vector<types::global_dof_index> dofs_per_component (2);
   DoFTools::count_dofs_per_component (system_dof_handler_Vh, dofs_per_component);
   n_y = dofs_per_component[0];
   n_p = dofs_per_component[1];

   DoFTools::count_dofs_per_component (system_dof_handler_VH, dofs_per_component);
   unsigned int n_y_H = dofs_per_component[0];
   unsigned int n_p_H = dofs_per_component[1];

   cout <<"Number of active cells on \phi space : "<< triangulation_Vh.n_active_cells()<< std::endl
        <<"Number of active cells on \psi space : "<< triangulation_VH.n_active_cells()<< std::endl
        << "Number of degrees of freedom y: "
        << n_y << std::endl
        << "Number of degrees of freedom p: "
        << n_p
        << std::endl
        << "Total degrees: "
        << (n_y+n_p)
        << std::endl;

   system_block_sizes.resize (1);
   system_block_sizes[0] = n_y;
   system_block_sizes[1] = n_p;



   const FEValuesExtractors::Scalar component_y(0);
   const FEValuesExtractors::Scalar component_p(1);
   /*Apply Dirichelet to the whole matrix*/
   matrix_constraints.clear ();

   VectorTools::interpolate_boundary_values (system_dof_handler_Vh, 0, ZeroFunction<dim>(2),  matrix_constraints, system_fe_phi.component_mask(component_y));
   VectorTools::interpolate_boundary_values (system_dof_handler_Vh, 0, ZeroFunction<dim>(2),  matrix_constraints, system_fe_phi.component_mask(component_p));

   VectorTools::interpolate_boundary_values (system_dof_handler_Vh, 1, ConvectionDiffusion::BoundaryValues<dim>(2), matrix_constraints, system_fe_phi.component_mask(component_y));
   VectorTools::interpolate_boundary_values (system_dof_handler_Vh, 1, ZeroFunction<dim>(2),  matrix_constraints, system_fe_phi.component_mask(component_p));

   matrix_constraints.close ();

   preconditioner_constraints.clear ();

   VectorTools::interpolate_boundary_values (system_dof_handler_Vh, 0, ZeroFunction<dim>(2),  preconditioner_constraints,  system_fe_phi.component_mask(component_y));
   VectorTools::interpolate_boundary_values (system_dof_handler_Vh, 0, ZeroFunction<dim>(2),  preconditioner_constraints, system_fe_phi.component_mask(component_p));

   VectorTools::interpolate_boundary_values (system_dof_handler_Vh, 1, ConvectionDiffusion::BoundaryValues<dim>(2),  preconditioner_constraints, system_fe_phi.component_mask(component_y));
   VectorTools::interpolate_boundary_values (system_dof_handler_Vh, 1, ZeroFunction<dim>(2),  preconditioner_constraints, system_fe_phi.component_mask(component_p));


   preconditioner_constraints.close ();

   cout<<"Dirichlet condition applied "<<endl;

   /*Sparsity Pattern for the System Matrix */
   {
   system_matrix.clear ();
   sparsity_pattern.reinit (2,2);
   const unsigned int n_couplings = system_dof_handler_Vh.max_couplings_between_dofs();
   sparsity_pattern.block(0,0).reinit (n_y, n_y, n_couplings);
   sparsity_pattern.block(1,0).reinit (n_p, n_y, n_couplings);

   sparsity_pattern.block(0,1).reinit (n_y, n_p, n_couplings);
   sparsity_pattern.block(1,1).reinit (n_p, n_p, n_couplings);
   sparsity_pattern.collect_sizes();  //what is this for? yes, needed when we touch each block separately!,

   DoFTools::make_sparsity_pattern(system_dof_handler_Vh,
                     sparsity_pattern,
                     matrix_constraints,
                     true);
    sparsity_pattern.compress();
    system_matrix.reinit (sparsity_pattern);

}



   /*Sparsity Pattern for the System Matrix */
   {
   system_matrix_VH.clear ();
   sparsity_pattern.reinit (2,2);
   const unsigned int n_couplings = system_dof_handler_VH.max_couplings_between_dofs();
   sparsity_pattern.block(0,0).reinit (n_y_H, n_y_H, n_couplings);
   sparsity_pattern.block(1,0).reinit (n_p_H, n_y_H, n_couplings);

   sparsity_pattern.block(0,1).reinit (n_y_H, n_p_H, n_couplings);
   sparsity_pattern.block(1,1).reinit (n_p_H, n_p_H, n_couplings);
   sparsity_pattern.collect_sizes();  //what is this for? yes, needed when we touch each block separately!,

   DoFTools::make_sparsity_pattern(system_dof_handler_VH,
                     sparsity_pattern,
                     matrix_constraints_VH,
                     true);
    sparsity_pattern.compress();
    system_matrix_VH.reinit (sparsity_pattern);

}

   /*Sparsity Pattern for the System Matrix */
   {
   preconditioner_matrix.clear ();
   pre_sparsity_pattern.reinit (2,2);
   const unsigned int n_couplings = system_dof_handler_Vh.max_couplings_between_dofs();
   pre_sparsity_pattern.block(0,0).reinit (n_y, n_y, n_couplings);
   pre_sparsity_pattern.block(1,0).reinit (n_p, n_y, n_couplings);

   pre_sparsity_pattern.block(0,1).reinit (n_y, n_p, n_couplings);
   pre_sparsity_pattern.block(1,1).reinit (n_p, n_p, n_couplings);
   pre_sparsity_pattern.collect_sizes();  //what is this for? yes, needed when we touch each block separately!,

   DoFTools::make_sparsity_pattern (system_dof_handler_Vh,
                     pre_sparsity_pattern,
                     preconditioner_constraints,
                     true);

    pre_sparsity_pattern.compress();
    preconditioner_matrix.reinit(pre_sparsity_pattern);
}


   solution_Vh.reinit (2);
   solution_Vh.block(0).reinit (n_y);
   solution_Vh.block(1).reinit (n_p);
   solution_Vh.collect_sizes ();

   interp_solution_Vh.reinit (2);
   interp_solution_Vh.block(0).reinit (n_y);
   interp_solution_Vh.block(1).reinit (n_p);
   interp_solution_Vh.collect_sizes ();


   system_rhs.reinit (2);
   system_rhs.block(0).reinit (n_y);
   system_rhs.block(1).reinit (n_p);
   system_rhs.collect_sizes ();

   system_rhs_VH.reinit (2);
   system_rhs_VH.block(0).reinit (n_y_H);
   system_rhs_VH.block(1).reinit (n_p_H);
   system_rhs_VH.collect_sizes ();

   solution_VH.reinit (2);
   solution_VH.block(0).reinit (n_y_H);
   solution_VH.block(1).reinit (n_p_H);
   solution_VH.collect_sizes ();


   zero_vector.reinit (2);
   zero_vector.block(0).reinit (n_y);
   zero_vector.block(1).reinit (n_p);
   zero_vector.collect_sizes ();
   zero_vector=0;


   cout<<"initialized... "<<endl;
 }
 /////////////////////assemble_constant_matrix(K,M)///////////////
 template <int dim>
 void OptimalControl<dim>::assemble_constant_matrix_equation ()
 {

     system_matrix = 0;
     preconditioner_matrix = 0;
     system_rhs= 0;


     const FEValuesExtractors::Scalar component_y(0);
     const FEValuesExtractors::Scalar component_p(1);


     const unsigned int   dofs_per_cell       = system_fe_phi.dofs_per_cell;
     const unsigned int   dofs_per_cell_psi   = system_fe_PSI.dofs_per_cell;

         QGauss<dim> quadrature_formula(degree+2);

         QGauss<dim> quadrature_formula_psi(degree+2);

         FEValues<dim> fe_values_Vh (system_fe_phi, quadrature_formula,
                                  update_values | update_gradients |
                                  update_quadrature_points | update_JxW_values);

         FEValues<dim> fe_values_VH (system_fe_PSI, quadrature_formula,
                                  update_values | update_gradients |
                                  update_quadrature_points | update_JxW_values);




     cout<<"phi degree of free dom "<<dofs_per_cell<<endl;
     cout<<"psi degree of free dom "<<dofs_per_cell_psi<<endl;


     FullMatrix<double>   local_00_matrix(dofs_per_cell, dofs_per_cell),
                          local_11_matrix(dofs_per_cell, dofs_per_cell),
                          local_01_matrix(dofs_per_cell, dofs_per_cell),
                          local_10_matrix(dofs_per_cell, dofs_per_cell),

                          local_transfer_matrix(dofs_per_cell, dofs_per_cell_psi),
                          local_proj_matrix(dofs_per_cell_psi, dofs_per_cell),
                          local_stab_matrix_wK(dofs_per_cell, dofs_per_cell),
                          local_stab_matrix_TMT(dofs_per_cell, dofs_per_cell),
                          local_stab_matrix(dofs_per_cell, dofs_per_cell),


                          M_psi(dofs_per_cell_psi, dofs_per_cell_psi),

                         local_matrix(dofs_per_cell, dofs_per_cell);


    Vector<double>         local_rhs (dofs_per_cell);



   const unsigned int   n_q_points         = quadrature_formula.size();



   const unsigned int   n_q_points_psi  = quadrature_formula_psi.size();

   std::vector<unsigned int> local_dof_indices (dofs_per_cell);


   double component_y_phi_i(dofs_per_cell),
          component_p_phi_i(dofs_per_cell),

          component_y_phi_j(dofs_per_cell),
          component_p_phi_j(dofs_per_cell);



   Tensor<1,dim>    component_y_grad_phi_i  (dofs_per_cell),
                    component_p_grad_phi_i  (dofs_per_cell),

                    component_y_grad_phi_j  (dofs_per_cell),
                    component_p_grad_phi_j  (dofs_per_cell);


   const ConvectionDiffusion::ControlValues<dim> conv_diff_control_values(2);
   std::vector<double> control_values (n_q_points);



   const ConvectionDiffusion::AdvectionField<dim> advection_field;
   std::vector<Tensor<1,dim> > advection_directions (n_q_points);

   cout<<"n_q_points "    <<n_q_points<<endl;
   cout<<"n_q_points_psi "<<n_q_points_psi<<endl;


   typename DoFHandler<dim>::active_cell_iterator
            cell = system_dof_handler_Vh.begin_active(),
            endc = system_dof_handler_Vh.end();

   typename DoFHandler<dim>::active_cell_iterator
            cell_psi = system_dof_handler_VH.begin_active(),
            endc_psi = system_dof_handler_VH.end();


   for (; cell!=endc, cell_psi!=endc_psi; ++cell, ++cell_psi)
     {
       /*Reinitialize the cell */
       fe_values_Vh.reinit (cell);
       fe_values_VH.reinit (cell_psi);


       std::vector<Point<dim>> p_list=fe_values_Vh.get_quadrature_points();
       conv_diff_control_values.value_list (p_list, control_values);

       advection_field.value_list (fe_values_Vh.get_quadrature_points(),advection_directions);


       local_00_matrix  = 0;
       local_11_matrix  = 0;
       local_01_matrix  = 0;
       local_10_matrix  = 0;
       local_matrix     = 0;
       local_rhs=0;



   M_psi=0;

   local_transfer_matrix=0;
   local_proj_matrix=0;
   local_stab_matrix_wK=0;
   local_stab_matrix_TMT=0;
   local_stab_matrix=0;


   double advection_directions_norm=0.0;

  for (unsigned int q=0; q<n_q_points_psi; ++q)
   advection_directions_norm+=advection_directions[q].norm();

   advection_directions_norm /=n_q_points;
   //cout<<"advection direction norm "<< advection_directions_norm<<endl;



   const double C_lps=1.0e4;

   double delta=0;
   /*Tensor<1, dim>  w_star;
   w_star[0] = cell->extent_in_direction(0)/fabs(advection_directions[q][0]);
   w_star[1] = cell->extent_in_direction(1)/fabs(advection_directions[q][1]);
   double h_k =(std::min(w_star[0], w_star[1]));*/

   double h_k =cell->diameter();

   double pe_lps=(h_k*advection_directions_norm)/(EquationData::epsilon);

   if(pe_lps>=1.0)
       delta=C_lps*(h_k)/(advection_directions_norm);
   else
       delta=0;




       for (unsigned int q=0; q<n_q_points; ++q){

           /*creating the matrix
             A=[M  -beta*K
                K        M]
                where M is mass and K is stiffnexx matrix
               */

           double K;
           double N;



           for (unsigned int i=0; i<dofs_per_cell; ++i){
               component_y_phi_i      = fe_values_Vh[component_y].value (i, q);
               component_p_phi_i      = fe_values_Vh[component_p].value (i, q);

               component_y_grad_phi_i = fe_values_Vh[component_y].gradient(i,q);
               component_p_grad_phi_i = fe_values_Vh[component_p].gradient(i,q);



             for (unsigned int j=0; j<dofs_per_cell; ++j)
               {
                 component_y_phi_j      = fe_values_Vh[component_y].value (j, q);
                 component_p_phi_j      = fe_values_Vh[component_p].value (j, q);

                 component_y_grad_phi_j = fe_values_Vh[component_y].gradient(j,q);
                 component_p_grad_phi_j = fe_values_Vh[component_p].gradient(j,q);



                 local_00_matrix(i, j) =(component_y_phi_i * component_y_phi_j)*fe_values_Vh.JxW(q);


                 K=EquationData::epsilon*(component_y_grad_phi_i * component_p_grad_phi_j)*fe_values_Vh.JxW(q);
                 N=((advection_directions[q] * component_y_grad_phi_i)*component_p_phi_j)*fe_values_Vh.JxW(q);
                 local_01_matrix(i, j)=K+N;

                 K=EquationData::epsilon*(component_p_grad_phi_i * component_y_grad_phi_j)*fe_values_Vh.JxW(q);
                 N=((advection_directions[q]*component_p_grad_phi_i)*component_y_phi_j)*fe_values_Vh.JxW(q);

                local_10_matrix(i, j)=K+N;

                local_11_matrix(i, j) =(component_p_phi_i * component_p_phi_j)*fe_values_Vh.JxW(q);


                local_stab_matrix_wK(i, j) += ((advection_directions[q]*fe_values_Vh[component_y].gradient(i, q))*(advection_directions[q]*fe_values_Vh[component_p].gradient(j, q))*fe_values_Vh.JxW (q))+
                                              ((advection_directions[q]*fe_values_Vh[component_p].gradient(i, q))*(advection_directions[q]*fe_values_Vh[component_y].gradient(j, q))*fe_values_Vh.JxW (q));



                 local_matrix(i,j) += local_00_matrix(i, j)+local_01_matrix(i, j)+
                                      local_10_matrix(i, j)+local_11_matrix(i, j);
             }



            /*Creating RHS
             [b
             d] */

             local_rhs(i) +=    component_y_phi_i*
                                control_values [q] *
                                fe_values_Vh.JxW(q);

             for(unsigned l=0;l<dofs_per_cell_psi;l++){
                local_transfer_matrix(i, l)  += (advection_directions[q]*fe_values_Vh[component_y].gradient(i, q))*fe_values_VH[component_p].value(l, q)*fe_values_Vh.JxW (q)+
                                                (advection_directions[q]*fe_values_Vh[component_p].gradient(i, q))*fe_values_VH[component_y].value(l, q)*fe_values_Vh.JxW (q);
            }




           }//end of i

           for(unsigned l=0;l<dofs_per_cell_psi;l++){
                      for(unsigned k=0;k<dofs_per_cell_psi;k++){
                      M_psi(l,k) +=fe_values_VH[component_y].value(l, q)*fe_values_VH[component_p].value(k, q)*fe_values_Vh.JxW (q)+
                                   fe_values_VH[component_p].value(l, q)*fe_values_VH[component_y].value(k, q)*fe_values_Vh.JxW (q);
                      }
                  }
       }

       M_psi.gauss_jordan();

       M_psi.mTmult(local_proj_matrix, local_transfer_matrix);
       local_transfer_matrix.mmult(local_stab_matrix_TMT, local_proj_matrix);

       local_stab_matrix_wK  *= delta;
       local_stab_matrix_TMT *=-delta;

       local_stab_matrix.add( 1.0,local_stab_matrix_wK);
       local_stab_matrix.add( 1.0,local_stab_matrix_TMT);


       local_matrix.add(1.0, local_stab_matrix);

       if(delta>1e-10){
       for (unsigned int i=0; i<dofs_per_cell; ++i){
               for (unsigned int j=0; j<dofs_per_cell; ++j){
                    cout<<local_stab_matrix(i, j)<<" ";
               }
             cout<<endl;
       }
      cout<<endl;
       }


        cell->get_dof_indices (local_dof_indices);
        matrix_constraints.distribute_local_to_global (local_matrix,
                                                          local_rhs,
                                                          local_dof_indices,
                                                          system_matrix,
                                                          system_rhs);

        }







   if(ConvectionDiffusion::p_type==ConvectionDiffusion::PreconditionerType::B_FACTORIZATION ||
      ConvectionDiffusion::p_type==ConvectionDiffusion::PreconditionerType::BD_NORM_BASED   ||
      ConvectionDiffusion::p_type==ConvectionDiffusion::PreconditionerType::BLT_NORM_BASED   ){

       preconditioner_matrix.block(0,0).add(1.0, system_matrix.block(0,0));
       preconditioner_matrix.block(0,1).add(1.0, system_matrix.block(0,0));
       preconditioner_matrix.block(0,1).add(sqrt(EquationData::beta), system_matrix.block(0,1));
       preconditioner_matrix.block(1,0).add(1.0, system_matrix.block(0,0));
       preconditioner_matrix.block(1,0).add(sqrt(EquationData::beta), system_matrix.block(1,0));
}


   if(ConvectionDiffusion::p_type==ConvectionDiffusion::PreconditionerType::BD_SCHUR_BASED ||
           ConvectionDiffusion::p_type==ConvectionDiffusion::PreconditionerType::BLT_SCHUR_BASED)
    {

       preconditioner_matrix.block(0,0).add(1.0, system_matrix.block(0,0));

       preconditioner_matrix.block(0,1).add(1.0/sqrt(EquationData::beta),system_matrix.block(0,0));
       preconditioner_matrix.block(0,1).add(1.0, system_matrix.block(0,1));

       preconditioner_matrix.block(1,0).add(1.0/sqrt(EquationData::beta), system_matrix.block(0,0));
       preconditioner_matrix.block(1,0).add(1.0, system_matrix.block(1,0));

    }




   if(ConvectionDiffusion::p_type==ConvectionDiffusion::PreconditionerType::BD_NORM_BASED   ||
      ConvectionDiffusion::p_type==ConvectionDiffusion::PreconditionerType::BLT_NORM_BASED  ||
      ConvectionDiffusion::p_type==ConvectionDiffusion::PreconditionerType::BD_SCHUR_BASED  ||
      ConvectionDiffusion::p_type==ConvectionDiffusion::PreconditionerType::BLT_SCHUR_BASED )
       system_matrix.block(1, 1) *=-1.0/EquationData::beta;
   else{

       system_matrix.block(0, 1) *= -(EquationData::beta);

   }

     system_matrix.compress(VectorOperation::add);
     preconditioner_matrix.compress(VectorOperation::add);
     system_rhs.compress(VectorOperation::add);

     cout<<"system assembled... "<<endl;

 }





template <int dim>
void OptimalControl<dim>::solve (unsigned int iterations)
{

        /*set the Preconditioner */
    const LinearSolvers::InverseMatrix<TrilinosWrappers::SparseMatrix, TrilinosWrappers::PreconditionChebyshev> m_inverse (preconditioner_matrix.block(0,0),*cb_preconditioner,Iterations::CHEBYCHEV,ToleranceLimits::inner_solver_chb);
    const LinearSolvers::InverseMatrix<TrilinosWrappers::SparseMatrix, TrilinosWrappers::PreconditionAMG> s_inverse_1 (preconditioner_matrix.block(1,0), *amg_preconditioner_1, Iterations::AMG,ToleranceLimits::inner_solver_amg);
    const LinearSolvers::InverseMatrix<TrilinosWrappers::SparseMatrix, TrilinosWrappers::PreconditionAMG> s_inverse_2 (preconditioner_matrix.block(0,1), *amg_preconditioner_2, Iterations::AMG,ToleranceLimits::inner_solver_amg);
    const BlockPreconditioner<TrilinosWrappers::PreconditionAMG, TrilinosWrappers::PreconditionChebyshev> preconditioner (
                system_matrix,
                m_inverse, s_inverse_1, s_inverse_2, n_y);

    double tolerance_level = system_rhs.l2_norm()*ToleranceLimits::outer_solver;

    cout<<"computed tolerence Level is "<<tolerance_level<<endl;

        /*Initialize the SolverControl */
        SolverControl solver_control (iterations, tolerance_level ,false,false);  

        double time=0;

        try{
            if(s==SolverType::FGMRES){
            SolverFGMRES<TrilinosWrappers::BlockVector> fgmres (solver_control);
            timer.restart();
            fgmres.solve(system_matrix, solution_Vh, system_rhs, preconditioner);
            time=timer.wall_time();          
            }else if(s==SolverType::GMRES){
                SolverGMRES<TrilinosWrappers::BlockVector> gmres (solver_control, SolverGMRES<TrilinosWrappers::BlockVector>::AdditionalData(150));
                timer.restart();
                gmres.solve(system_matrix, solution_Vh, system_rhs, preconditioner);
                time=timer.wall_time();
               }

            else if(s==SolverType::MINRES){
             SolverMinRes<TrilinosWrappers::BlockVector> minres (solver_control);
             timer.restart();
             minres.solve(system_matrix, solution_Vh, system_rhs, preconditioner);
             time=timer.wall_time();
            }else {
                cout<<"no iterative solver selected! breaking !!!! "<<endl;
            }
       }catch (std::exception &e){
           Assert(true, ExcMessage(e.what()));
       }
        matrix_constraints.distribute (solution_Vh);
        double KKT_residual = solver_control.last_value();

        cout << "   "
             << KKT_residual
             << " is the final residual"
             << std::endl
             << solver_control.last_step()
             << " GMRES iterations for system."
             << std::endl
             << LinearSolvers::cb_it/(solver_control.last_step()+1)
             << " avg inner chebishev iterations for system."
             << std::endl
             << LinearSolvers::amg_it/(solver_control.last_step()+1)
             << " avg inner amg iterations for system."
             << std::endl
             << LinearSolvers::cg_it/(solver_control.last_step())
             << " avg inner solver iterations for system."
             << std::endl
             << "time "<<time //<<"("<<LinearSolvers::cb_timer_in_sec<<"/"<<LinearSolvers::amg_timer_in_sec<<")"
             << std::endl
             << "done ...."
             << std::endl;


           if(ConvectionDiffusion::p_type==ConvectionDiffusion::PreconditionerType::BD_NORM_BASED){
                cout<<"scaling norm based preconditioner... "<<endl;
                solution_Vh.block(1) *=1.0/(EquationData::beta);

             }
            if(ConvectionDiffusion::p_type==ConvectionDiffusion::PreconditionerType::B_FACTORIZATION){
                 solution_Vh.block(1) *=-1.0;///(EquationData::beta);
                 cout<<"scaling block factorization based preconditioner... "<<endl;
            }
            if(ConvectionDiffusion::p_type==ConvectionDiffusion::PreconditionerType::BD_SCHUR_BASED){
                 solution_Vh.block(1) *=1.0/EquationData::beta;
                 cout<<"scaling block diagonal (Schur based) preconditioner... "<<endl;
            }

            if(ConvectionDiffusion::p_type==ConvectionDiffusion::PreconditionerType::BLT_SCHUR_BASED){
                 solution_Vh.block(1) *=1.0/EquationData::beta;
                 cout<<"scaling block lower triangular (Schur based) preconditioner... "<<endl;
            }

            if(ConvectionDiffusion::p_type==ConvectionDiffusion::PreconditionerType::BLT_NORM_BASED){
                 solution_Vh.block(1) *=1.0/EquationData::beta;
                 cout<<"scaling block lower triangular (Norm based) preconditioner... "<<endl;
            }


            compute_errors (solution_Vh);
            process_solution(table_1, solution_Vh.block(1).linfty_norm(), solver_control.last_step(), KKT_residual, time);


        cb_preconditioner->clear();
        amg_preconditioner_1->clear();
        amg_preconditioner_2->clear();

}

template <int dim>
void OptimalControl<dim>::output_results () const

{
  /*std::ofstream output1;
  output1.open ("M00.txt");
  system_matrix.block(0,0).print(output1);
  output1.close();

  output1.open ("F10.txt");
  system_matrix.block(1,0).print(output1);
  output1.close();

  output1.open ("F01.txt");
  system_matrix.block(0,1).print(output1);
  output1.close();

  output1.open ("M11.txt");
  system_matrix.block(1,1).print(output1);
  output1.close();


  output1.open ("PP.txt");
  preconditioner_matrix.block(1,1).print(output1);
  output1.close();

  output1.open ("v_rhs.txt");
  system_rhs.block(0).print(output1);
  output1.close();

  output1.open ("p_rhs.txt");
  system_rhs.block(1).print(output1);
  output1.close();*/



    std::vector<std::string> solution_names;
    switch (dim)
    {
    case 2:
            solution_names.push_back ("state(y)");
            solution_names.push_back ("control(u)");

     break;
    default:
    Assert (false, ExcNotImplemented());
 }

    DataOut<dim> data_out;
    data_out.attach_dof_handler (system_dof_handler_Vh);
    data_out.add_data_vector (solution_Vh, solution_names);
    data_out.build_patches ();
    std::ostringstream filename;
    filename << "solution-"
           << vtk_tile_name
      //   << Utilities::int_to_string (n_refs, 2)
      //   <<"-"local_restriction_matrix
      //   << (bta)
           <<".vtk";
    std::ofstream output (filename.str().c_str());
    data_out.write_vtk (output);

    output.close();
    data_out.clear();

    MatrixOut matrix_out;
    std::ofstream out ("A.vtk");
    matrix_out.build_patches (system_matrix, "A");
    matrix_out.write_vtk(out);
}



template <int dim>
void OptimalControl<dim>::initialize_preconditioner(){


        cout<<"initializing preconditioners... "<<endl;
        /*Defing the AMG Preconditioner */
        try{
        amg_preconditioner_1 =std_cxx1x::shared_ptr<TrilinosWrappers::PreconditionAMG> (new TrilinosWrappers::PreconditionAMG());
        amg_preconditioner_2 =std_cxx1x::shared_ptr<TrilinosWrappers::PreconditionAMG> (new TrilinosWrappers::PreconditionAMG());

        TrilinosWrappers::PreconditionAMG::AdditionalData Amg_data;
        //Amg_data.elliptic = false;
        Amg_data.smoother_sweeps = 2;
        Amg_data.smoother_type ="block Gauss-Seidel";

        Amg_data.aggregation_threshold = 0.8;

        amg_preconditioner_1->initialize(preconditioner_matrix.block(1,0), Amg_data);
        amg_preconditioner_2->initialize(preconditioner_matrix.block(0,1), Amg_data);

        /*defining IC */
        TrilinosWrappers::PreconditionChebyshev::AdditionalData cb1_data;
        cb1_data.max_eigenvalue=9.0/4.0;
        cb1_data.min_eigenvalue=1.0/4.0;
        cb_preconditioner = std_cxx1x::shared_ptr<TrilinosWrappers::PreconditionChebyshev> (new TrilinosWrappers::PreconditionChebyshev());
        cb_preconditioner->initialize(preconditioner_matrix.block(0,0), cb1_data);
        }
        catch (std::exception &e){
                       Assert(false, ExcMessage(e.what()));
        }
       cout<<"preconditioners initialized... "<<endl;
}

template <int dim>
void OptimalControl<dim>::run ()
{


    int beta_values_length =beta_values.size();
    int refinements_length =refinements.size();

    table_1.clear();
    set_labels();



       for (unsigned int i=0;i<beta_values_length;i++){
           EquationData::beta= double(beta_values[i]);
           for (unsigned int j=0;j<refinements_length;j++){
                n_refs=double(refinements[j]);
                 make_grid_and_dofs (n_refs);

        //  assemble_and_solve_PH();
          assemble_constant_matrix_equation ();
          h = std::pow(0.5, (n_refs));
           cout << "mesh size: " << h<< std::endl<<
                   "number of refinements: " <<n_refs<< std::endl<<
                   "beta: " <<EquationData::beta<< std::endl<<
                    std::endl;
        initialize_preconditioner();
        solve (200);

        output_results ();
        LinearSolvers::cg_it=0;
        LinearSolvers::cb_it=0;
        LinearSolvers::amg_it=0;
        triangulation_VH.clear();
        triangulation_Vh.clear();
     }

  }


  table_1.set_tex_table_caption(tex_table_caption);
  MiscUtilities::print_tex_tables(tex_file_name, s, table_1);
  MiscUtilities::print_table_data (text_table_file_name, beta_values_length, refinements_length, table_data_list);
  table_data_list.clear();

}


template <int dim>
void OptimalControl<dim>::process_solution(TableHandler &table, double l_infinity, unsigned int iterations, double tolerance, double time){

    //Set the text table file
    MiscUtilities::TableData td;
    td.dofs=system_dof_handler_Vh.n_dofs();
    td.beta=EquationData::beta;
    td.iterations=iterations;
    td.m_iterations=LinearSolvers::cb_it/(iterations+1);
    td.k_iterations=LinearSolvers::amg_it/(iterations+1);
    td.time=time;
    table_data_list.push_back(td);


    //Set the table !
    table.add_value("dofs", n_y+n_p);

    table.add_value("ref", n_refs);
    table.add_value("$\\beta$",EquationData::beta);
    table.add_value("$\\widetilde{\\beta}$",EquationData::beta);

    table.add_value("iter",iterations);

    table.add_value("$\\hat{M}$",LinearSolvers::cb_it/(iterations+1));
    table.add_value("$\\hat{S}$",LinearSolvers::amg_it/(iterations+1));
    table.add_value("$|u|_{2}$",u_l2_norm);
    table.add_value("$\|u\|_{\\infty}$",l_infinity);
    table.add_value("$\|y-\\hat{y}\|$",y_yd_l2_norm);
    table.add_value("$\|y-\\hat{y}\|/|\\hat{y}\|$",rel_y_yd_l2_norm);
    table.add_value("$J$",cost_functional_J);
    table.add_value("Tol",tolerance);
    table.add_value("time",time);
}

template <int dim>
void OptimalControl<dim>::compute_errors (TrilinosWrappers::BlockVector e_solution_Vh)
{

    rel_y_yd_l2_norm=0;
    y_yd_l2_norm=0;
    const ComponentSelectFunction<dim> y_mask (0, dim);

    ConvectionDiffusion::ControlValues<dim> desired_solution(dim);
    unsigned int n_cells=triangulation_Vh.n_active_cells();


    Vector<double> cellwise_errors (n_cells);
    QTrapez<1> q_trapez;
    QIterated<dim> quadrature (q_trapez, degree+2);

    //zero_vector = 0;
    VectorTools::integrate_difference (system_dof_handler_Vh,
                                       e_solution_Vh,
                                       desired_solution,
                                       cellwise_errors,
                                       quadrature,
                                       VectorTools::L2_norm,
                                       &y_mask);

    y_yd_l2_norm= cellwise_errors.l2_norm();

    VectorTools::integrate_difference (system_dof_handler_Vh,
                                       zero_vector,
                                       desired_solution,
                                       cellwise_errors,
                                       quadrature,
                                       VectorTools::L2_norm,
                                       &y_mask);


   rel_y_yd_l2_norm =y_yd_l2_norm/cellwise_errors.l2_norm();
   u_l2_norm=e_solution_Vh.block(1).l2_norm();


    cost_functional_J =1.0/2.0*(y_yd_l2_norm*y_yd_l2_norm)+1.0/2.0*EquationData::beta*(u_l2_norm*u_l2_norm);
    cout<<"cost functional J = "<<cost_functional_J<<endl<<
          "||y-yd||       = "<< y_yd_l2_norm<<endl<<
          "||y-yd||/yd    = "<< rel_y_yd_l2_norm<<endl<<
          "||u||          = "<<u_l2_norm<<endl;


}


template <int dim>
void OptimalControl<dim>::set_labels(){


    if(ConvectionDiffusion::p_type==ConvectionDiffusion::PreconditionerType::BD_NORM_BASED){
        std::stringstream ss;
        ss << std::scientific << std::setprecision(1) << EquationData::epsilon;
        string caption ="Problem("+std::to_string(ConvectionDiffusion::solve_problem_type)+"): "+"$P_{nsn}:\\epsilon="+ss.str()+"$";
        tex_table_caption=caption;

        tex_file_name="bd_norm";
        text_table_file_name="block_diagonal_norm";
        vtk_tile_name="BD_NORM";
      }


    if(ConvectionDiffusion::p_type==ConvectionDiffusion::PreconditionerType::BLT_NORM_BASED){
            std::stringstream ss;
            ss << std::scientific << std::setprecision(1) << EquationData::beta;
            string caption ="Problem("+std::to_string(Poisson::solve_problem_type)+"): "+"$P_{nsn}:\\beta="+ss.str()+"$";
            tex_table_caption=caption;

            tex_file_name="blt_norm";
            text_table_file_name="block_lower_triangular_norm";
            vtk_tile_name="BLT_NORM";
          }

    if(ConvectionDiffusion::p_type==ConvectionDiffusion::PreconditionerType::BD_SCHUR_BASED){
        std::stringstream ss;
        ss << std::scientific << std::setprecision(1) << EquationData::epsilon;
        string caption ="Problem("+std::to_string(ConvectionDiffusion::solve_problem_type)+"): "+"$P_{bd}:\\epsilon="+ss.str()+"$";
        tex_table_caption=caption;

        tex_file_name="bd_schur";
        text_table_file_name="bd_schur";
        vtk_tile_name="BD_SCHUR";
    }

    if(ConvectionDiffusion::p_type==ConvectionDiffusion::PreconditionerType::B_FACTORIZATION){

        std::stringstream ss;
        ss << std::scientific << std::setprecision(1) << EquationData::epsilon;
        string caption ="Problem("+std::to_string(ConvectionDiffusion::solve_problem_type)+"): "+"$P_{F}:\\epsilon="+ss.str()+"$";
        tex_table_caption=caption;

        tex_file_name="block_factorization";
        text_table_file_name="block_factorization";
        vtk_tile_name="B_FACTORIZATION";
      }

    if(ConvectionDiffusion::p_type==ConvectionDiffusion::PreconditionerType::BLT_SCHUR_BASED){
        std::stringstream ss;
        ss << std::scientific << std::setprecision(1) << EquationData::epsilon;
        string caption ="Problem("+std::to_string(ConvectionDiffusion::solve_problem_type)+"): "+"$P_{blt}:\\epsilon="+ss.str()+"$";
        tex_table_caption=caption;


        tex_file_name="blt_schur";
        text_table_file_name="blt_schur";
        vtk_tile_name="BLT_SCHUR";
      }
}



template <int dim>
void OptimalControl<dim>::init_parameters(){
   beta_values = {pow(10,-2), pow(10,-3), pow(10,-4), pow(10,-5) , pow(10,-6), pow(10,-7), pow(10,-8), pow(10,-9), pow(10,-10)};
   //beta_values = { pow(10,-5), pow(10,-6), pow(10,-7), pow(10,-8), pow(10,-9), pow(10,-10)};
    //beta_values = {pow(10,-2), pow(10,-3), pow(10,-4), pow(10,-5)};
   refinements =  {4, 5, 6, 7, 8};
    //beta_values = {2.0*pow(10,-3), 2.0*pow(10,-4), 2.0*pow(10,-5),2.0*pow(10,-6)};
    //beta_values = {2*pow(10,-2), 2*pow(10,-3), 2*pow(10,-4), 2*pow(10,-5), 2*pow(10,-6), pow(10,-7), 2*pow(10,-8), 2*pow(10,-9), 2*pow(10,-10)};


    beta_values = {pow(10,-8)};//, pow(10,-3)};
    refinements =  {3};
    //beta_values = {pow(10.0, 0)};
    //ConvectionDiffusion::solve_problem_type=ConvectionDiffusion::Problem_Type::CONST_WIND_1;
    //ConvectionDiffusion::solve_problem_type=ConvectionDiffusion::Problem_Type::CONST_WIND_2;
    ConvectionDiffusion::solve_problem_type=ConvectionDiffusion::Problem_Type::DOUBLE_GLAZING_1;
    total_time.restart();

    //SET PRECONDITIONER TYPE
    total_time.restart();

    s=SolverType::MINRES;
    ConvectionDiffusion::p_type=ConvectionDiffusion::PreconditionerType::BD_SCHUR_BASED;
    run();

    s=SolverType::MINRES;
    ConvectionDiffusion::p_type=ConvectionDiffusion::PreconditionerType::BD_NORM_BASED;
    //run();


    s=SolverType::GMRES;
    ConvectionDiffusion::p_type=ConvectionDiffusion::PreconditionerType::B_FACTORIZATION;
    //run();

    s=SolverType::GMRES;
    ConvectionDiffusion::p_type=ConvectionDiffusion::PreconditionerType::BLT_SCHUR_BASED;
    //run();

    s=SolverType::GMRES;
    ConvectionDiffusion::p_type=ConvectionDiffusion::PreconditionerType::BLT_NORM_BASED;
    //run();

    //MiscUtilities::print_inner_solver_errors();
    cout<<"ALL COMPUTATIONS ENDED "<<total_time.wall_time()/60.0<<endl;


}


int main (int argc, char *argv[])
{
  Utilities::MPI::MPI_InitFinalize mpi_initialization(argc, argv);

  deallog.depth_console(0);
  OptimalControl<2> p_control(1);
  p_control.init_parameters();

  //SET PRECONDITIONER TYPE

  return 0;
}

