#include <deal.II/base/quadrature_lib.h>
#include <deal.II/base/function.h>

#include <deal.II/lac/solver_cg.h>
#include <deal.II/lac/solver_gmres.h>
#include <deal.II/lac/solver_minres.h>
#include <deal.II/lac/constraint_matrix.h>
#include <deal.II/lac/block_sparsity_pattern.h>
#include <deal.II/lac/trilinos_block_vector.h>
#include <deal.II/lac/trilinos_sparse_matrix.h>
#include <deal.II/lac/trilinos_block_sparse_matrix.h>
/*For PreconditionAMG */
#include <deal.II/lac/trilinos_precondition.h>
/*For PreconditionIdentity*/
#include <deal.II/lac/precondition.h>

#include <deal.II/grid/tria.h>
#include <deal.II/grid/grid_generator.h>
#include <deal.II/grid/tria_accessor.h>
#include <deal.II/grid/tria_iterator.h>

#include <deal.II/dofs/dof_handler.h>
#include <deal.II/dofs/dof_renumbering.h>
#include <deal.II/dofs/dof_accessor.h>
#include <deal.II/dofs/dof_tools.h>

#include <deal.II/fe/fe_q.h>
#include <deal.II/fe/fe_system.h>
#include <deal.II/fe/fe_values.h>

/*Vector and Matrix tools */
#include <deal.II/numerics/vector_tools.h>
#include <deal.II/numerics/matrix_tools.h>


#include <fstream>
#include <iostream>
#include <string>
#include <deal.II/numerics/data_out.h>
#include <deal.II/lac/lapack_full_matrix.h>
#include <deal.II/lac/transpose_matrix.h>

/*for iterative inverse*/
#include <deal.II/lac/iterative_inverse.h>

/* For convergence table out put */
#include <deal.II/base/convergence_table.h>
/* The timer class header */
#include <deal.II/base/timer.h>

/*For Tensors */
#include <deal.II/base/tensor_function.h>

#include "../data.hh"
#include "../solver_impl.hh"
#include "../MiscUtilities.hh"


#include <deal.II/lac/sparse_direct.h>
#include <deal.II/lac/sparse_ilu.h>
#include <deal.II/lac/trilinos_solver.h>

namespace EquationData
{
  //double beta;
  double beta;
}




#include <deal.II/base/std_cxx1x/thread.h>

using namespace dealii;

class PointData{
public : double x;
         double y;
         double value;
         unsigned int index;
         PointData(){}

public : friend std::ofstream& operator <<(std::ofstream& os, const PointData& dt);
};
std::ofstream& operator <<(std::ofstream& os, const PointData& dt)
{
     os <<dt.index << ' ' <<  dt.x << ' ' << dt.y << ' '<<'\n';
    return os;
}




////////////////////////linear solver////////////////////////////////////


    template <class PreconditionerA, class PreconditionerB>
    class BlockPreconditioner : public Subscriptor
    {
      public:
        BlockPreconditioner (const TrilinosWrappers::BlockSparseMatrix  &system_matrix,
                             const TrilinosWrappers::BlockSparseMatrix  &S,

                             const LinearSolvers::InverseMatrix<TrilinosWrappers::SparseMatrix, PreconditionerB> &preconditioner_inv_1,


                             const LinearSolvers::InverseMatrix<TrilinosWrappers::SparseMatrix, PreconditionerA> &amg_inv_1,
                             const LinearSolvers::InverseMatrix<TrilinosWrappers::SparseMatrix, PreconditionerA> &amg_inv_2,
                             const int n_v,
                             const int n_p
                             );

        void vmult (TrilinosWrappers::BlockVector &dst,
                    const TrilinosWrappers::BlockVector &src) const;


        void implement_zulehner(TrilinosWrappers::BlockVector &dst, const TrilinosWrappers::BlockVector &src) const;




      private:
        const SmartPointer<const TrilinosWrappers::BlockSparseMatrix> preconditioner_matrix;
        const SmartPointer<const TrilinosWrappers::BlockSparseMatrix> system_matrix;


        const SmartPointer<const LinearSolvers::InverseMatrix<TrilinosWrappers::SparseMatrix, PreconditionerB> > m_inv_1;

        const SmartPointer<const LinearSolvers::InverseMatrix<TrilinosWrappers::SparseMatrix, PreconditionerA> > amg_1;
        const SmartPointer<const LinearSolvers::InverseMatrix<TrilinosWrappers::SparseMatrix, PreconditionerA> > amg_2;



        mutable TrilinosWrappers::Vector v, l, m, p;
        mutable int n_v, n_l, n_m, n_p;
        mutable TrilinosWrappers::Vector g_v1, g_v2, g_p1, g_p2;
        mutable TrilinosWrappers::BlockVector solution_H1, rhs_H1, direct_sol;

    };

    template <class PreconditionerA, class PreconditionerB>
    BlockPreconditioner<PreconditionerA, PreconditionerB>::
    BlockPreconditioner(const TrilinosWrappers::BlockSparseMatrix &_system_matrix,

                        const TrilinosWrappers::BlockSparseMatrix &S,
                        const LinearSolvers::InverseMatrix<TrilinosWrappers::SparseMatrix, PreconditionerB> &_m_inv_1,
                        const LinearSolvers::InverseMatrix<TrilinosWrappers::SparseMatrix, PreconditionerA> &_amg_1,
                        const LinearSolvers::InverseMatrix<TrilinosWrappers::SparseMatrix, PreconditionerA> &_amg_2,
                        int n_v,
                        int n_p)
                    :
                    system_matrix           (&_system_matrix),                    
                    preconditioner_matrix   (&S),
                    m_inv_1                 (&_m_inv_1),
                    amg_1                   (&_amg_1),
                    amg_2                   (&_amg_2),
                    n_v                     (n_v),
                    n_p                     (n_p),
                    g_v1                    (n_v),
                    g_v2                    (n_v),
                    g_p1                    (n_p),
                    g_p2                    (n_p),
                    v                       (n_v),
                    l                       (n_v),
                    m                       (n_p),
                    p                       (n_p)

 {
    rhs_H1.reinit(2);
    rhs_H1.block(0).reinit (n_v);
    rhs_H1.block(1).reinit (n_p);
    rhs_H1.collect_sizes ();

    solution_H1.reinit(2);
    solution_H1.block(0).reinit (n_v);
    solution_H1.block(1).reinit (n_p);
    solution_H1.collect_sizes ();

    direct_sol.reinit(2);
    direct_sol.block(0).reinit (n_v);
    direct_sol.block(1).reinit (n_p);
    direct_sol.collect_sizes ();

 }


    template <class PreconditionerA, class PreconditionerB>
    void BlockPreconditioner<PreconditionerA, PreconditionerB>::vmult (
      TrilinosWrappers::BlockVector &dst,
      const TrilinosWrappers::BlockVector &src) const
    {

          implement_zulehner(dst, src);

    }




    template <class PreconditionerA, class PreconditionerB>
    void BlockPreconditioner<PreconditionerA, PreconditionerB >::implement_zulehner(
                                                                                    TrilinosWrappers::BlockVector &dst,
                                                                                    const TrilinosWrappers::BlockVector &src) const
    {
        v = 0;
        l = 0;

        m = 0;
        p = 0;

        g_v1=0;
        g_v2=0;

        g_p1=0;
        g_p2=0;


        //compute v
        amg_1->vmult(v, src.block(0));

        //compute p
        amg_2->vmult(g_p1,src.block(1));
        m_inv_1->vmult(g_p2, src.block(1));
        g_p2 *=sqrt(EquationData::beta);

        p +=g_p1;
        p +=g_p2;
        p *=1.0/EquationData::beta;


        //compute l
        amg_1->vmult(l,src.block(2));
        l *= EquationData::beta;


        //compute m
        amg_2->vmult(g_p1,src.block(3));
        m_inv_1->vmult(g_p2, src.block(3));
        g_p2 *=sqrt(EquationData::beta);

        m +=g_p1;
        m +=g_p2;

       dst.block(0) = v;
       dst.block(1) = p;

       dst.block(2) = l;
       dst.block(3) = m;

      }










/*The main class*/
template <int dim>
class OptimalControl
{
  public:
    OptimalControl (const unsigned int degree);
    void  init_parameters();
    void run ();

  private:
    void make_grid_and_dofs (const double n_refinement_steps);
    void assemble_constant_matrix_equation();
    void assemble_constant_matrix ();
    void solve();
    void find_coordinates ();
    void construct_diagonal_preconditioner();
    void compute_errors ();
    void output_results() const;
    void output_results_vtk () const;
    void PrintPoints();
    void print_tables();



    void initialize_preconditioner();
    void process_solution(TableHandler &table, unsigned int iterations, double tolerance, double time);
    void checks ();

    dealii::Triangulation<dim>   triangulation;

    FESystem<dim>     system_fe;

    DoFHandler<dim>   system_dof_handler;


    TrilinosWrappers::BlockSparsityPattern sparsity_pattern;

    TrilinosWrappers::BlockSparsityPattern pre_sparsity_pattern;


    double h;
    double n_refs;

    TrilinosWrappers::BlockSparseMatrix system_matrix;

    TrilinosWrappers::BlockSparseMatrix preconditioner_matrix;



    ConstraintMatrix  matrix_constraints;

    ConstraintMatrix  preconditioner_constraints;


    std::vector<types::global_dof_index> system_block_sizes;

    TrilinosWrappers::BlockVector solution;
    TrilinosWrappers::BlockVector system_rhs;




    TrilinosWrappers::BlockVector zero_vector;

    unsigned int n_v;
    unsigned int n_l;
    unsigned int n_p;
    unsigned int n_m;

    const unsigned int degree;

    std::vector<PointData> point_list;

    TableHandler table;

    std_cxx1x::shared_ptr<TrilinosWrappers::PreconditionAMG> amg_preconditioner_1;
    std_cxx1x::shared_ptr<TrilinosWrappers::PreconditionAMG> amg_preconditioner_2;



    std_cxx1x::shared_ptr<TrilinosWrappers::PreconditionChebyshev> cb_preconditioner_1;



    std::vector<double> beta_values;
    std::vector<int> refinements;
    std::vector<double> inner_tolerance;
    Timer timer;
    Timer total_time;
    SolverType s;

    TableHandler table_1;
    TableHandler table_2;

    double u_l2_norm;
    double y_yd_l2_norm;
    double rel_y_yd_l2_norm;
    double cost_functional_J;

};

 template <int dim>
 OptimalControl<dim>::OptimalControl(const unsigned int degree)
        :
        degree(degree),
        triangulation (Triangulation<dim>::none),
        system_fe(FE_Q<dim>(degree+1),2,
                  FE_Q<dim>(degree),  1,
                  FE_Q<dim>(degree+1),2,
                  FE_Q<dim>(degree),  1),
        system_dof_handler(triangulation)

 {

 }

 /////////////////////make_grid_and_dofs////////////////////////////////
template <int dim>
 void OptimalControl<dim>::make_grid_and_dofs (const double n_refinement_steps)
 {

     GridGenerator::hyper_cube (triangulation, 0, 1);
     triangulation.refine_global (n_refinement_steps);

     system_dof_handler.distribute_dofs (system_fe);


     DoFRenumbering::Cuthill_McKee (system_dof_handler);



     std::vector<unsigned int> pde_sub_blocks (6,0);
     pde_sub_blocks[0]=0; //v_i
     pde_sub_blocks[1]=0; //v_j
     pde_sub_blocks[2]=1; //p
     pde_sub_blocks[3]=2; //w_i
     pde_sub_blocks[4]=2; //w_j
     pde_sub_blocks[5]=3; //mu
     DoFRenumbering::component_wise (system_dof_handler, pde_sub_blocks);
     /*The next thing is that we want to figure out the sizes of these blocks,
      so that we can allocate an appropriate amount of space. */
     std::vector<types::global_dof_index> dofs_per_component (4);
     DoFTools::count_dofs_per_component (system_dof_handler, dofs_per_component, true,pde_sub_blocks);
     n_v = dofs_per_component[0];
     n_p = dofs_per_component[1];
     n_l = dofs_per_component[2];
     n_m = dofs_per_component[3];



     cout << "Number of active cells: "
               << triangulation.n_active_cells()
               << std::endl
               << "Total number of degrees of freedom: "
               << system_dof_handler.n_dofs()
               << std::endl
               << "Number of degrees of freedom v: "
               << n_v
               << std::endl
               << "Number of degrees of freedom l: "
               << n_l
               << std::endl
               << "Number of degrees of freedom m: "
               << n_m
               << std::endl
               << "Number of degrees of freedom p: "
               << n_p
               << std::endl
               << "Total degrees: "
               << (n_v+n_l+n_m+n_p)
               << std::endl;




     //Apply Dirichelet to the whole matrix

     for (typename Triangulation<dim>::active_cell_iterator
      cell = triangulation.begin_active();
      cell != triangulation.end(); ++cell)
     for (unsigned int f=0; f<GeometryInfo<dim>::faces_per_cell; ++f)
              if (std::fabs(cell->face(f)->center()(0) - 1) < 1e-12)
                  cell->face(f)->set_boundary_indicator(1);
      /*for (unsigned int f=0; f<GeometryInfo<dim>::faces_per_cell; ++f)
                 if (std::fabs(cell->face(f)->center()(1) - 1) < 1e-12)
                     cell->face(f)->set_boundary_indicator(0);*/


     //CompressedSparsityPattern c(n_p);
     //DoFTools::make_sparsity_pattern(system_dof_handler.)

     const FEValuesExtractors::Vector component_v(0);
     const FEValuesExtractors::Scalar component_p(2);
     const FEValuesExtractors::Vector component_l(3);
     const FEValuesExtractors::Scalar component_m(5);


     cout<<system_fe.component_mask(component_v)<<endl;
     cout<<system_fe.component_mask(component_l)<<endl;



     DoFTools::make_hanging_node_constraints (system_dof_handler, matrix_constraints);



     matrix_constraints.clear ();
     VectorTools::interpolate_boundary_values (system_dof_handler, 1, Stokes::BoundaryValues<dim>(6), matrix_constraints, system_fe.component_mask(component_v));
     VectorTools::interpolate_boundary_values (system_dof_handler, 1, ZeroFunction<dim>(6), matrix_constraints, system_fe.component_mask(component_l));

     VectorTools::interpolate_boundary_values (system_dof_handler, 0, ZeroFunction<dim>(6),  matrix_constraints, system_fe.component_mask(component_v));//
     VectorTools::interpolate_boundary_values (system_dof_handler, 0, ZeroFunction<dim>(6),  matrix_constraints, system_fe.component_mask(component_l));


     matrix_constraints.close ();

     preconditioner_constraints.clear ();
     VectorTools::interpolate_boundary_values (system_dof_handler, 1, Stokes::BoundaryValues<dim>(6), preconditioner_constraints, system_fe.component_mask(component_v));
     VectorTools::interpolate_boundary_values (system_dof_handler, 1, ZeroFunction<dim>(6), preconditioner_constraints, system_fe.component_mask(component_l));
  //  VectorTools::interpolate_boundary_values (system_dof_handler, 1, ZeroFunction<dim>(6), preconditioner_constraints, system_fe.component_mask(component_p));

     VectorTools::interpolate_boundary_values (system_dof_handler,0, ZeroFunction<dim>(6),  preconditioner_constraints, system_fe.component_mask(component_v));
     VectorTools::interpolate_boundary_values (system_dof_handler,0, ZeroFunction<dim>(6),  preconditioner_constraints, system_fe.component_mask(component_l));
     //VectorTools::interpolate_boundary_values (system_dof_handler,0, ZeroFunction<dim>(6),  preconditioner_constraints, system_fe.component_mask(component_m));
     //VectorTools::interpolate_boundary_values (system_dof_handler,0, ZeroFunction<dim>(6),  preconditioner_constraints, system_fe.component_mask(component_p));
     preconditioner_constraints.close ();


     /*Sparsity Pattern for the System Matrix */
     {
     system_matrix.clear ();
     sparsity_pattern.reinit (4,4);
     const unsigned int n_couplings = system_dof_handler.max_couplings_between_dofs();
     sparsity_pattern.block(0,0).reinit (n_v, n_v, n_couplings);
     sparsity_pattern.block(1,0).reinit (n_p, n_v, n_couplings);
     sparsity_pattern.block(2,0).reinit (n_l, n_v, n_couplings);
     sparsity_pattern.block(3,0).reinit (n_m, n_v, n_couplings);

     sparsity_pattern.block(0,1).reinit (n_v, n_p, n_couplings);
     sparsity_pattern.block(1,1).reinit (n_p, n_p, n_couplings);
     sparsity_pattern.block(2,1).reinit (n_l, n_p, n_couplings);
     sparsity_pattern.block(3,1).reinit (n_m, n_p, n_couplings);

     sparsity_pattern.block(0,2).reinit (n_v, n_l, n_couplings);
     sparsity_pattern.block(1,2).reinit (n_p, n_l, n_couplings);
     sparsity_pattern.block(2,2).reinit (n_l, n_l, n_couplings);
     sparsity_pattern.block(3,2).reinit (n_m, n_l, n_couplings);

     sparsity_pattern.block(0,3).reinit (n_v, n_m, n_couplings);
     sparsity_pattern.block(1,3).reinit (n_p, n_m, n_couplings);
     sparsity_pattern.block(2,3).reinit (n_l, n_m, n_couplings);
     sparsity_pattern.block(3,3).reinit (n_m, n_m, n_couplings);


     sparsity_pattern.collect_sizes();  //what is this for? yes, needed when we touch each block separately!,

     DoFTools::make_sparsity_pattern (system_dof_handler,
                       sparsity_pattern,
                       matrix_constraints,
                       true);
      sparsity_pattern.compress();
      system_matrix.reinit (sparsity_pattern);

     }





     //Sparsity Pattern for the Preconditioner Matrix */
     {
     preconditioner_matrix.clear ();
     pre_sparsity_pattern.reinit (4,4);
     const unsigned int n_couplings = system_dof_handler.max_couplings_between_dofs();

     pre_sparsity_pattern.block(0,0).reinit (n_v, n_v, n_couplings);
     pre_sparsity_pattern.block(1,0).reinit (n_p, n_v, n_couplings);
     pre_sparsity_pattern.block(2,0).reinit (n_l, n_v, n_couplings);
     pre_sparsity_pattern.block(3,0).reinit (n_m, n_v, n_couplings);

     pre_sparsity_pattern.block(0,1).reinit (n_v, n_p, n_couplings);
     pre_sparsity_pattern.block(1,1).reinit (n_p, n_p, n_couplings);
     pre_sparsity_pattern.block(2,1).reinit (n_l, n_p, n_couplings);
     pre_sparsity_pattern.block(3,1).reinit (n_m, n_p, n_couplings);

     pre_sparsity_pattern.block(0,2).reinit (n_v, n_l, n_couplings);
     pre_sparsity_pattern.block(1,2).reinit (n_p, n_l, n_couplings);
     pre_sparsity_pattern.block(2,2).reinit (n_l, n_l, n_couplings);
     pre_sparsity_pattern.block(3,2).reinit (n_m, n_l, n_couplings);

     pre_sparsity_pattern.block(0,3).reinit (n_v, n_m, n_couplings);
     pre_sparsity_pattern.block(1,3).reinit (n_p, n_m, n_couplings);
     pre_sparsity_pattern.block(2,3).reinit (n_l, n_m, n_couplings);
     pre_sparsity_pattern.block(3,3).reinit (n_m, n_m, n_couplings);
     pre_sparsity_pattern.collect_sizes();  //what is this for? yes, needed when we touch each block separately!,

     DoFTools::make_sparsity_pattern (system_dof_handler,
                       pre_sparsity_pattern,
                       preconditioner_constraints,
                       true);

      pre_sparsity_pattern.compress();
      preconditioner_matrix.reinit(pre_sparsity_pattern);
  }



       solution.reinit (4);
       solution.block(0).reinit (n_v);
       solution.block(1).reinit (n_p);
       solution.block(2).reinit (n_l);
       solution.block(3).reinit (n_m);
       solution.collect_sizes ();

       system_rhs.reinit (4);
       system_rhs.block(0).reinit (n_v);
       system_rhs.block(1).reinit (n_p);
       system_rhs.block(2).reinit (n_l);
       system_rhs.block(3).reinit (n_m);
       system_rhs.collect_sizes ();

       zero_vector.reinit (4);
       zero_vector.block(0).reinit (n_v);
       zero_vector.block(1).reinit (n_p);
       zero_vector.block(2).reinit (n_l);
       zero_vector.block(3).reinit (n_m);
       zero_vector.collect_sizes ();
       zero_vector=0;



   cout<<"dofs initialized ..."<<endl;
 }


 /////////////////////assemble_constant_matrix(K,M)///////////////
 template <int dim>
 void OptimalControl<dim>::assemble_constant_matrix_equation ()
 {

     system_matrix= 0;
     preconditioner_matrix= 0;
     system_rhs = 0;



     const FEValuesExtractors::Vector component_v(0);
     const FEValuesExtractors::Scalar component_p(2);
     const FEValuesExtractors::Vector component_l(3);
     const FEValuesExtractors::Scalar component_m(5);


     const unsigned int   dofs_per_cell   = system_fe.dofs_per_cell;


     FullMatrix<double>   local_00_MM_matrix(dofs_per_cell, dofs_per_cell),
                          local_02_FF_matrix(dofs_per_cell, dofs_per_cell),
                          local_03_DD_matrix(dofs_per_cell, dofs_per_cell),

                          local_12_DD_matrix(dofs_per_cell, dofs_per_cell),

                          local_20_FF_matrix(dofs_per_cell, dofs_per_cell),
                          local_21_DD_matrix(dofs_per_cell, dofs_per_cell),
                          local_22_MM_matrix(dofs_per_cell, dofs_per_cell),

                          local_30_DD_matrix(dofs_per_cell, dofs_per_cell),

                          local_02_MpF_amg_matrix(dofs_per_cell, dofs_per_cell),
                           local_11_FF_pre_matrix(dofs_per_cell, dofs_per_cell),
                           local_33_MM_pre_matrix(dofs_per_cell, dofs_per_cell),

                          local_13_MM_pre_matrix(dofs_per_cell, dofs_per_cell),
                          local_22_MFF_pre_matrix(dofs_per_cell, dofs_per_cell),
                          local_23_DD_pre_matrix(dofs_per_cell, dofs_per_cell),
                          local_32_DD_pre_matrix(dofs_per_cell, dofs_per_cell);



     FullMatrix<double>   local_matrix(dofs_per_cell, dofs_per_cell),

                          local_pre_matrix(dofs_per_cell, dofs_per_cell);



    Vector<double>         local_rhs (dofs_per_cell);

    QGauss<dim>   quadrature_formula (degree+2);
    FEValues<dim> fe_values (system_fe, quadrature_formula,
                                        update_values    | update_gradients | update_quadrature_points |
                                        update_JxW_values);

   const unsigned int   n_q_points      = quadrature_formula.size();

   std::vector<unsigned int> local_dof_indices (dofs_per_cell);


   Tensor<1,dim>
                 component_v_phi_i(dofs_per_cell),
                 component_l_phi_i(dofs_per_cell),

                 component_v_phi_j(dofs_per_cell),
                 component_l_phi_j(dofs_per_cell);


   double  component_p_phi_i(dofs_per_cell),
           component_m_phi_i(dofs_per_cell),
           component_p_phi_j(dofs_per_cell),
           component_m_phi_j(dofs_per_cell);

   double
             component_v_div_phi_i  (dofs_per_cell),
             component_l_div_phi_i  (dofs_per_cell),

             component_v_div_phi_j  (dofs_per_cell),
             component_l_div_phi_j  (dofs_per_cell);


   Tensor<1,dim> component_p_grad_phi_i (dofs_per_cell),
                 component_m_grad_phi_i (dofs_per_cell),
                 component_p_grad_phi_j (dofs_per_cell),
                 component_m_grad_phi_j (dofs_per_cell);


   Tensor<2,dim>
                          component_v_grad_phi_i,
                          component_l_grad_phi_i,
                          component_v_grad_phi_j,
                          component_l_grad_phi_j;



   const Stokes::VelocityFieldControlValues<dim> velocity_field_control(6);


   std::vector< Tensor<1, dim> >  velocity_field_control_values( n_q_points, Tensor<1, dim> ());

   cout<<"n_q_points "<<n_q_points<<endl;

   typename DoFHandler<dim>::active_cell_iterator
   cell = system_dof_handler.begin_active(),
   endc = system_dof_handler.end();

   for (; cell!=endc; ++cell)
     {
       /*Reinitialize the cell */
       fe_values.reinit (cell);

       std::vector<Point<dim>> p_list=fe_values.get_quadrature_points();
       velocity_field_control.vector_value_list (p_list, velocity_field_control_values);



       local_00_MM_matrix = 0;
       local_02_FF_matrix = 0;
       local_03_DD_matrix = 0;
       local_12_DD_matrix = 0;
       local_20_FF_matrix = 0;
       local_21_DD_matrix = 0;
       local_22_MM_matrix = 0;
       local_30_DD_matrix = 0;


       local_02_MpF_amg_matrix = 0;
       local_11_FF_pre_matrix  = 0;
       local_33_MM_pre_matrix  = 0;

       local_11_FF_pre_matrix  = 0;
       local_13_MM_pre_matrix  = 0;
       local_22_MFF_pre_matrix = 0;
       local_23_DD_pre_matrix  = 0;
       local_32_DD_pre_matrix  = 0;

       local_matrix     = 0;
       local_pre_matrix = 0;

       local_rhs=0;

       for (unsigned int q=0; q<n_q_points; ++q){

           /*creating the matrix
             A=[M  0  K
                0 BM -M
                K -M  0
                where M is mass and K is stiffnexx matrix
               */

           for (unsigned int i=0; i<dofs_per_cell; ++i){


               component_v_phi_i      = fe_values[component_v].value (i, q);
               component_l_phi_i      = fe_values[component_l].value (i, q);
               component_m_phi_i      = fe_values[component_m].value (i, q);
               component_p_phi_i      = fe_values[component_p].value (i, q);



               component_v_div_phi_i  = fe_values[component_v].divergence(i,q);
               component_l_div_phi_i  = fe_values[component_l].divergence(i,q);
               component_m_grad_phi_i = fe_values[component_m].gradient(i,q);
               component_p_grad_phi_i = fe_values[component_p].gradient(i,q);

               component_v_grad_phi_i = fe_values[component_v].gradient(i,q);
               component_l_grad_phi_i = fe_values[component_l].gradient(i,q);


             for (unsigned int j=0; j<dofs_per_cell; ++j)
               {

                 component_v_phi_j      = fe_values[component_v].value (j, q);
                 component_l_phi_j      = fe_values[component_l].value (j, q);
                 component_m_phi_j      = fe_values[component_m].value (j, q);
                 component_p_phi_j      = fe_values[component_p].value (j, q);



                 component_v_div_phi_j  = fe_values[component_v].divergence(j,q);
                 component_l_div_phi_j  = fe_values[component_l].divergence(j,q);
                 component_m_grad_phi_j = fe_values[component_m].gradient(j,q);
                 component_p_grad_phi_j = fe_values[component_p].gradient(j,q);




                 component_v_grad_phi_j = fe_values[component_v].gradient(j,q);
                 component_l_grad_phi_j = fe_values[component_l].gradient(j,q);


                 local_00_MM_matrix(i, j)  =    (component_v_phi_i * component_v_phi_j)*fe_values.JxW(q);
                 local_02_FF_matrix(i, j)  =    scalar_product(component_v_grad_phi_i,  component_l_grad_phi_j)*fe_values.JxW(q);
                 local_03_DD_matrix(i, j)  =   -(component_v_div_phi_i*component_m_phi_j)*fe_values.JxW(q);


                 local_12_DD_matrix(i, j)  =   -(component_p_phi_i*component_l_div_phi_j)*fe_values.JxW(q);


                 local_20_FF_matrix(i, j) =   scalar_product(component_l_grad_phi_i,  component_v_grad_phi_j)*fe_values.JxW(q);
                 local_21_DD_matrix(i, j) =  -(component_l_div_phi_i*component_p_phi_j)*fe_values.JxW(q);

                 local_22_MM_matrix(i, j) =   -1.0/EquationData::beta*(component_l_phi_i*component_l_phi_j)*fe_values.JxW(q);


                 local_30_DD_matrix(i, j) =  -(component_m_phi_i*component_v_div_phi_j)*fe_values.JxW(q);



                 ////////

                 local_11_FF_pre_matrix(i, j)   = (component_p_grad_phi_i * component_p_grad_phi_j)*fe_values.JxW(q);
                 local_33_MM_pre_matrix(i, j)   = (component_m_phi_i * component_m_phi_j)*fe_values.JxW(q);
                 local_22_MFF_pre_matrix(i, j)  = (component_l_phi_i*component_l_phi_j+sqrt(EquationData::beta)*scalar_product(component_l_grad_phi_i, component_l_grad_phi_j))*fe_values.JxW(q);


                // cout<<"here we are "<<endl;

                 local_matrix(i,j) += local_00_MM_matrix(i, j)+local_02_FF_matrix(i, j)+local_03_DD_matrix(i, j)+
                                                               local_12_DD_matrix(i, j)+
                                      local_20_FF_matrix(i, j)+local_21_DD_matrix(i, j)+local_22_MM_matrix(i, j)+
                                      local_30_DD_matrix(i, j);


                 local_pre_matrix(i,j) += local_00_MM_matrix(i, j)+
                                          local_11_FF_pre_matrix(i, j)+
                                          local_22_MFF_pre_matrix(i, j)+
                                          local_33_MM_pre_matrix(i, j);

             }


            /*Creating RHS
             [v
              p
              u
              l
              m] where d=0*/

            local_rhs(i) +=
                            velocity_field_control_values[q]*
                            component_v_phi_i*

                             fe_values.JxW(q);

           }


       }
           cell->get_dof_indices (local_dof_indices);
           matrix_constraints.distribute_local_to_global (local_matrix,
                                                          local_rhs,
                                                          local_dof_indices,
                                                          system_matrix,
                                                          system_rhs);






           preconditioner_constraints.distribute_local_to_global (local_pre_matrix,
                                                          local_dof_indices,
                                                          preconditioner_matrix
                                                          );




     }



 // sub_matrix_H1.block(0,0).add(1.0, preconditioner_matrix.block(2,2));
 // sub_matrix_H1.block(0,1).add(1.0, system_matrix.block(0,3));
 // sub_matrix_H1.block(1,0).add(1.0, system_matrix.block(3,0));



     //system_matrix.block(0, 3) *=-1.0;
     //system_matrix.block(0, 2) *=-1.0;
     //system_matrix.block(1, 2) *=-1.0;

     //system_matrix.block(2, 2) *=-1.0/EquationData::beta;

     //system_rhs.block(0) *=EquationData::beta;
     //system_rhs.block(1) *=EquationData::beta;

     system_matrix.compress(VectorOperation::add);
     preconditioner_matrix.compress(VectorOperation::add);


     system_rhs.compress(VectorOperation::add);


     cout<<"System Assembled .... "<<system_rhs.block(1).l2_norm()<<endl;



 }

template <int dim>
void OptimalControl<dim>::solve ()
{

        /*set the Preconditioner */
        const LinearSolvers::InverseMatrix<TrilinosWrappers::SparseMatrix, TrilinosWrappers::PreconditionAMG> k_inverse_1 (preconditioner_matrix.block(2,2),*amg_preconditioner_1, Iterations::AMG,ToleranceLimits::inner_solver);
        const LinearSolvers::InverseMatrix<TrilinosWrappers::SparseMatrix, TrilinosWrappers::PreconditionAMG> k_inverse_2 (preconditioner_matrix.block(1,1),*amg_preconditioner_2, Iterations::AMG,ToleranceLimits::inner_solver);


        const LinearSolvers::InverseMatrix<TrilinosWrappers::SparseMatrix, TrilinosWrappers::PreconditionChebyshev> Mp_inverse_1 (preconditioner_matrix.block(3,3),*cb_preconditioner_1, Iterations::CHEBYCHEV,ToleranceLimits::inner_solver);




        const BlockPreconditioner<TrilinosWrappers::
                PreconditionAMG, TrilinosWrappers::PreconditionChebyshev> preconditioner (system_matrix,
                                                                                          preconditioner_matrix,
                                                                                          Mp_inverse_1,
                                                                                          k_inverse_1,
                                                                                          k_inverse_2,
                                                                                          n_v, n_p);





        double tolerance_level = system_rhs.l2_norm()*ToleranceLimits::outer_solver;

        cout<<"computed tolerence Level is "<<tolerance_level<<endl
                 <<"norm of RHS "<<system_rhs.l2_norm()<<endl;
        /*Initialize the SolverControl */
        SolverControl solver_control (5000, tolerance_level ,false,false);

        SolverGMRES<TrilinosWrappers::BlockVector>::AdditionalData ad;
        ad.compute_eigenvalues=true;

        SolverFGMRES<TrilinosWrappers::BlockVector> fgmres (solver_control);//, ad);

        SolverMinRes<TrilinosWrappers::BlockVector> minres (solver_control);

        cout<<"y norm "<<system_rhs.block(0).l2_norm()<<endl<<
              "p norm "<<system_rhs.block(1).l2_norm()<<endl;

        solution = 0;
        double time=0;



        try{

            if(s==SolverType::GMRES){
            timer.restart();

            fgmres.solve(system_matrix , solution, system_rhs, preconditioner);
           // fgmres.solve(system_matrix , solution, system_rhs, PreconditionIdentity());
            time=timer.wall_time();
            }else{
                timer.restart();
                minres.solve(system_matrix, solution, system_rhs, preconditioner);
                time=timer.wall_time();
            }

            cout<<"FGMRES ... done "<<endl;


            matrix_constraints.distribute (solution.block(0));
           // solution.block(0) *=1.0/EquationData::beta;
           // solution.block(1) *=1.0/EquationData::beta;
           solution.block(2) *=1.0/EquationData::beta;
           // solution.block(3) *=1.0/EquationData::beta;

       }catch (std::exception &e){
           Assert(true, ExcMessage(e.what()));
       }

        cout << "   "

             << solver_control.last_step() //<<"("<<LinearSolvers::cb_it<<"/"<<LinearSolvers::amg_it<<")"
             << " GMRES iterations for system."
             << std::endl
             << LinearSolvers::cb_it/solver_control.last_step()
             << " avg inner chebishev iterations for system."
             << std::endl
             << LinearSolvers::amg_it/solver_control.last_step()
             << " avg inner amg iterations for system."
             << std::endl
             << LinearSolvers::cg_it/solver_control.last_step()
             << " avg inner solver iterations for system."
             << std::endl
             << "time "<<time //<<"("<<LinearSolvers::cb_timer_in_sec<<"/"<<LinearSolvers::amg_timer_in_sec<<")"
             << std::endl
             << "done ...."
             << std::endl;


        /*if(p_type==PreconditionerType::P5_PEARSON_POISSON_BLOCK_DIAGONAL)
           process_solution(table_1, solver_control.last_step(), tolerance_level, time);
        if(p_type==PreconditionerType::P7_PEARSON_POISSON_BLOCK_LOWER_TRIANGULAR)
           process_solution(table_2, solver_control.last_step(), h, time);*/



}









    template <int dim>
    void OptimalControl<dim>::output_results_vtk () const
    {
        std::vector<std::string> solution_names;
        solution_names.push_back ("vi");
        solution_names.push_back ("vj");
        solution_names.push_back ("p");
        solution_names.push_back ("li");
        solution_names.push_back ("lj");

        solution_names.push_back ("m");


        std::vector<DataComponentInterpretation::DataComponentInterpretation> data_component_interpretation;

        data_component_interpretation.push_back (DataComponentInterpretation::component_is_part_of_vector);
        data_component_interpretation.push_back (DataComponentInterpretation::component_is_part_of_vector);
        data_component_interpretation.push_back (DataComponentInterpretation::component_is_scalar);
        data_component_interpretation.push_back (DataComponentInterpretation::component_is_part_of_vector);
        data_component_interpretation.push_back (DataComponentInterpretation::component_is_part_of_vector);

        data_component_interpretation.push_back (DataComponentInterpretation::component_is_scalar);


        DataOut<dim> data_out;
        data_out.attach_dof_handler (system_dof_handler);
        data_out.add_data_vector (solution, solution_names,
                                  DataOut<dim>::type_dof_data,
                                  data_component_interpretation);
        data_out.build_patches ();
        std::ostringstream filename;
        filename << "solution"
                 << ".vtk";
        std::ofstream output (filename.str().c_str());
        data_out.write_vtk (output);



    }






template <int dim>
void OptimalControl<dim>::initialize_preconditioner(){
        /*Defing the AMG Preconditioner */
    TrilinosWrappers::PreconditionAMG::AdditionalData Amg_data_1;
    TrilinosWrappers::PreconditionAMG::AdditionalData Amg_data_2;

    std::vector<std::vector<bool> > constant_modes;
    FEValuesExtractors::Vector velocity_components(0);
    DoFTools::extract_constant_modes (system_dof_handler,
    system_fe.component_mask(velocity_components), constant_modes);


    Amg_data_1.elliptic = true;

    Amg_data_1.higher_order_elements = true;
    Amg_data_1.smoother_sweeps = 2;
    //Amg_data_1.n_cycles = 2;
    //Amg_data_1.w_cycle = true;
    Amg_data_1.smoother_type = "symmetric Gauss-Seidel";
    Amg_data_1.coarse_type = "symmetric Gauss-Seidel";
   // Amg_data_1.constant_modes=constant_modes;
    Amg_data_1.aggregation_threshold = 0.8;


    Amg_data_2.elliptic = true;
    Amg_data_2.smoother_sweeps = 2;

    Amg_data_2.smoother_type = "symmetric Gauss-Seidel";
    //Amg_data_2.coarse_type = "symmetric Gauss-Seidel";
    Amg_data_2.coarse_type = "Jacobi";
    Amg_data_2.aggregation_threshold = 0.8;
    //Amg_data_2.n_cycles=2;
    //Amg_data_2.w_cycle = true;

    amg_preconditioner_1 = std_cxx1x::shared_ptr<TrilinosWrappers::PreconditionAMG> (new TrilinosWrappers::PreconditionAMG());
    amg_preconditioner_1->initialize(preconditioner_matrix.block(2,2), Amg_data_1);

    amg_preconditioner_2 = std_cxx1x::shared_ptr<TrilinosWrappers::PreconditionAMG> (new TrilinosWrappers::PreconditionAMG());
    amg_preconditioner_2->initialize(preconditioner_matrix.block(1,1), Amg_data_2);



    /*defining IC */
    cb_preconditioner_1 = std_cxx1x::shared_ptr<TrilinosWrappers::PreconditionChebyshev> (new TrilinosWrappers::PreconditionChebyshev());
    cb_preconditioner_1->initialize(preconditioner_matrix.block(3,3));


}

template <int dim>
void OptimalControl<dim>::run ()
{


    int beta_values_length =beta_values.size();
    //int inner_tolerance_length =inner_tolerance.size();
    int refinements_length =refinements.size();

    for (unsigned int i=0;i<beta_values_length;i++)
  //for (unsigned int i=0;i<inner_tolerance_length;i++)
        for (unsigned int j=0;j<refinements_length;j++){

        n_refs=double(refinements[j]);
        EquationData::beta= double(beta_values[i]);
        //TolerenceLimits::inner_solver=double(inner_tolerance[i]);

        h = std::pow(0.5, (n_refs));
        cout << "mesh size: " << h<< std::endl<<
                "number of refinements: " <<n_refs<< std::endl<<
                "beta: " <<EquationData::beta<< std::endl<<
                "inner tolerance: " <<ToleranceLimits::inner_solver<< std::endl;

     make_grid_and_dofs (n_refs);
     assemble_constant_matrix_equation ();

     initialize_preconditioner();
     solve ();


     output_results_vtk ();

     triangulation.clear();
     LinearSolvers::cg_it=0;
     }


}


template <int dim>
void OptimalControl<dim>::process_solution(TableHandler &table, unsigned int iterations, double tolerance, double time){

    table.add_value("dofs", n_v+n_l+n_m+n_p);
    table.add_value("ref", n_refs);
    table.add_value("$\\beta$",EquationData::beta);

    table.add_value("iter",iterations);
    table.add_value("$\\hat{M}$",LinearSolvers::cb_it/iterations);
    table.add_value("$\\hat{S}$",LinearSolvers::amg_it/iterations);
    table.add_value("$|u|$",u_l2_norm);
    table.add_value("$\|y-\\hat{y}\|$",y_yd_l2_norm);
    table.add_value("$\|y-\\hat{y}\|/|\\hat{y}\|$",rel_y_yd_l2_norm);
    table.add_value("$J$",cost_functional_J);
    table.add_value("Tol",tolerance);
    table.add_value("time",time);

}

template <int dim>
void OptimalControl<dim>::print_tables()
{

    std::string gmv_filename;
    gmv_filename = "tolerance-solution";

    switch (system_fe.degree)
    {
    case 1:
        gmv_filename += "-q1";
        break;
        case 2:
        gmv_filename += "-q2";
        break;
        default:
        Assert (false, ExcNotImplemented());
    }

     if(s==SolverType::GMRES)
         gmv_filename += "-fgmres-p7";
     else
         gmv_filename += "-minres-p5";

     gmv_filename += ".tex";

     table.set_precision("h", 2);
     table.set_precision("beta",0 );
     table.set_precision("inner tolerance",0);
     table.set_precision("time",3 );

     table.set_scientific("h", true);
     table.set_scientific("beta", true);
     table.set_scientific("inner tolerance",true);


     std::cout << std::endl;
     table.write_text(std::cout);


     std::ofstream table_file(gmv_filename.c_str());
     table.write_tex(table_file);


  }

template <int dim>
void OptimalControl<dim>::compute_errors ()
{
    //const ComponentSelectFunction<dim> y_mask (0, 6);
    const ComponentSelectFunction<dim> y_mask(std::make_pair(0, dim));
    Poisson::ControlValues<dim> desired_solution(6);
    unsigned int n_cells=triangulation.n_active_cells();
    Vector<double> cellwise_errors (n_cells);
    QTrapez<1> q_trapez;
    //QGauss<dim-1> q_trapez(degree+1);
    QIterated<dim> quadrature (q_trapez, degree+2);

    VectorTools::integrate_difference (system_dof_handler,
                                       solution,
                                       desired_solution,
                                       cellwise_errors,
                                       quadrature,
                                       VectorTools::L2_norm,
                                       &y_mask);
    y_yd_l2_norm= cellwise_errors.l2_norm();

    VectorTools::integrate_difference (system_dof_handler,
                                       zero_vector,
                                       desired_solution,
                                       cellwise_errors,
                                       quadrature,
                                       VectorTools::L2_norm,
                                       &y_mask);



   rel_y_yd_l2_norm =y_yd_l2_norm/cellwise_errors.l2_norm();
   u_l2_norm=solution.block(1).l2_norm();


    cost_functional_J =0.5*(y_yd_l2_norm*y_yd_l2_norm)+0.5*EquationData::beta*(u_l2_norm*u_l2_norm);
    cout<<"cost functional J = "<<cost_functional_J<<endl<<
          "||y-yd||       = "<< y_yd_l2_norm<<endl<<
          "||y-yd||/yd    = "<< rel_y_yd_l2_norm<<endl<<
          "||u||          = "<<u_l2_norm<<endl;

}

template <int dim>
void OptimalControl<dim>::init_parameters(){
    //beta_values = {pow(10,-2), pow(10,-3), pow(10,-4), pow(10,-5), pow(10,-6), pow(10,-7), pow(10,-8), pow(10,-9), pow(10,-10)};
    //refinements =  {4, 5, 6, 7, 8};
    beta_values = {pow(10, -10)};
    //beta_values = {2*pow(10,-2), 2*pow(10,-3), 2*pow(10,-4), 2*pow(10,-5), 2*pow(10,-6), pow(10,-7), 2*pow(10,-8), 2*pow(10,-9), 2*pow(10,-10)};
    refinements =  {4};

    total_time.restart();

    //SET PRECONDITIONER TYPE

    //SET SOLVER TYPES
   //s=SolverType::MINRES;

   s=SolverType::GMRES;
    run ();

    //cout<<"using Block Diagonal preconditioner... "<<endl;

    //p_type=PreconditionerType::P5_PEARSON_POISSON_BLOCK_DIAGONAL;
    //run ();

    //cout<<"ALL COMPUTATIONS ENDED "<<total_time.wall_time()/60.0<<endl;

}

int main (int argc, char *argv[])
{
  Utilities::MPI::MPI_InitFinalize mpi_initialization(argc, argv);
  std::ofstream logfile("deallog");
  deallog.attach(logfile);
  deallog.depth_console(1);

  //deallog.depth_console(0);
  OptimalControl<2> p_control(1);
  p_control.init_parameters();

  return 0;
}

