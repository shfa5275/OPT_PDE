#include <deal.II/base/quadrature_lib.h>
#include <deal.II/base/function.h>

#include <deal.II/lac/solver_cg.h>
#include <deal.II/lac/solver_gmres.h>
#include <deal.II/lac/solver_minres.h>
#include <deal.II/lac/constraint_matrix.h>
#include <deal.II/lac/block_sparsity_pattern.h>
#include <deal.II/lac/trilinos_block_vector.h>
#include <deal.II/lac/trilinos_sparse_matrix.h>
#include <deal.II/lac/trilinos_block_sparse_matrix.h>
/*For PreconditionAMG */
#include <deal.II/lac/trilinos_precondition.h>
/*For PreconditionIdentity*/
#include <deal.II/lac/precondition.h>

#include <deal.II/grid/tria.h>
#include <deal.II/grid/grid_generator.h>
#include <deal.II/grid/tria_accessor.h>
#include <deal.II/grid/tria_iterator.h>

#include <deal.II/dofs/dof_handler.h>
#include <deal.II/dofs/dof_renumbering.h>
#include <deal.II/dofs/dof_accessor.h>
#include <deal.II/dofs/dof_tools.h>

#include <deal.II/fe/fe_q.h>
#include <deal.II/fe/fe_system.h>
#include <deal.II/fe/fe_values.h>

/*Vector and Matrix tools */
#include <deal.II/numerics/vector_tools.h>
#include <deal.II/numerics/matrix_tools.h>


#include <fstream>
#include <iostream>
#include <string>
#include <deal.II/numerics/data_out.h>
#include <deal.II/lac/lapack_full_matrix.h>
#include <deal.II/lac/transpose_matrix.h>

/*for iterative inverse*/
#include <deal.II/lac/iterative_inverse.h>

/* For convergence table out put */
#include <deal.II/base/convergence_table.h>
/* The timer class header */
#include <deal.II/base/timer.h>

/*For Tensors */
#include <deal.II/base/tensor_function.h>



#include <deal.II/base/std_cxx1x/thread.h>

template <class Matrix, class Preconditioner>
class InverseMatrixI : public Subscriptor
{
public:
InverseMatrixI (const Matrix &m,
const Preconditioner &preconditioner);

void vmult (TrilinosWrappers::Vector &dst,
            const TrilinosWrappers::Vector &src) const;

private:
const SmartPointer<const Matrix> matrix;
const SmartPointer<const Preconditioner> preconditioner;
};
template <class Matrix, class Preconditioner>
InverseMatrixI<Matrix,Preconditioner>::InverseMatrixI (const Matrix &m,
const Preconditioner &preconditioner)
:
matrix (&m),
preconditioner (&preconditioner)
{


}

template <class Matrix, class Preconditioner>
void InverseMatrixI<Matrix,Preconditioner>::vmult (TrilinosWrappers::Vector &dst,
                                                   const TrilinosWrappers::Vector &src) const
{


SolverControl solver_control (src.size(), 1.0e-4*src.l2_norm());
SolverFGMRES<TrilinosWrappers::Vector> cg (solver_control);
dst = 0;

cg.solve (*matrix, dst, src, *preconditioner);

}



template <class Preconditioner>
class SchurComplement : public Subscriptor
{
public:
SchurComplement (const TrilinosWrappers::BlockSparseMatrix &system_matrix, const InverseMatrixI<TrilinosWrappers::SparseMatrix, Preconditioner> &A_inverse);
void vmult (TrilinosWrappers::BlockVector &dst,
const TrilinosWrappers::BlockVector &src) const;
private:
const SmartPointer<const TrilinosWrappers::BlockSparseMatrix > system_matrix;
const SmartPointer<const InverseMatrixI<TrilinosWrappers::SparseMatrix, Preconditioner> > A_inverse;
mutable TrilinosWrappers::Vector tmp0, tmp1, tmp2;


};
template <class Preconditioner>
SchurComplement<Preconditioner>::
SchurComplement (const TrilinosWrappers::BlockSparseMatrix &system_matrix,

const InverseMatrixI<TrilinosWrappers::SparseMatrix,Preconditioner> &A_inverse)
:
system_matrix (&system_matrix),
A_inverse (&A_inverse),
tmp0 (system_matrix.block(0,0).m()),
tmp1 (system_matrix.block(0,0).m()),
tmp2 (system_matrix.block(0,0).m())
{}
template <class Preconditioner>
void SchurComplement<Preconditioner>::vmult (TrilinosWrappers::BlockVector &dst,
const TrilinosWrappers::BlockVector &src) const
{
A_inverse->vmult (dst.block(0), src.block(0));

//cout<<"inv "<<endl;
system_matrix->block(0,1).vmult (tmp1, src.block(1));
A_inverse->vmult (tmp2, tmp1);
system_matrix->block(1,0).vmult (dst.block(1), tmp2);
}
/////////////////////////////////////////////////////////////////


/*class SchurComplement : public Subscriptor
{
public:
SchurComplement (const TrilinosWrappers::BlockSparseMatrix &A, const TrilinosWrappers::BlockSparseMatrix &block_A_matrix, const IterativeInverse<TrilinosWrappers::BlockVector > &A_inverse);
void vmult (TrilinosWrappers::BlockVector &dst, const TrilinosWrappers::BlockVector &src) const;
private:
const SmartPointer<const TrilinosWrappers::BlockSparseMatrix > system_matrix;
const SmartPointer<const TrilinosWrappers::BlockSparseMatrix > block_A_matrix;
const SmartPointer<const IterativeInverse<TrilinosWrappers::BlockVector> > A_inverse;

};
SchurComplement::SchurComplement (const TrilinosWrappers::BlockSparseMatrix &A, const TrilinosWrappers::BlockSparseMatrix &block_A_matrix, const IterativeInverse<TrilinosWrappers::BlockVector> &_A_inverse)
:
 system_matrix (&A),
 block_A_matrix (&block_A_matrix),
 A_inverse (&_A_inverse)
{}
void SchurComplement::vmult (TrilinosWrappers::BlockVector &dst, const TrilinosWrappers::BlockVector& src) const
{
    unsigned int n_v=system_matrix->block(0,0).m();
    //unsigned int n_p=system_matrix->block(3,3).m();
    TrilinosWrappers::BlockVector tmp1, tmp2;
    tmp1.reinit (2);
    tmp1.block(0).reinit (n_v);
    tmp1.block(1).reinit (n_v);
    tmp1.collect_sizes ();

    tmp2.reinit (2);
    tmp2.block(0).reinit (n_v);
    tmp2.block(1).reinit (n_v);
    tmp2.collect_sizes ();

    tmp1=0;
    tmp2=0;

    cout<<"here I am "<<endl;

    //system_matrix->block(0,3).vmult (tmp1.block(0), src.block(0));
    //system_matrix->block(0,3).vmult (tmp1.block(1), src.block(1));
   // A_inverse->vmult (tmp2, tmp1);
    tmp1.block(0)= src.block(0);
    tmp1.block(1)= src.block(1);



    double tolerance_level = 0.1;//tmp1.l2_norm()*ToleranceLimits::outer_solver;


    SolverControl solver_control (n_v, tolerance_level ,false,false);
    SolverFGMRES<TrilinosWrappers::BlockVector> fgmres (solver_control);


    try{
        fgmres.solve(*block_A_matrix, tmp2, tmp1, PreconditionIdentity());
        cout<<"solver last step "<<solver_control.last_step()<<endl;
    }catch (std::exception &e){
        Assert(false, ExcMessage(e.what()));
    }

    //system_matrix->block(3,0).vmult (dst.block(0), tmp2.block(0));
    //system_matrix->block(3,0).vmult (dst.block(1), tmp2.block(1));
    tmp2.block(0)= tmp1.block(0);
    tmp2.block(1)= tmp1.block(1);


}
*/

/*template <class PreconditionerA, class PreconditionerB>
class SchurComplement : public Subscriptor
{
  public:
    SchurComplement(const TrilinosWrappers::BlockSparseMatrix  &S,
                         const LinearSolvers::InverseMatrix<TrilinosWrappers::SparseMatrix, PreconditionerB> &preconditioner_inv_1,
                         const LinearSolvers::InverseMatrix<TrilinosWrappers::SparseMatrix, PreconditionerB> &preconditioner_inv_2,

                         const LinearSolvers::InverseMatrix<TrilinosWrappers::SparseMatrix, PreconditionerA> &amg_inv_1,
                         const LinearSolvers::InverseMatrix<TrilinosWrappers::SparseMatrix, PreconditionerA> &amg_inv_2,
                         const LinearSolvers::InverseMatrix<TrilinosWrappers::SparseMatrix, PreconditionerA> &amg_inv_3,
                         const int n_v,
                         const int n_p
                         );

    void vmult (TrilinosWrappers::BlockVector &dst,
                const TrilinosWrappers::BlockVector &src) const;

    void implement_schur_approx(TrilinosWrappers::BlockVector &dst, const TrilinosWrappers::BlockVector &src) const;




  private:
    const SmartPointer<const TrilinosWrappers::BlockSparseMatrix> preconditioner_matrix;
    const SmartPointer<const LinearSolvers::InverseMatrix<TrilinosWrappers::SparseMatrix, PreconditionerB> > m_inv_1;
    const SmartPointer<const LinearSolvers::InverseMatrix<TrilinosWrappers::SparseMatrix, PreconditionerB> > m_inv_2;
    const SmartPointer<const LinearSolvers::InverseMatrix<TrilinosWrappers::SparseMatrix, PreconditionerA> > amg_1;
    const SmartPointer<const LinearSolvers::InverseMatrix<TrilinosWrappers::SparseMatrix, PreconditionerA> > amg_2;
    const SmartPointer<const LinearSolvers::InverseMatrix<TrilinosWrappers::SparseMatrix, PreconditionerA> > amg_3;

    mutable TrilinosWrappers::Vector v, l, m, p;
    mutable int n_v, n_l, n_m, n_p;
    mutable TrilinosWrappers::Vector g_v1, g_v2, g_p1, g_p2;





};

template <class PreconditionerA, class PreconditionerB>
SchurComplement <PreconditionerA, PreconditionerB>::
SchurComplement (const TrilinosWrappers::BlockSparseMatrix  &S,
                    const LinearSolvers::InverseMatrix<TrilinosWrappers::SparseMatrix, PreconditionerB> &_m_inv_1,
                    const LinearSolvers::InverseMatrix<TrilinosWrappers::SparseMatrix, PreconditionerB> &_m_inv_2,
                    const LinearSolvers::InverseMatrix<TrilinosWrappers::SparseMatrix, PreconditionerA> &_amg_1,
                    const LinearSolvers::InverseMatrix<TrilinosWrappers::SparseMatrix, PreconditionerA> &_amg_2,
                    const LinearSolvers::InverseMatrix<TrilinosWrappers::SparseMatrix, PreconditionerA> &_amg_3,
                    int n_v,
                    int n_p)
                :
                preconditioner_matrix   (&S),
                m_inv_1                 (&_m_inv_1),
                m_inv_2                 (&_m_inv_2),
                amg_1                   (&_amg_1),
                amg_2                   (&_amg_2),
                amg_3                   (&_amg_3),
                n_v                     (n_v),
                n_p                     (n_p),
                g_v1                    (n_v),
                g_v2                    (n_v),
                g_p1                    (n_p),
                g_p2                    (n_p),
                v                       (n_v),
                l                       (n_v),
                m                       (n_p),
                p                       (n_p)

{}


template <class PreconditionerA, class PreconditionerB>
void SchurComplement<PreconditionerA, PreconditionerB >::vmult (
  TrilinosWrappers::BlockVector &dst,
  const TrilinosWrappers::BlockVector &src) const
{


        implement_schur_approx(dst, src);


}

    template <class PreconditionerA, class PreconditionerB>
    void SchurComplement<PreconditionerA, PreconditionerB >::implement_schur_approx(
                                                                                    TrilinosWrappers::BlockVector &dst,
                                                                                    const TrilinosWrappers::BlockVector &src) const
    {


        v = 0;
        l = 0;

        m = 0;
        p = 0;

        g_v1=0;
        g_v2=0;

        g_p1=0;
        g_p2=0;


        //compute p
        preconditioner_matrix->block(0,3).vmult (g_v1, src.block(0));
        preconditioner_matrix->block(0,3).vmult (g_v2, src.block(1));
        cout<<"Bv done ... "<<endl;


        amg_2->vmult(v, g_v1);
        preconditioner_matrix->block(3,0).vmult (p, v);
        p *=1.0/EquationData::beta;

        amg_2->vmult(l, g_v2);
        preconditioner_matrix->block(3,0).vmult (m, l);


        dst.block(0) = p;
        dst.block(1) = m;

   }


*/
template <class PreconditionerA, class PreconditionerB>
class BlockStokesControlShurApprox : public Subscriptor
{
  public:
    BlockStokesControlShurApprox (const TrilinosWrappers::BlockSparseMatrix  &S,
                         const LinearSolvers::InverseMatrix<TrilinosWrappers::SparseMatrix, PreconditionerB> &preconditioner_inv_1,
                         const LinearSolvers::InverseMatrix<TrilinosWrappers::SparseMatrix, PreconditionerB> &preconditioner_inv_2,

                         const LinearSolvers::InverseMatrix<TrilinosWrappers::SparseMatrix, PreconditionerA> &amg_inv_1,
                         const LinearSolvers::InverseMatrix<TrilinosWrappers::SparseMatrix, PreconditionerA> &amg_inv_2,
                         const LinearSolvers::InverseMatrix<TrilinosWrappers::SparseMatrix, PreconditionerA> &amg_inv_3,
                         const int n_v,
                         const int n_p
                         );

    void vmult (TrilinosWrappers::BlockVector &dst,
                const TrilinosWrappers::BlockVector &src) const;

    void implement_schur_approx(TrilinosWrappers::BlockVector &dst, const TrilinosWrappers::BlockVector &src) const;
    void implement_zulhener_schur_approx(TrilinosWrappers::BlockVector &dst, const TrilinosWrappers::BlockVector &src) const;
    void implement_zulhener_schur_exact(TrilinosWrappers::BlockVector &dst, const TrilinosWrappers::BlockVector &src) const;
     void implement_zulhener_schur_prec(TrilinosWrappers::BlockVector &dst, const TrilinosWrappers::BlockVector &src) const;



  private:
    const SmartPointer<const TrilinosWrappers::BlockSparseMatrix> preconditioner_matrix;
    const SmartPointer<const LinearSolvers::InverseMatrix<TrilinosWrappers::SparseMatrix, PreconditionerB> > m_inv_1;
    const SmartPointer<const LinearSolvers::InverseMatrix<TrilinosWrappers::SparseMatrix, PreconditionerB> > m_inv_2;
    const SmartPointer<const LinearSolvers::InverseMatrix<TrilinosWrappers::SparseMatrix, PreconditionerA> > amg_1;
    const SmartPointer<const LinearSolvers::InverseMatrix<TrilinosWrappers::SparseMatrix, PreconditionerA> > amg_2;
    const SmartPointer<const LinearSolvers::InverseMatrix<TrilinosWrappers::SparseMatrix, PreconditionerA> > amg_3;

    mutable TrilinosWrappers::Vector v, l, m, p;
    mutable int n_v, n_l, n_m, n_p;
    mutable TrilinosWrappers::Vector g_v1, g_v2, g_p1, g_p2;

    /*std_cxx1x::shared_ptr<TrilinosWrappers::PreconditionAMG> amg_preconditioner_1;
    std_cxx1x::shared_ptr<TrilinosWrappers::PreconditionAMG> amg_preconditioner_2;
    std_cxx1x::shared_ptr<TrilinosWrappers::PreconditionAMG> amg_preconditioner_3;


    std_cxx1x::shared_ptr<TrilinosWrappers::PreconditionChebyshev> cb_preconditioner_1;
    std_cxx1x::shared_ptr<TrilinosWrappers::PreconditionChebyshev> cb_preconditioner_2;*/



};

template <class PreconditionerA, class PreconditionerB>
BlockStokesControlShurApprox <PreconditionerA, PreconditionerB>::
BlockStokesControlShurApprox (const TrilinosWrappers::BlockSparseMatrix  &S,
                    const LinearSolvers::InverseMatrix<TrilinosWrappers::SparseMatrix, PreconditionerB> &_m_inv_1,
                    const LinearSolvers::InverseMatrix<TrilinosWrappers::SparseMatrix, PreconditionerB> &_m_inv_2,
                    const LinearSolvers::InverseMatrix<TrilinosWrappers::SparseMatrix, PreconditionerA> &_amg_1,
                    const LinearSolvers::InverseMatrix<TrilinosWrappers::SparseMatrix, PreconditionerA> &_amg_2,
                    const LinearSolvers::InverseMatrix<TrilinosWrappers::SparseMatrix, PreconditionerA> &_amg_3,
                    int n_v,
                    int n_p)
                :
                preconditioner_matrix   (&S),
                m_inv_1                 (&_m_inv_1),
                m_inv_2                 (&_m_inv_2),
                amg_1                   (&_amg_1),
                amg_2                   (&_amg_2),
                amg_3                   (&_amg_3),
                n_v                     (n_v),
                n_p                     (n_p),
                g_v1                    (n_v),
                g_v2                    (n_v),
                g_p1                    (n_p),
                g_p2                    (n_p),
                v                       (n_v),
                l                       (n_v),
                m                       (n_p),
                p                       (n_p)

{}


template <class PreconditionerA, class PreconditionerB>
void BlockStokesControlShurApprox<PreconditionerA, PreconditionerB >::vmult (
  TrilinosWrappers::BlockVector &dst,
  const TrilinosWrappers::BlockVector &src) const
{

   // if(p_type==PreconditionerType::P1_STOKES_NON_STANDARD_NORM)
      //  implement_zulhener_schur_approx(dst, src);
         //implement_zulhener_schur_exact(dst, src);
       // implement_zulhener_schur_prec(dst, src);


//    else
    implement_schur_approx(dst, src) ;

}

    template <class PreconditionerA, class PreconditionerB>
    void BlockStokesControlShurApprox<PreconditionerA, PreconditionerB >::implement_schur_approx(
                                                                                    TrilinosWrappers::BlockVector &dst,
                                                                                    const TrilinosWrappers::BlockVector &src) const
    {


        v = 0;
        l = 0;

        m = 0;
        p = 0;

        g_v1=0;
        g_v2=0;

        g_p1=0;
        g_p2=0;






        double zeps=1.0/sqrt(EquationData::beta);


        TrilinosWrappers::Vector q(n_p);
        TrilinosWrappers::Vector z(n_p);
        TrilinosWrappers::Vector s(n_p);
        TrilinosWrappers::Vector r(n_p);
        TrilinosWrappers::Vector w(n_v);
        TrilinosWrappers::Vector t(n_v);
        TrilinosWrappers::Vector g_p3(n_p);
        TrilinosWrappers::Vector g_p4(n_p);
        TrilinosWrappers::Vector z_1(n_p);
        TrilinosWrappers::Vector z_2(n_p);
        TrilinosWrappers::Vector z_3(n_p);
        g_p3=0;
        g_p4=0;
        z_1=0;
        z_2=0;
        z_3=0;



        preconditioner_matrix->block(0,3).vmult (g_v1, src.block(0));
        preconditioner_matrix->block(1,2).vmult (g_v2, src.block(1));

        g_v2 *= zeps;

        q =g_v1;
        q+=g_v2;
        //z=H_1q
        amg_2->vmult (z, q);

        cout<<"here we are amg 1x "<<endl;
        //w=Mz
        preconditioner_matrix->block(0,0).vmult (w, z);
        s =w;
        s-=g_v2;
        amg_2->vmult (r, s);

        cout<<"here we are amg 2 "<<endl;
        //r=H_2s
        preconditioner_matrix->block(2,1).vmult (p, r);

        //dst.block(0) = p;
        t  = z;
        t -= r;

        preconditioner_matrix->block(3,0).vmult (m, t);
        m  *= 1/zeps;
        dst.block(0) =p;
        dst.block(1) =m;

        cout<<"the destination norm is : "<<dst.l2_norm()<<endl;


   }

    template <class PreconditionerA, class PreconditionerB>
    void BlockStokesControlShurApprox<PreconditionerA, PreconditionerB >::implement_zulhener_schur_approx(
                                                                                    TrilinosWrappers::BlockVector &dst,
                                                                                    const TrilinosWrappers::BlockVector &src) const
    {
        v = 0;
        l = 0;

        m = 0;
        p = 0;

        g_v1=0;
        g_v2=0;

        g_p1=0;
        g_p2=0;


        //compute p
        amg_3->vmult(g_p1,src.block(0));
        m_inv_2->vmult(g_p2, src.block(0));
        g_p2 *=sqrt(EquationData::beta);

        cout<<"pressure calculated..., "<<endl;

        p +=g_p1;
        p +=g_p2;
        p *=1.0/EquationData::beta;

        //compute m
        amg_3->vmult(g_p1,src.block(1));
        m_inv_2->vmult(g_p2, src.block(1));
        g_p2 *=sqrt(EquationData::beta);
        cout<<"pressure adjoint calculated..., "<<endl;
        m +=g_p1;
        m +=g_p2;

        dst.block(0) = p;
        dst.block(1) = m;



 }

    template <class PreconditionerA, class PreconditionerB>
    void BlockStokesControlShurApprox<PreconditionerA, PreconditionerB >::implement_zulhener_schur_exact(
                                                                                    TrilinosWrappers::BlockVector &dst,
                                                                                    const TrilinosWrappers::BlockVector &src) const
    {
        v = 0;
        l = 0;

        m = 0;
        p = 0;

        g_v1=0;
        g_v2=0;

        g_p1=0;
        g_p2=0;

        //compute p
        preconditioner_matrix->block(0,3).vmult (g_v1, src.block(0));
        preconditioner_matrix->block(0,3).vmult (g_v2, src.block(1));
        cout<<"Bv done ... "<<endl;


        amg_2->vmult(v, g_v1);
        preconditioner_matrix->block(3,0).vmult (p, v);
        p *=1.0/EquationData::beta;

        amg_2->vmult(l, g_v2);
        preconditioner_matrix->block(3,0).vmult (m, l);


        dst.block(0) = p;
        dst.block(1) = m;


        dst.block(0) = p;
        dst.block(1) = m;

 }

    template <class PreconditionerA, class PreconditionerB>
    void BlockStokesControlShurApprox<PreconditionerA, PreconditionerB >::implement_zulhener_schur_prec(
                                                                                    TrilinosWrappers::BlockVector &dst,
                                                                                    const TrilinosWrappers::BlockVector &src) const
    {
        v = 0;
        l = 0;

        m = 0;
        p = 0;

        g_v1=0;
        g_v2=0;

        g_p1=0;
        g_p2=0;



        //compute p
        amg_3->vmult(g_p1,src.block(0));
        m_inv_2->vmult(g_p2, src.block(1));
        g_p2 *=sqrt(EquationData::beta);

        p +=g_p1;
        p +=g_p2;
        p *=1.0/EquationData::beta;

        //compute m
        amg_3->vmult(g_p1,src.block(0));
        m_inv_2->vmult(g_p2, src.block(1));
        g_p2 *=sqrt(EquationData::beta);

        m +=g_p1;
        m +=g_p2;


        dst.block(0) = p;
        dst.block(1) = m;



    }
