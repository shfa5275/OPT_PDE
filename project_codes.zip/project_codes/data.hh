
#include <deal.II/base/function.h>

#include <fstream>
#include <iostream>
#include <string>
/*For Tensors */
#include <deal.II/base/tensor_function.h>

using namespace dealii;


namespace ConvectionDiffusion{

enum PreconditionerType{
    BD_NORM_BASED     =1,
    BD_SCHUR_BASED    =2,
    B_FACTORIZATION   =3,
    BLT_SCHUR_BASED   =4
};
PreconditionerType p_type;


enum Problem_Type{

    CONST_WIND_1=1,
    CONST_WIND_2=2,
    CONST_WIND_3=3,
    DOUBLE_GLAZING_1=4

};
  Problem_Type solve_problem_type;


    template <int dim>
    class BoundaryValues : public Function<dim>
    {
    public:
        BoundaryValues(const unsigned int components) : Function<dim>(components) {}
        virtual double value (const Point<dim> &p, const unsigned int component) const;
    };

    template <int dim>
    double BoundaryValues<dim>::value (const Point<dim> &p,
                                       const unsigned int component) const
    {

        double x=p[0];
        double y=p[1];

        if(ConvectionDiffusion::solve_problem_type==ConvectionDiffusion::Problem_Type::DOUBLE_GLAZING_1){
            if(component==0)
            return 1.0;
        }
         else if(ConvectionDiffusion::solve_problem_type==ConvectionDiffusion::Problem_Type::CONST_WIND_1){
                if(component==0)
                    return (2.0*x-1.0)*(2*x-1.0)*(2.0*y-1.0)*(2.0*y-1.0);
            }
        else if(ConvectionDiffusion::solve_problem_type==ConvectionDiffusion::Problem_Type::CONST_WIND_2){
               //if(component==0)
                   return 1.0;
           }
        else if(ConvectionDiffusion::solve_problem_type==ConvectionDiffusion::Problem_Type::CONST_WIND_3){
               if(component==0)
               return (std::sin(x) + std::sin(y));
           }

       return 0;
    }


template <int dim>
class ControlValues : public Function<dim>
{
public:
ControlValues(const unsigned int components) : Function<dim>(components) {}
virtual double value (const Point<dim> &p, const unsigned int component) const;

};
template <int dim>

    double ControlValues<dim>::value (const Point<dim> &p, const unsigned int /*n_components*/) const
    {

        double x=p[0];
        double y=p[1];
        if(ConvectionDiffusion::solve_problem_type==ConvectionDiffusion::Problem_Type::DOUBLE_GLAZING_1){
            return 0.0;
        }
         else if(ConvectionDiffusion::solve_problem_type==ConvectionDiffusion::Problem_Type::CONST_WIND_1){
          if((x<=0.50) && (y<=0.50))
                return (2.0*x-1.0)*(2*x-1.0)*(2.0*y-1.0)*(2.0*y-1.0);
            }

        else if(ConvectionDiffusion::solve_problem_type==ConvectionDiffusion::Problem_Type::CONST_WIND_2){
         //if((x<=0.0) && (y<=0.0))
               return 0.0;


        }

        else if(ConvectionDiffusion::solve_problem_type==ConvectionDiffusion::Problem_Type::CONST_WIND_3){
        return (std::cos(x) + std::cos(y) + std::sin(x) + std::sin(y));
        }

        return 0;
    }

    template <int dim>
    class AdvectionField : public TensorFunction<1,dim>
    {
    public:
    AdvectionField () : TensorFunction<1,dim> () {}
    virtual Tensor<1,dim> value (const Point<dim> &p) const;
    virtual void value_list (const std::vector<Point<dim> > &points,
    std::vector<Tensor<1,dim> > &values) const;
    DeclException2 (ExcDimensionMismatch,
    unsigned int, unsigned int,
    << "The vector has size " << arg1 << " but should have "
    << arg2 << " elements.");
    };
    template <int dim>
    Tensor<1,dim> AdvectionField<dim>::value (const Point<dim> &p) const
    {
        Point<dim> value;
        double x=p[0];
        double y=p[1];


        if(ConvectionDiffusion::solve_problem_type==ConvectionDiffusion::Problem_Type::DOUBLE_GLAZING_1){
          //  value[0]=     1.0/sqrt(2.0)*y*(1.0-x*x);
          //  value[1]=    -1.0/sqrt(2.0)*x*(1.0-y*y);
           value[0]=    1.0/2.0*y*(1.0-x*x);
           value[1]=   -1.0/2.0*x*(1.0-y*y);
            //value[0]=    1.0/2.0*y*(1.0-x*x);
            //value[1]=   -1.0/2.0*x*(1.0-y*y);

         //  value[0]=    1.0;
         //  value[1]=    0.0;
        }
         else if(ConvectionDiffusion::solve_problem_type==ConvectionDiffusion::Problem_Type::CONST_WIND_1){
            double theta=numbers::PI/4.0;
             //value[0]=  1.0/sqrt(2)*std::cos(theta);
             //value[1]=  1.0/sqrt(2)*std::sin(theta);
            //value[0]=   1.0/(2.0)*y*(1.0-x*x);
            //value[1]=   1.0/(2.0)*x*(1.0-y*y);
             //value[0]=     1.0/2.0*std::sin(theta);
             //value[1]=     1.0/2.0*std::cos(theta);
            // value[0]=    std::sin(theta);
            // value[1]=    std::cos(theta);

            value[0]=    -std::cos(theta);
            value[1]=     std::sin(theta);

            }
        else if(ConvectionDiffusion::solve_problem_type==ConvectionDiffusion::Problem_Type::CONST_WIND_2){

           // value[0]=     2.0*1.0/sqrt(2.0);//std::cos(theta);
           // value[1]=    -2.0*1.0/sqrt(2.0);//std::sin(theta);

           // value[0]=    1.0/(2.0)*y*(1.0-x*x);
           // value[1]=   -1.0/(2.0)*x*(1.0-y*y);
           // value[0]=     -std::cos(theta);
           // value[1]=      std::sin(theta);
            value[0]=    1.0;
            value[1]=     0;
           } else if(ConvectionDiffusion::solve_problem_type==ConvectionDiffusion::Problem_Type::CONST_WIND_3){
              value[0]= 1.0;
              value[1]= 1.0;
            }


        return value;
    }
    template <int dim>
    void AdvectionField<dim>::value_list (const std::vector<Point<dim> > &points,
    std::vector<Tensor<1,dim> > &values) const
    {
        Assert (values.size() == points.size(),
        ExcDimensionMismatch (values.size(), points.size()));
        for (unsigned int i=0; i<points.size(); ++i)
        values[i] = AdvectionField<dim>::value (points[i]);
}



    /*template <int dim>
    class ExactSolution : public Function<dim>
    {
    public:
    ExactSolution(const unsigned int components) : Function<dim> (components) {}

    virtual void vector_value (const Point<dim> &p, Vector<double> &value) const;

    };

    template <int dim>
    void
    ExactSolution<dim>::vector_value (const Point<dim> &p, Vector<double> &values) const
    {

    if(solve_problem_type==Problem_Type::CONST_WIND_3){
        double x =p[0];
        double y =p[1];

    values[0]=std::sin(x) + std::sin(y);
    }

    }*/



}

//The POISSON ConreolProblem//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

namespace Poisson{

enum PreconditionerType{
    BD_NORM_BASED     =1,
    BD_SCHUR_BASED    =2,
    B_FACTORIZATION   =3,
    BLT_SCHUR_BASED   =4,
    BLT_NORM_BASED    =5
};

PreconditionerType p_type;


enum Problem_Type{

    HEAT_FLOW_1=1,
    HEAT_FLOW_2=2,

};
  Problem_Type solve_problem_type;

    template <int dim>
    class BoundaryValues : public Function<dim>
    {

    public:
        BoundaryValues(const unsigned int _components) : Function<dim>(_components) {}
        virtual double value (const Point<dim> &p, const unsigned int component) const;
    };

    template <int dim>
    double BoundaryValues<dim>::value (const Point<dim> &p,
                                       const unsigned int component) const
    {

        double x=p[0];
        double y=p[1];
        double value;

         if(solve_problem_type==Problem_Type::HEAT_FLOW_1){
                if(component==0){
                value  =(2.0*x-1.0)*(2.0*x-1.0)*(2.0*y-1.0)*(2.0*y-1.0);
                return value;
                }
         }

         if(solve_problem_type==Problem_Type::HEAT_FLOW_2){
             if(component==0){
                return 1.0;
             }
    }
     return 0;
    }


template <int dim>
class ControlValues : public Function<dim>
{
public:
ControlValues(const unsigned int components) : Function<dim>(components) {}
virtual double value (const Point<dim> &p, const unsigned int component) const;

};
template <int dim>
double ControlValues<dim>::value (const Point<dim> &p, const unsigned int /*n_components*/) const
    {

        double x=p[0];
        double y=p[1];

        if(solve_problem_type==Problem_Type::HEAT_FLOW_1){
         if((p[0])<=0.50 && (p[1])<=0.50)
               return (2*x-1)*(2*x-1)*(2*y-1)*(2*y-1);
        }

        if(solve_problem_type==Problem_Type::HEAT_FLOW_2){
         if((p[0])<=0.50 && (p[1])<=0.50)
               return 1.0;
        }
        else return 0;
    }

}
enum Stabilization_Scheme {
    LPS  =1,
    SUPG =2
};

Stabilization_Scheme stbl_scheme;

namespace Stokes{

enum PreconditionerType{
    BD_NORM_BASED     =1,
    BD_SCHUR_BASED    =2,
    B_FACTORIZATION   =3,
    BLT_SCHUR_BASED   =4,
    BLT_NORM_BASED    =5
};
PreconditionerType p_type;


enum Problem_Type{

    VELOCITY_TRACKING_1=0,
    LID_DRIVEN_CAVITY  =1,
    VELOCITY_TRACKING_2=2

};
  Problem_Type solve_problem_type;
template <int dim>
class BoundaryValues : public Function<dim>
{
public:
     BoundaryValues(const unsigned int _components) : Function<dim>(_components) {}
    virtual double value (const Point<dim> &p,
                          const unsigned int component) const;
    virtual void vector_value (const Point<dim> &p,
                               Vector<double> &value) const;


};
template <int dim>
double BoundaryValues<dim>::value (const Point<dim> &p,
                            const unsigned int component) const
{
    Assert (component < this->n_components,
            ExcIndexRange (component, 0, this->n_components));

    double x=p[0];
    double y=p[1];
    Point<dim> value;

    //1
    /*if((x<0 && y>0) && (x<0 && y<=1)){
        value[0]=-(0.5-y)*x*(1.0+x);
        value[1]= (0.5+x)*y*(1.0-y);

    }
    //2
    else if((x>0 && y>0) && (x<=1 && y<=1)){
        value[0]=-(0.5-y)*x*(1.0-x);
        value[1]= (0.5-x)*y*(1.0-y);
    }

    if((x<0 && y<0) && (x>=-1 && y>=-1)){
        value[0]=-(0.5+y)*x*(1.0+x);
        value[1]= (0.5+x)*y*(1.0+y);
    }
    if((x>0 && y<0) && (x<=1 && y>=-1)){
        value[0]=-(0.5+y)*x*(1.0-x);
        value[1]= (0.5-x)*y*(1.0+y);
    }*/

 if(solve_problem_type==Problem_Type::VELOCITY_TRACKING_1) {
     return 0.0;
 }else if(solve_problem_type==Problem_Type::LID_DRIVEN_CAVITY) {
     if (component==1) {
        return  -1.0;
      }
       return 0.0;
     }




    return 0;
}
template <int dim>
void
BoundaryValues<dim>::vector_value (const Point<dim> &p,
                                   Vector<double> &values) const
{
    for (unsigned int c=0; c<this->n_components; ++c)
        values(c) = BoundaryValues<dim>::value (p, c);
}

template <int dim>
class VelocityFieldControlValues : public TensorFunction<1,dim>
{
public:
VelocityFieldControlValues(const unsigned int components) : TensorFunction<1,dim> (components) {}
//VelocityFieldControlValues  () : TensorFunction<1,dim> () {}
virtual Tensor<1,dim> value (const Point<dim> &p) const;
//virtual void vector_value (const Point<dim> &p, Vector<double> &value) const;
virtual void vector_value_list (const std::vector<Point<dim> > &points, std::vector<Tensor<1,dim> > &values) const;
DeclException2 (ExcDimensionMismatch,
unsigned int, unsigned int,
<< "The vector has size " << arg1 << " but should have "
<< arg2 << " elements.");
};
template <int dim>
Tensor<1,dim> VelocityFieldControlValues<dim>::value (const Point<dim> &p) const
{
    Point<dim> value;
    double x=p[0];
    double y=p[1];


    if(solve_problem_type==Problem_Type::LID_DRIVEN_CAVITY){
    value[0]=   y;
    value[1]=  -x;
    return value;
    }
    else if(solve_problem_type==Problem_Type::VELOCITY_TRACKING_1) {
    double a=0.8*numbers::PI;

    double sin_ax =sin(a*x);
    double cos_ax =cos(a*x);

    double sin_ay =sin(a*y);
    double cos_ay =cos(a*y);


    double phi_x  =(1-cos_ax)*(1.0-x)*(1.0-x);
    double phi_y  =(1-cos_ay)*(1.0-y)*(1.0-y);

    double d_phi_x=a*x*(x*sin_ax-2.0*sin_ax)-2*x*(cos_ax-1)+2.0*cos_ax+a*sin_ax-2.0;
    double d_phi_y=a*y*(y*sin_ay-2.0*sin_ay)-2*y*(cos_ay-1)+2.0*cos_ay+a*sin_ay-2.0;

    value[0]= 10*phi_x*d_phi_y;
    value[1]=-10*phi_y*d_phi_x;
    return value;
    }
    //1
    /*if((x<0 && y>0) && (x<0 && y<=1)){
        value[0]=-(0.5-y)*x*(1.0+x);
        value[1]= (0.5+x)*y*(1.0-y);

    }
    //2
    else if((x>0 && y>0) && (x<=1 && y<=1)){
        value[0]=-(0.5-y)*x*(1.0-x);
        value[1]= (0.5-x)*y*(1.0-y);
    }

    if((x<0 && y<0) && (x>=-1 && y>=-1)){
        value[0]=-(0.5+y)*x*(1.0+x);
        value[1]= (0.5+x)*y*(1.0+y);
    }
    if((x>0 && y<0) && (x<=1 && y>=-1)){
        value[0]=-(0.5+y)*x*(1.0-x);
        value[1]= (0.5-x)*y*(1.0+y);
    }*/


    return value;
}
template <int dim>
void VelocityFieldControlValues<dim>::vector_value_list (const std::vector<Point<dim> > &points, std::vector<Tensor<1,dim> > &values) const
{
    Assert (values.size() == points.size(),
    ExcDimensionMismatch (values.size(), points.size()));
    for (unsigned int i=0; i<points.size(); ++i)
    values[i] = VelocityFieldControlValues <dim>::value (points[i]);
}


/*template <int dim>
void
VelocityFieldControlValues<dim>::vector_value (const Point<dim> &p, Vector<double> &values) const
{
//Assert (values.size() == dim+1,
//ExcDimensionMismatch (values.size(), dim+1));

Tensor<1,dim> t=VelocityFieldControlValues<dim>::value (p);
values(0) = t[0];
values(1) = t[1];

}*/


template <int dim>
class ExactVelocityFieldControlValues : public Function<dim>
{
public:
ExactVelocityFieldControlValues(const unsigned int components) : Function<dim> (components) {}

virtual void vector_value (const Point<dim> &p, Vector<double> &value) const;

};

template <int dim>
void
ExactVelocityFieldControlValues<dim>::vector_value (const Point<dim> &p, Vector<double> &values) const
{
//Assert (values.size() == dim+1,
//ExcDimensionMismatch (values.size(), dim+1));
//const double alpha = 0.3;
//const double beta = 1;

    Point<dim> value;
    double x=p[0];
    double y=p[1];
if(solve_problem_type==Problem_Type::LID_DRIVEN_CAVITY){
    value[0]=   y;
    value[1]=  -x;
}
else if(solve_problem_type==Problem_Type::VELOCITY_TRACKING_1) {
    double a=0.8*numbers::PI;

    double sin_ax =sin(a*x);
    double cos_ax =cos(a*x);

    double sin_ay =sin(a*y);
    double cos_ay =cos(a*y);


    double phi_x  =(1-cos_ax)*(1-x)*(1-x);
    double phi_y  =(1-cos_ay)*(1-y)*(1-y);

    double d_phi_x=a*x*(x*sin_ax-2*sin_ax)-2*x*(cos_ax-1)+2*cos_ax+a*sin_ax-2;
    double d_phi_y=a*y*(y*sin_ay-2*sin_ay)-2*y*(cos_ay-1)+2*cos_ay+a*sin_ay-2;

    values[0]= 10*phi_x*d_phi_y;
    values[1]=-10*phi_y*d_phi_x;

}
    ///////////////////////////////////////////
    //1
   /*  if((x<0 && y>0) && (x<0 && y<=1)){
        value[0]=-(0.5-y)*x*(1.0+x);
        value[1]= (0.5+x)*y*(1.0-y);

    }
    //2
    else if((x>0 && y>0) && (x<=1 && y<=1)){
        value[0]=-(0.5-y)*x*(1.0-x);
        value[1]= (0.5-x)*y*(1.0-y);
    }

    if((x<0 && y<0) && (x>=-1 && y>=-1)){
        value[0]=-(0.5+y)*x*(1.0+x);
        value[1]= (0.5+x)*y*(1.0+y);
    }
    if((x>0 && y<0) && (x<=1 && y>=-1)){
        value[0]=-(0.5+y)*x*(1.0-x);
        value[1]= (0.5-x)*y*(1.0+y);
    }*/


}



}


