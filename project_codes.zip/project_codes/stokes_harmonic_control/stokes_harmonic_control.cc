#include <deal.II/base/quadrature_lib.h>
#include <deal.II/base/function.h>
#include <sstream>
#include <deal.II/lac/solver_cg.h>
#include <deal.II/lac/solver_gmres.h>
#include <deal.II/lac/solver_minres.h>
#include <deal.II/lac/constraint_matrix.h>
#include <deal.II/lac/block_sparsity_pattern.h>
#include <deal.II/lac/trilinos_block_vector.h>
#include <deal.II/lac/trilinos_sparse_matrix.h>
#include <deal.II/lac/trilinos_block_sparse_matrix.h>
/*For PreconditionAMG */
#include <deal.II/lac/trilinos_precondition.h>
/*For PreconditionIdentity*/
#include <deal.II/lac/precondition.h>

#include <deal.II/grid/tria.h>
#include <deal.II/grid/grid_generator.h>
#include <deal.II/grid/tria_accessor.h>
#include <deal.II/grid/tria_iterator.h>

#include <deal.II/dofs/dof_handler.h>
#include <deal.II/dofs/dof_renumbering.h>
#include <deal.II/dofs/dof_accessor.h>
#include <deal.II/dofs/dof_tools.h>

#include <deal.II/fe/fe_q.h>
#include <deal.II/fe/fe_system.h>
#include <deal.II/fe/fe_values.h>

/*Vector and Matrix tools */
#include <deal.II/numerics/vector_tools.h>
#include <deal.II/numerics/matrix_tools.h>


#include <deal.II/numerics/data_out.h>
#include <deal.II/lac/lapack_full_matrix.h>
#include <deal.II/lac/transpose_matrix.h>

/*for iterative inverse*/
#include <deal.II/lac/iterative_inverse.h>

/* For convergence table out put */
#include <deal.II/base/convergence_table.h>
/* The timer class header */
#include <deal.II/base/timer.h>

#include <deal.II/base/std_cxx1x/thread.h>

/*For Tensors */
#include <deal.II/base/tensor_function.h>

/*Solvers */
#include <deal.II/lac/sparse_direct.h>
#include <deal.II/lac/sparse_ilu.h>
#include <deal.II/lac/trilinos_solver.h>


#include <fstream>
#include <iostream>
#include <string>

#include "../data.hh"
#include "../solver_impl.hh"
#include "../MiscUtilities.hh"




unsigned int SCALED=0;
namespace EquationData
{
  unsigned int inner_fgmres_iterations_H1=0;
  unsigned int inner_fgmres_iterations_H2=0;
  double beta;
  double beta_hat;
  double omega;
}






using namespace dealii;




template <class PreconditionerA, class PreconditionerB>
class BlockHPreconditioner : public Subscriptor
{
  public:
    BlockHPreconditioner (const TrilinosWrappers::BlockSparseMatrix  &sub_matrix_H,
                         const LinearSolvers::InverseMatrix<TrilinosWrappers::SparseMatrix, PreconditionerB> &m_inv_1,
                         const LinearSolvers::InverseMatrix<TrilinosWrappers::SparseMatrix, PreconditionerA> &_amg_inv_1,
                         const LinearSolvers::InverseMatrix<TrilinosWrappers::SparseMatrix, PreconditionerA> &_amg_inv_2,
                         const double scaling_parameter,
                         const int n_v,
                         const int n_p
                         );

    void vmult (TrilinosWrappers::BlockVector &dst,
                const TrilinosWrappers::BlockVector &src) const;


    void implement_block_diagonal(TrilinosWrappers::BlockVector &dst, const TrilinosWrappers::BlockVector &src) const;


  private:
    const SmartPointer<const TrilinosWrappers::BlockSparseMatrix> preconditioner_matrix;
    const SmartPointer<const TrilinosWrappers::BlockSparseMatrix> sub_matrix_H;

    const SmartPointer<const LinearSolvers::InverseMatrix<TrilinosWrappers::SparseMatrix, PreconditionerB> > m_inv_1;
    const SmartPointer<const LinearSolvers::InverseMatrix<TrilinosWrappers::SparseMatrix, PreconditionerA> > amg_1;
    const SmartPointer<const LinearSolvers::InverseMatrix<TrilinosWrappers::SparseMatrix, PreconditionerA> > amg_2;
    const double scaling_parameter;

    mutable int n_v, n_p;
    mutable TrilinosWrappers::Vector v_1, v_2, v_3,p_1, p_2, p_3, t_1, t_2;

};
template <class PreconditionerA, class PreconditionerB>
BlockHPreconditioner<PreconditionerA, PreconditionerB>::
BlockHPreconditioner(const TrilinosWrappers::BlockSparseMatrix &_sub_matrix_H,
                    const LinearSolvers::InverseMatrix<TrilinosWrappers::SparseMatrix, PreconditionerB> &_m_inv_1,
                    const LinearSolvers::InverseMatrix<TrilinosWrappers::SparseMatrix, PreconditionerA> &_amg_1,
                    const LinearSolvers::InverseMatrix<TrilinosWrappers::SparseMatrix, PreconditionerA> &_amg_2,
                    const double _scaling_parameter,
                    int n_v,
                    int n_p)
                :
                sub_matrix_H           (&_sub_matrix_H),
                m_inv_1                 (&_m_inv_1),
                amg_1                   (&_amg_1),
                amg_2                   (&_amg_2),
                scaling_parameter       (_scaling_parameter),
                n_v                     (n_v),
                n_p                     (n_p),
                v_1                     (n_v),
                v_2                     (n_v),
                v_3                     (n_v),
                p_1                     (n_p),
                p_2                     (n_p),
                p_3                     (n_p),
                t_1                     (n_p),
                t_2                     (n_p)

{}


template <class PreconditionerA, class PreconditionerB>
void BlockHPreconditioner<PreconditionerA, PreconditionerB >::vmult (
  TrilinosWrappers::BlockVector &dst,
  const TrilinosWrappers::BlockVector &src) const
{

      implement_block_diagonal(dst, src);

}

template <class PreconditionerA, class PreconditionerB>
void BlockHPreconditioner<PreconditionerA, PreconditionerB >::implement_block_diagonal (
  TrilinosWrappers::BlockVector &dst,
  const TrilinosWrappers::BlockVector &src) const
{
 p_1=0;
 p_2=0;
 p_3=0;
 v_1=0;
 v_2=0;
 v_3=0;
 t_1=0;
 t_2=0;

 amg_1->vmult (v_1, src.block(0));
 sub_matrix_H->block(1,0).vmult(t_1, v_1);
 t_2   = src.block(1);
 t_2  -= t_1;
 t_2  *=-1.0;
 //for (unsigned int i=0; i<n_p;i++)
 //    p_1[i] =t_2[i]/preconditioner_matrix->block(3, 3).diag_element(i);
 m_inv_1->vmult(p_1, t_2);
 amg_2->vmult(p_2, t_2);
 p_1 *=sqrt(EquationData::beta_hat);
 p_3  =p_1;
 p_3 +=p_2;
 p_3 *=1.0/(EquationData::beta_hat);

 dst.block(0) =v_1;
 dst.block(1) =p_3;

}



    template <class PreconditionerA, class PreconditionerB, class PreconditionerC>
    class BlockPreconditioner : public Subscriptor
    {
      public:
        BlockPreconditioner (const TrilinosWrappers::BlockSparseMatrix  &system_matrix,
                             const TrilinosWrappers::BlockSparseMatrix  &sub_matrix_H1,
                             const TrilinosWrappers::BlockSparseMatrix  &sub_matrix_H2,
                             const TrilinosWrappers::BlockSparseMatrix  &S,
                             const BlockHPreconditioner<TrilinosWrappers::PreconditionAMG, TrilinosWrappers::PreconditionChebyshev>  &_block_H1_preconditioner,
                             const BlockHPreconditioner<TrilinosWrappers::PreconditionAMG, TrilinosWrappers::PreconditionChebyshev>  &_block_H2_preconditioner,
                             const LinearSolvers::InverseMatrix<TrilinosWrappers::SparseMatrix, PreconditionerB> &preconditioner_inv_1,
                             const LinearSolvers::InverseMatrix<TrilinosWrappers::SparseMatrix, PreconditionerA> &amg_inv_1,
                             const LinearSolvers::InverseMatrix<TrilinosWrappers::SparseMatrix, PreconditionerA> &amg_inv_2,

                             const int n_v,
                             const int n_p
                             );

        void vmult (TrilinosWrappers::BlockVector &dst,
                    const TrilinosWrappers::BlockVector &src) const;
        void solve_H_block(TrilinosWrappers::BlockVector &dst, const TrilinosWrappers::BlockVector &src, unsigned int h_block_id) const;
        void implement_factorization(TrilinosWrappers::BlockVector &dst, const TrilinosWrappers::BlockVector &src) const;
        void solve_with_uzawa_h1 (TrilinosWrappers::BlockVector &dst, const TrilinosWrappers::BlockVector &src) const;
        void solve_with_uzawa_h2 (TrilinosWrappers::BlockVector &dst, const TrilinosWrappers::BlockVector &src) const;


      private:
        const SmartPointer<const TrilinosWrappers::BlockSparseMatrix> preconditioner_matrix;
        const SmartPointer<const TrilinosWrappers::BlockSparseMatrix> system_matrix;
        const SmartPointer<const TrilinosWrappers::BlockSparseMatrix> sub_matrix_H1;
        const SmartPointer<const TrilinosWrappers::BlockSparseMatrix> sub_matrix_H2;
        const SmartPointer<const LinearSolvers::InverseMatrix<TrilinosWrappers::SparseMatrix, PreconditionerB> > m_inv_1;
        const SmartPointer<const LinearSolvers::InverseMatrix<TrilinosWrappers::SparseMatrix, PreconditionerA> > amg_1;
        const SmartPointer<const LinearSolvers::InverseMatrix<TrilinosWrappers::SparseMatrix, PreconditionerA> > amg_2;

        const SmartPointer<const BlockHPreconditioner <TrilinosWrappers::PreconditionAMG, TrilinosWrappers::PreconditionChebyshev> > block_H1_preconditioner;
        const SmartPointer<const BlockHPreconditioner <TrilinosWrappers::PreconditionAMG, TrilinosWrappers::PreconditionChebyshev> > block_H2_preconditioner;
        mutable TrilinosWrappers::Vector v, l, m, p;
        mutable int n_v, n_l, n_m, n_p;
        mutable TrilinosWrappers::Vector g_v1, g_v2, g_p1, g_p2;
        mutable TrilinosWrappers::BlockVector solution_H1, rhs_H1, direct_sol;

    };

    template <class PreconditionerA, class PreconditionerB,  class PreconditionerC>
    BlockPreconditioner<PreconditionerA, PreconditionerB, PreconditionerC>::
    BlockPreconditioner(const TrilinosWrappers::BlockSparseMatrix &_system_matrix,
                        const TrilinosWrappers::BlockSparseMatrix &_sub_matrix_H1,
                        const TrilinosWrappers::BlockSparseMatrix &_sub_matrix_H2,
                        const TrilinosWrappers::BlockSparseMatrix &S,
                        const BlockHPreconditioner<TrilinosWrappers::PreconditionAMG, TrilinosWrappers::PreconditionChebyshev>  &_block_H1_preconditioner,
                        const BlockHPreconditioner<TrilinosWrappers::PreconditionAMG, TrilinosWrappers::PreconditionChebyshev>  &_block_H2_preconditioner,
                        const LinearSolvers::InverseMatrix<TrilinosWrappers::SparseMatrix, PreconditionerB> &_m_inv_1,
                        const LinearSolvers::InverseMatrix<TrilinosWrappers::SparseMatrix, PreconditionerA> &_amg_1,
                        const LinearSolvers::InverseMatrix<TrilinosWrappers::SparseMatrix, PreconditionerA> &_amg_2,

                        int n_v,
                        int n_p)
                    :
                    system_matrix           (&_system_matrix),
                    sub_matrix_H1           (&_sub_matrix_H1),
                    sub_matrix_H2           (&_sub_matrix_H2),
                    preconditioner_matrix   (&S),
                    block_H1_preconditioner (&_block_H1_preconditioner),
                    block_H2_preconditioner (&_block_H2_preconditioner),
                    m_inv_1                 (&_m_inv_1),
                    amg_1                   (&_amg_1),
                    amg_2                   (&_amg_2),
                    n_v                     (n_v),
                    n_p                     (n_p),
                    g_v1                    (n_v),
                    g_v2                    (n_v),
                    g_p1                    (n_p),
                    g_p2                    (n_p),
                    v                       (n_v),
                    l                       (n_v),
                    m                       (n_p),
                    p                       (n_p)

 {
    rhs_H1.reinit(2);
    rhs_H1.block(0).reinit (n_v);
    rhs_H1.block(1).reinit (n_p);
    rhs_H1.collect_sizes ();

    solution_H1.reinit(2);
    solution_H1.block(0).reinit (n_v);
    solution_H1.block(1).reinit (n_p);
    solution_H1.collect_sizes ();

    direct_sol.reinit(2);
    direct_sol.block(0).reinit (n_v);
    direct_sol.block(1).reinit (n_p);
    direct_sol.collect_sizes ();

 }


    template <class PreconditionerA, class PreconditionerB,  class PreconditionerC>
    void BlockPreconditioner<PreconditionerA, PreconditionerB, PreconditionerC >::vmult (
      TrilinosWrappers::BlockVector &dst,
      const TrilinosWrappers::BlockVector &src) const
    {
      implement_factorization(dst, src);
    }

   template <class PreconditionerA, class PreconditionerB,  class PreconditionerC>
    void BlockPreconditioner<PreconditionerA, PreconditionerB, PreconditionerC >::solve_with_uzawa_h1 (
      TrilinosWrappers::BlockVector &dst,
      const TrilinosWrappers::BlockVector &src) const {


     const double tau=3.0/5.0;

     TrilinosWrappers::Vector K_v1(n_v);
     TrilinosWrappers::Vector B_p1(n_v);
     TrilinosWrappers::Vector B_v2(n_p);

     TrilinosWrappers::Vector r_v(n_v);
     TrilinosWrappers::Vector r_p(n_p);

     TrilinosWrappers::Vector g_v1(n_v);
     TrilinosWrappers::Vector g_p1(n_p);
     TrilinosWrappers::Vector g_p2(n_p);
     TrilinosWrappers::Vector g_p3(n_p);


     TrilinosWrappers::Vector lambda_bar(n_v);
     TrilinosWrappers::Vector mu_bar(n_p);

     r_v=0;
     r_p=0;
     g_v1=0;
     g_p1=0;
     g_p2=0;
     g_p3=0;
     lambda_bar = 0;
         mu_bar = 0;



    for(int i=0; i<Iterations::h_block;i++){

        K_v1=0;
        B_p1=0;
        B_v2=0;
        r_v = src.block(0);
        r_p = src.block(1);
        //[K B^T
        // B  Mp]

        //K.lambda_bar
        sub_matrix_H1->block(0,0).vmult(K_v1, lambda_bar);
        //B.mu_bar
        sub_matrix_H1->block(0,1).vmult(B_p1, mu_bar);

        //calculate velocity
        r_v  -= K_v1;
        r_v  -= B_p1;
        amg_1->vmult(g_v1, r_v);
        lambda_bar +=g_v1;

        //calculate pressure
        sub_matrix_H1->block(1,0).vmult (B_v2,lambda_bar);
        r_p -=B_v2;

        m_inv_1->vmult(g_p1, r_p);
        amg_2->vmult(g_p2, r_p);
        g_p1 *=(sqrt(EquationData::beta_hat));
        g_p3  =g_p1;
        g_p3 +=g_p2;
        g_p3 *=1.0/((EquationData::beta_hat));
        g_p3 *=1.0/tau;
        mu_bar-=g_p3;

    }

    EquationData::inner_fgmres_iterations_H1 +=Iterations::h_block;
    dst.block(0) = lambda_bar;
    dst.block(1) = mu_bar;

   }

    template <class PreconditionerA, class PreconditionerB,  class PreconditionerC>
     void BlockPreconditioner<PreconditionerA, PreconditionerB, PreconditionerC >::solve_with_uzawa_h2 (
       TrilinosWrappers::BlockVector &dst,
       const TrilinosWrappers::BlockVector &src) const {


      const double tau=3.0/5.0;

      TrilinosWrappers::Vector K_v1(n_v);
      TrilinosWrappers::Vector B_p1(n_v);
      TrilinosWrappers::Vector B_v2(n_p);

      TrilinosWrappers::Vector r_v(n_v);
      TrilinosWrappers::Vector r_p(n_p);

      TrilinosWrappers::Vector g_v1(n_v);
      TrilinosWrappers::Vector g_p1(n_p);
      TrilinosWrappers::Vector g_p2(n_p);
      TrilinosWrappers::Vector g_p3(n_p);


      TrilinosWrappers::Vector lambda_bar(n_v);
      TrilinosWrappers::Vector mu_bar(n_p);

      r_v=0;
      r_p=0;
      g_v1=0;
      g_p1=0;
      g_p2=0;
      g_p3=0;
      lambda_bar = 0;
          mu_bar = 0;



     for(int i=0; i<Iterations::h_block;i++){

         K_v1=0;
         B_p1=0;
         B_v2=0;
         r_v = src.block(0);
         r_p = src.block(1);
         //[K B^T
         //B  Mp]

         //K.lambda_bar
         sub_matrix_H2->block(0,0).vmult(K_v1, lambda_bar);
         //B.mu_bar
         sub_matrix_H2->block(0,1).vmult(B_p1, mu_bar);

         //calculate velocity
         r_v  -= K_v1;
         r_v  -= B_p1;
         amg_1->vmult(g_v1, r_v);
         lambda_bar +=g_v1;

         //calculate pressure
         sub_matrix_H2->block(1,0).vmult (B_v2,lambda_bar);
         r_p -=B_v2;

         m_inv_1->vmult(g_p1, r_p);
         amg_2->vmult(g_p2, r_p);
         g_p1 *=(sqrt(EquationData::beta_hat));
         g_p3  =g_p1;
         g_p3 +=g_p2;
         g_p3 *=1.0/((EquationData::beta_hat));
         g_p3 *=1.0/tau;
         mu_bar-=g_p3;
     }


     EquationData::inner_fgmres_iterations_H2 +=Iterations::h_block;
     dst.block(0) = lambda_bar;
     dst.block(1) = mu_bar;

    }





    template <class PreconditionerA, class PreconditionerB,  class PreconditionerC>
    void BlockPreconditioner<PreconditionerA, PreconditionerB, PreconditionerC >::solve_H_block (
      TrilinosWrappers::BlockVector &dst,
      const TrilinosWrappers::BlockVector &src, unsigned int h_block_id) const
     {


      //  double relative_tolerance=std::max(EquationData::beta, 1.0e-4)*src.l2_norm();

        double relative_tolerance = ToleranceLimits::h_block_solver*src.l2_norm();

        SolverControl solver_control (Iterations::h_block, relative_tolerance);
        SolverFGMRES<TrilinosWrappers::BlockVector> fgmres (solver_control);
        //SolverMinRes<TrilinosWrappers::BlockVector> minres (solver_control);
        dst=0;
        try{
        if(h_block_id==1)
            fgmres.solve (*sub_matrix_H1, dst, src, *block_H1_preconditioner);
         else
            fgmres.solve (*sub_matrix_H2, dst, src, *block_H2_preconditioner);


        }catch (std::exception &e){
            Assert(true, ExcMessage(e.what()));
        }

        /*There is always 1 extra iteration */
        if(h_block_id==1)
            EquationData::inner_fgmres_iterations_H1 +=solver_control.last_step();
        else
            EquationData::inner_fgmres_iterations_H2 +=solver_control.last_step();

       }


   template <class PreconditionerA, class PreconditionerB,  class PreconditionerC>
    void BlockPreconditioner<PreconditionerA, PreconditionerB, PreconditionerC >::implement_factorization(
                                                                                    TrilinosWrappers::BlockVector &dst,
                                                                                    const TrilinosWrappers::BlockVector &src) const
    {

        TrilinosWrappers::Vector f_1(n_v);
        TrilinosWrappers::Vector f_2(n_v);
        TrilinosWrappers::Vector f_3(n_v);
        TrilinosWrappers::Vector v_1(n_v);

        TrilinosWrappers::Vector g_1(n_p);
        TrilinosWrappers::Vector g_2(n_p);
        TrilinosWrappers::Vector g_3(n_p);

        TrilinosWrappers::Vector f(n_v);
        TrilinosWrappers::Vector g(n_p);


        TrilinosWrappers::Vector v_2(n_v);

        TrilinosWrappers::Vector m_1(n_p);
        TrilinosWrappers::Vector m_2(n_p);
        TrilinosWrappers::Vector m_3(n_p);
        TrilinosWrappers::Vector p_1(n_p);
        TrilinosWrappers::Vector p_2(n_p);
        TrilinosWrappers::Vector p_3(n_p);


        p_1=0;
        p_2=0;
        p_3=0;

        m_1=0;
        m_2=0;
        m_3=0;


        double zeps;
        if(SCALED ==1)
        zeps=1.0;
        else
        zeps=sqrt(EquationData::beta_hat);


        f_1  = src.block(0);
        f_2  = src.block(2);
        f_2 *= zeps;

        f    =f_1;
        f   +=f_2;


        g_1  =  src.block(1);
        g_2  =  src.block(3);
        g_2 *=  zeps;

        g   = g_1;
        g  += g_2;




        solution_H1=0;
        rhs_H1.block(0) = f;
        rhs_H1.block(1) = g;
        //solve_H_block(solution_H1, rhs_H1, 1);
        solve_with_uzawa_h1(solution_H1, rhs_H1);

        v_1=solution_H1.block(0);
        p_3=solution_H1.block(1);


        //compute Ag
        system_matrix->block(0,0).vmult (f_3, v_1);
        f_3 *= -1.0;
        f_3 += f_1;

       // preconditioner_matrix->block(3,3).vmult (g_3, p_3);
       // g_3 *= -1.0;
        g_3 = g_1;



        solution_H1=0;
        rhs_H1.block(0) = f_3;
        rhs_H1.block(1) = g_3;
        //solve_H_block(solution_H1, rhs_H1, 2);
        solve_with_uzawa_h2(solution_H1, rhs_H1);

        v_2=solution_H1.block(0);
        m_3=solution_H1.block(1);



        dst.block(0)  = v_1;
        dst.block(1)  = p_3;

        dst.block(0) += v_2;
        dst.block(1) += m_3;

        dst.block(2) = v_2;
        dst.block(3) = m_3;

        dst.block(2) *= -1.0/zeps;
        dst.block(3) *= -1.0/zeps;

    }

/*The main class*/
template <int dim>
class OptimalControl
{
  public:
    OptimalControl (const unsigned int degree);
    void start();
    void run ();

  private:
    void make_grid_and_dofs (const double n_refinement_steps);
    void assemble_constant_matrix_equation();
    void assemble_constant_matrix ();
    void set_table_labels();
    void solve();

    void compute_errors ();
    void output_results() const;
    void output_results_vtk () const;
    void print_tables();


    void initialize_preconditioner();
    void process_solution(TableHandler &table, unsigned int iterations, double tolerance, double time);


    dealii::Triangulation<dim>   triangulation;


    FESystem<dim>     system_fe;
    FESystem<dim>     system_fe_block_H1;

    DoFHandler<dim>   system_dof_handler;
    DoFHandler<dim>   system_dof_handler_block_H1;



    TrilinosWrappers::BlockSparsityPattern sparsity_pattern;
    TrilinosWrappers::BlockSparsityPattern sparsity_pattern_2x2;
    TrilinosWrappers::BlockSparsityPattern pre_sparsity_pattern;
    TrilinosWrappers::BlockSparsityPattern sparsity_pattern_block_H;

    double h;
    double n_refs;

    TrilinosWrappers::BlockSparseMatrix system_matrix;
    TrilinosWrappers::BlockSparseMatrix sub_matrix_H1;
    TrilinosWrappers::BlockSparseMatrix sub_matrix_H2;
    TrilinosWrappers::BlockSparseMatrix preconditioner_matrix;



    ConstraintMatrix  matrix_constraints;
    ConstraintMatrix  matrix_constraints_2x2;
    ConstraintMatrix  preconditioner_constraints;
    ConstraintMatrix  matrix_constraints_nil;



    std::vector<types::global_dof_index> system_block_sizes;

    TrilinosWrappers::BlockVector solution;
    TrilinosWrappers::BlockVector system_rhs;




    TrilinosWrappers::BlockVector zero_vector;

    unsigned int n_v;
    unsigned int n_l;
    unsigned int n_p;
    unsigned int n_m;

    const unsigned int degree;


    std_cxx1x::shared_ptr<TrilinosWrappers::PreconditionAMG> amg_preconditioner_1;
    std_cxx1x::shared_ptr<TrilinosWrappers::PreconditionAMG> amg_preconditioner_2;


    std_cxx1x::shared_ptr<TrilinosWrappers::PreconditionChebyshev> cb_preconditioner_1;


    std::vector<double> beta_values;
    std::vector<int> refinements;
    std::vector<double> inner_tolerance;
    Timer timer;
    Timer total_time;
    SolverType solver_type;



    /*Table output */
    std::vector< MiscUtilities::TableData> table_data_list;
    TableHandler table;
    TableHandler table_for_solution_data;

    std::string tex_table_caption;
    std::string tex_file_name;
    std::string text_table_file_name;
    std::string vtk_tile_name;

    /*cost functional and errors*/
    double u_l2_norm;
    double y_yd_l2_norm;
    double rel_y_yd_l2_norm;
    double cost_functional_J;

};

 template <int dim>
 OptimalControl<dim>::OptimalControl(const unsigned int degree)
        :
        degree(degree),
        triangulation (Triangulation<dim>::none),
        system_fe(FE_Q<dim>(degree+1),2,
                  FE_Q<dim>(degree),  1,
                  FE_Q<dim>(degree+1),2,
                  FE_Q<dim>(degree),  1),
          system_fe_block_H1(FE_Q<dim>(degree+1),2,
                        FE_Q<dim>(degree),1),

        system_dof_handler_block_H1(triangulation),
        system_dof_handler(triangulation)

 {

 }

 /////////////////////make_grid_and_dofs////////////////////////////////
template <int dim>
 void OptimalControl<dim>::make_grid_and_dofs (const double n_refinement_steps)
 {

     GridGenerator::hyper_cube (triangulation, 0, 1);
     triangulation.refine_global (n_refinement_steps);

     system_dof_handler.distribute_dofs (system_fe);
     system_dof_handler_block_H1.distribute_dofs (system_fe_block_H1);

     DoFRenumbering::Cuthill_McKee (system_dof_handler);
     DoFRenumbering::Cuthill_McKee (system_dof_handler_block_H1);


     std::vector<unsigned int> pde_sub_blocks (6,0);
     pde_sub_blocks[0]=0; //v_i
     pde_sub_blocks[1]=0; //v_j
     pde_sub_blocks[2]=1; //p
     pde_sub_blocks[3]=2; //w_i
     pde_sub_blocks[4]=2; //w_j
     pde_sub_blocks[5]=3; //mu
     DoFRenumbering::component_wise (system_dof_handler, pde_sub_blocks);
     /*The next thing is that we want to figure out the sizes of these blocks,
      so that we can allocate an appropriate amount of space. */
     std::vector<types::global_dof_index> dofs_per_component (4);


     // DoFTools::count_dofs_per_component (system_dof_handler, dofs_per_component_all, true,pde_sub_blocks);
     DoFTools::count_dofs_per_component (system_dof_handler, dofs_per_component, true,pde_sub_blocks);
     n_v = dofs_per_component[0];
     n_p = dofs_per_component[1];
     n_l = dofs_per_component[2];
     n_m = dofs_per_component[3];

     std::vector<unsigned int> pde_sub_blocks_H1 (3,0);
     pde_sub_blocks_H1[0]=0; //v_i
     pde_sub_blocks_H1[1]=0; //v_j
     pde_sub_blocks_H1[2]=1; //p

     DoFRenumbering::component_wise (system_dof_handler_block_H1, pde_sub_blocks_H1);

     //cout<<"v_i = "<<dofs_per_component_all[0]<<endl;
     cout << "Number of active cells: "
               << triangulation.n_active_cells()
               << std::endl
               << "Total number of degrees of freedom: "
               << system_dof_handler.n_dofs()
               << std::endl
               << "Number of degrees of freedom v: "
               << n_v
               << std::endl
               << "Number of degrees of freedom l: "
               << n_l
               << std::endl
               << "Number of degrees of freedom m: "
               << n_m
               << std::endl
               << "Number of degrees of freedom p: "
               << n_p
               << std::endl
               << "Total degrees: "
               << (n_v+n_l+n_m+n_p)
               << std::endl;




     //Apply Dirichelet to the whole matrix

     for (typename Triangulation<dim>::active_cell_iterator
      cell = triangulation.begin_active();
      cell != triangulation.end(); ++cell)
     /*for (unsigned int f=0; f<GeometryInfo<dim>::faces_per_cell; ++f)
              if (std::fabs(cell->face(f)->center()(0) - 1) < 1e-12)
                  cell->face(f)->set_boundary_indicator(1);*/
      for (unsigned int f=0; f<GeometryInfo<dim>::faces_per_cell; ++f){
                 if (std::fabs(cell->face(f)->center()(0) - 1.0) < 1.0e-12)
                     cell->face(f)->set_boundary_indicator(1);
     }

     //CompressedSparsityPattern c(n_p);
     //DoFTools::make_sparsity_pattern(system_dof_handler.)

     const FEValuesExtractors::Vector component_v(0);
     const FEValuesExtractors::Scalar component_p(2);
     const FEValuesExtractors::Vector component_l(3);
     const FEValuesExtractors::Scalar component_m(5);



     DoFTools::make_hanging_node_constraints (system_dof_handler, matrix_constraints);
     DoFTools::make_hanging_node_constraints (system_dof_handler, matrix_constraints_2x2);
     DoFTools::make_hanging_node_constraints (system_dof_handler, preconditioner_constraints);


     matrix_constraints.clear ();
     VectorTools::interpolate_boundary_values (system_dof_handler, 1, Stokes::BoundaryValues<dim>(6), matrix_constraints, system_fe.component_mask(component_v));
     VectorTools::interpolate_boundary_values (system_dof_handler, 1, ZeroFunction<dim>(6), matrix_constraints, system_fe.component_mask(component_l));

     VectorTools::interpolate_boundary_values (system_dof_handler, 0, ZeroFunction<dim>(6),  matrix_constraints, system_fe.component_mask(component_v));//
     VectorTools::interpolate_boundary_values (system_dof_handler, 0, ZeroFunction<dim>(6),  matrix_constraints, system_fe.component_mask(component_l));


     matrix_constraints.close ();

     preconditioner_constraints.clear ();
     VectorTools::interpolate_boundary_values (system_dof_handler, 1, Stokes::BoundaryValues<dim>(6), preconditioner_constraints, system_fe.component_mask(component_v));
     VectorTools::interpolate_boundary_values (system_dof_handler, 1, ZeroFunction<dim>(6), preconditioner_constraints, system_fe.component_mask(component_l));

     VectorTools::interpolate_boundary_values (system_dof_handler,0, ZeroFunction<dim>(6),  preconditioner_constraints, system_fe.component_mask(component_v));
     VectorTools::interpolate_boundary_values (system_dof_handler,0, ZeroFunction<dim>(6),  preconditioner_constraints, system_fe.component_mask(component_l));

     preconditioner_constraints.close ();


     cout<<"Dirichlet condition applied "<<endl;

     /*Sparsity Pattern for the System Matrix */
     {
     system_matrix.clear ();
     sparsity_pattern.reinit (4,4);
     const unsigned int n_couplings = system_dof_handler.max_couplings_between_dofs();
     sparsity_pattern.block(0,0).reinit (n_v, n_v, n_couplings);
     sparsity_pattern.block(1,0).reinit (n_p, n_v, n_couplings);
     sparsity_pattern.block(2,0).reinit (n_l, n_v, n_couplings);
     sparsity_pattern.block(3,0).reinit (n_m, n_v, n_couplings);

     sparsity_pattern.block(0,1).reinit (n_v, n_p, n_couplings);
     sparsity_pattern.block(1,1).reinit (n_p, n_p, n_couplings);
     sparsity_pattern.block(2,1).reinit (n_l, n_p, n_couplings);
     sparsity_pattern.block(3,1).reinit (n_m, n_p, n_couplings);

     sparsity_pattern.block(0,2).reinit (n_v, n_l, n_couplings);
     sparsity_pattern.block(1,2).reinit (n_p, n_l, n_couplings);
     sparsity_pattern.block(2,2).reinit (n_l, n_l, n_couplings);
     sparsity_pattern.block(3,2).reinit (n_m, n_l, n_couplings);

     sparsity_pattern.block(0,3).reinit (n_v, n_m, n_couplings);
     sparsity_pattern.block(1,3).reinit (n_p, n_m, n_couplings);
     sparsity_pattern.block(2,3).reinit (n_l, n_m, n_couplings);
     sparsity_pattern.block(3,3).reinit (n_m, n_m, n_couplings);


     sparsity_pattern.collect_sizes();  //what is this for? yes, needed when we touch each block separately!,

     DoFTools::make_sparsity_pattern (system_dof_handler,
                       sparsity_pattern,
                       matrix_constraints,
                       true);
      sparsity_pattern.compress();
      system_matrix.reinit (sparsity_pattern);

     }



     //Sparsity Pattern for the System Matrix */
     {
     preconditioner_matrix.clear ();
     pre_sparsity_pattern.reinit (4,4);
     const unsigned int n_couplings = system_dof_handler.max_couplings_between_dofs();

     pre_sparsity_pattern.block(0,0).reinit (n_v, n_v, n_couplings);
     pre_sparsity_pattern.block(1,0).reinit (n_p, n_v, n_couplings);
     pre_sparsity_pattern.block(2,0).reinit (n_l, n_v, n_couplings);
     pre_sparsity_pattern.block(3,0).reinit (n_m, n_v, n_couplings);

     pre_sparsity_pattern.block(0,1).reinit (n_v, n_p, n_couplings);
     pre_sparsity_pattern.block(1,1).reinit (n_p, n_p, n_couplings);
     pre_sparsity_pattern.block(2,1).reinit (n_l, n_p, n_couplings);
     pre_sparsity_pattern.block(3,1).reinit (n_m, n_p, n_couplings);

     pre_sparsity_pattern.block(0,2).reinit (n_v, n_l, n_couplings);
     pre_sparsity_pattern.block(1,2).reinit (n_p, n_l, n_couplings);
     pre_sparsity_pattern.block(2,2).reinit (n_l, n_l, n_couplings);
     pre_sparsity_pattern.block(3,2).reinit (n_m, n_l, n_couplings);

     pre_sparsity_pattern.block(0,3).reinit (n_v, n_m, n_couplings);
     pre_sparsity_pattern.block(1,3).reinit (n_p, n_m, n_couplings);
     pre_sparsity_pattern.block(2,3).reinit (n_l, n_m, n_couplings);
     pre_sparsity_pattern.block(3,3).reinit (n_m, n_m, n_couplings);
     pre_sparsity_pattern.collect_sizes();  //what is this for? yes, needed when we touch each block separately!,

     DoFTools::make_sparsity_pattern (system_dof_handler,
                       pre_sparsity_pattern,
                       preconditioner_constraints,
                       true);

      pre_sparsity_pattern.compress();
      preconditioner_matrix.reinit(pre_sparsity_pattern);
  }

     matrix_constraints_nil.clear();
     matrix_constraints_nil.close();

    {
     sub_matrix_H1.clear ();
     sub_matrix_H2.clear ();
     sparsity_pattern_block_H.reinit (2,2);
     const unsigned int n_couplings = system_dof_handler_block_H1.max_couplings_between_dofs();

     sparsity_pattern_block_H.block(0,0).reinit (n_v, n_v, n_couplings);
     sparsity_pattern_block_H.block(1,0).reinit (n_p, n_v, n_couplings);
     sparsity_pattern_block_H.block(0,1).reinit (n_v, n_p, n_couplings);
     sparsity_pattern_block_H.block(1,1).reinit (n_p, n_p, n_couplings);

     sparsity_pattern_block_H.collect_sizes();  //what is this for? yes, needed when we touch each block separately!,

     DoFTools::make_sparsity_pattern( system_dof_handler_block_H1,
                       sparsity_pattern_block_H,matrix_constraints_nil,
                       true);
      sparsity_pattern_block_H.compress();
      sub_matrix_H1.reinit (sparsity_pattern_block_H);
      sub_matrix_H2.reinit (sparsity_pattern_block_H);

     }



     solution.reinit (4);
     solution.block(0).reinit (n_v);
     solution.block(1).reinit (n_p);
     solution.block(2).reinit (n_l);
     solution.block(3).reinit (n_m);
     solution.collect_sizes ();

     system_rhs.reinit (4);
     system_rhs.block(0).reinit (n_v);
     system_rhs.block(1).reinit (n_p);
     system_rhs.block(2).reinit (n_l);
     system_rhs.block(3).reinit (n_m);
     system_rhs.collect_sizes ();

   zero_vector.reinit (4);
   zero_vector.block(0).reinit (n_v);
   zero_vector.block(1).reinit (n_p);
   zero_vector.block(2).reinit (n_l);
   zero_vector.block(3).reinit (n_m);
   zero_vector.collect_sizes ();
   zero_vector=0;



   cout<<"dofs initialized ..."<<endl;
 }


 /////////////////////assemble_constant_matrix(K,M)///////////////
 template <int dim>
 void OptimalControl<dim>::assemble_constant_matrix_equation ()
 {

     system_matrix= 0;
     preconditioner_matrix= 0;
     system_rhs = 0;

     sub_matrix_H1=0;
     sub_matrix_H2=0;

     const FEValuesExtractors::Vector component_v(0);
     const FEValuesExtractors::Scalar component_p(2);
     const FEValuesExtractors::Vector component_l(3);
     const FEValuesExtractors::Scalar component_m(5);


     const unsigned int   dofs_per_cell   = system_fe.dofs_per_cell;


     FullMatrix<double>   local_00_MM_matrix(dofs_per_cell, dofs_per_cell),

                          local_02_FF_matrix(dofs_per_cell, dofs_per_cell),
                          local_03_DD_matrix(dofs_per_cell, dofs_per_cell),

                          local_12_DD_matrix(dofs_per_cell, dofs_per_cell),

                          local_20_FF_matrix(dofs_per_cell, dofs_per_cell),
                          local_21_DD_matrix(dofs_per_cell, dofs_per_cell),
                          local_22_MM_matrix(dofs_per_cell, dofs_per_cell),

                          local_30_DD_matrix(dofs_per_cell, dofs_per_cell),

                          local_02_MpF_amg_matrix(dofs_per_cell, dofs_per_cell),
                          local_11_FF_pre_matrix(dofs_per_cell, dofs_per_cell),
                          local_33_MM_pre_matrix(dofs_per_cell, dofs_per_cell),

                          local_13_MM_pre_matrix(dofs_per_cell, dofs_per_cell),
                          local_22_MFF_pre_matrix(dofs_per_cell, dofs_per_cell),
                          local_23_DD_pre_matrix(dofs_per_cell, dofs_per_cell),
                          local_32_DD_pre_matrix(dofs_per_cell, dofs_per_cell);



     FullMatrix<double>   local_matrix(dofs_per_cell, dofs_per_cell),
                          local_H1_matrix(dofs_per_cell, dofs_per_cell),
                          local_H2_matrix(dofs_per_cell, dofs_per_cell),
                          local_pre_matrix(dofs_per_cell, dofs_per_cell);



    Vector<double>         local_rhs (dofs_per_cell);

    QGauss<dim>   quadrature_formula (degree+2);
    FEValues<dim> fe_values (system_fe, quadrature_formula,
                                        update_values    | update_gradients | update_quadrature_points |
                                        update_JxW_values);

   const unsigned int   n_q_points      = quadrature_formula.size();

   std::vector<unsigned int> local_dof_indices (dofs_per_cell);


   Tensor<1,dim>
                 component_v_phi_i(dofs_per_cell),
                 component_l_phi_i(dofs_per_cell),

                 component_v_phi_j(dofs_per_cell),
                 component_l_phi_j(dofs_per_cell);


   double  component_p_phi_i(dofs_per_cell),
           component_m_phi_i(dofs_per_cell),
           component_p_phi_j(dofs_per_cell),
           component_m_phi_j(dofs_per_cell);

   double
             component_v_div_phi_i  (dofs_per_cell),
             component_l_div_phi_i  (dofs_per_cell),

             component_v_div_phi_j  (dofs_per_cell),
             component_l_div_phi_j  (dofs_per_cell);


   Tensor<1,dim> component_p_grad_phi_i (dofs_per_cell),
                 component_m_grad_phi_i (dofs_per_cell),
                 component_p_grad_phi_j (dofs_per_cell),
                 component_m_grad_phi_j (dofs_per_cell);


   Tensor<2,dim>
                          component_v_grad_phi_i,
                          component_l_grad_phi_i,
                          component_v_grad_phi_j,
                          component_l_grad_phi_j;



   const Stokes::VelocityFieldControlValues<dim> velocity_field_control(6);


   std::vector< Tensor<1, dim> >  velocity_field_control_values( n_q_points, Tensor<1, dim> ());

   cout<<"n_q_points "<<n_q_points<<endl;




   typename DoFHandler<dim>::active_cell_iterator
   cell = system_dof_handler.begin_active(),
   endc = system_dof_handler.end();

   for (; cell!=endc; ++cell)
     {
       /*Reinitialize the cell */
       fe_values.reinit (cell);

       std::vector<Point<dim>> p_list=fe_values.get_quadrature_points();
       velocity_field_control.vector_value_list (p_list, velocity_field_control_values);

       local_00_MM_matrix = 0;
       local_02_FF_matrix = 0;
       local_03_DD_matrix = 0;
       local_12_DD_matrix = 0;
       local_20_FF_matrix = 0;
       local_21_DD_matrix = 0;
       local_22_MM_matrix = 0;
       local_30_DD_matrix = 0;


       local_02_MpF_amg_matrix = 0;
       local_11_FF_pre_matrix  = 0;
       local_33_MM_pre_matrix  = 0;

       local_11_FF_pre_matrix  = 0;
       local_13_MM_pre_matrix  = 0;
       local_22_MFF_pre_matrix = 0;
       local_23_DD_pre_matrix  = 0;
       local_32_DD_pre_matrix  = 0;

       local_matrix     = 0;
       local_H1_matrix   = 0;
       local_H2_matrix   = 0;
       local_pre_matrix = 0;

       local_rhs=0;

       for (unsigned int q=0; q<n_q_points; ++q){

           /*creating the matrix
             A=[M  0  K
                0 BM -M
                K -M  0
                where M is mass and K is stiffnexx matrix
               */

           for (unsigned int i=0; i<dofs_per_cell; ++i){


               component_v_phi_i      = fe_values[component_v].value (i, q);
               component_l_phi_i      = fe_values[component_l].value (i, q);
               component_m_phi_i      = fe_values[component_m].value (i, q);
               component_p_phi_i      = fe_values[component_p].value (i, q);



               component_v_div_phi_i  = fe_values[component_v].divergence(i,q);
               component_l_div_phi_i  = fe_values[component_l].divergence(i,q);
               component_m_grad_phi_i = fe_values[component_m].gradient(i,q);
               component_p_grad_phi_i = fe_values[component_p].gradient(i,q);

               component_v_grad_phi_i = fe_values[component_v].gradient(i,q);
               component_l_grad_phi_i = fe_values[component_l].gradient(i,q);


             for (unsigned int j=0; j<dofs_per_cell; ++j)
               {

                 component_v_phi_j      = fe_values[component_v].value (j, q);
                 component_l_phi_j      = fe_values[component_l].value (j, q);
                 component_m_phi_j      = fe_values[component_m].value (j, q);
                 component_p_phi_j      = fe_values[component_p].value (j, q);



                 component_v_div_phi_j  = fe_values[component_v].divergence(j,q);
                 component_l_div_phi_j  = fe_values[component_l].divergence(j,q);
                 component_m_grad_phi_j = fe_values[component_m].gradient(j,q);
                 component_p_grad_phi_j = fe_values[component_p].gradient(j,q);




                 component_v_grad_phi_j = fe_values[component_v].gradient(j,q);
                 component_l_grad_phi_j = fe_values[component_l].gradient(j,q);


                 local_00_MM_matrix(i, j)  =    (component_v_phi_i * component_v_phi_j)*fe_values.JxW(q);
                 local_02_FF_matrix(i, j)  =    scalar_product(component_v_grad_phi_i,  component_l_grad_phi_j)*fe_values.JxW(q);
                 local_03_DD_matrix(i, j)  =   -(component_v_div_phi_i*component_m_phi_j)*fe_values.JxW(q);


                 local_12_DD_matrix(i, j)  =   -(component_p_phi_i*component_l_div_phi_j)*fe_values.JxW(q);


                 local_20_FF_matrix(i, j) =     scalar_product(component_l_grad_phi_i,  component_v_grad_phi_j)*fe_values.JxW(q);
                 local_21_DD_matrix(i, j) =    -(component_l_div_phi_i*component_p_phi_j)*fe_values.JxW(q);

                 local_22_MM_matrix(i, j) =     (component_l_phi_i*component_l_phi_j)*fe_values.JxW(q);

                 local_30_DD_matrix(i, j) =    -(component_m_phi_i*component_v_div_phi_j)*fe_values.JxW(q);



                 local_11_FF_pre_matrix(i, j)   = (component_p_grad_phi_i * component_p_grad_phi_j)*fe_values.JxW(q);
                 local_33_MM_pre_matrix(i, j)   = (component_m_phi_i * component_m_phi_j)*fe_values.JxW(q);
                 local_22_MFF_pre_matrix(i, j)  = (component_v_phi_i*component_v_phi_j+sqrt(EquationData::beta_hat)*scalar_product(component_v_grad_phi_i, component_v_grad_phi_j))*fe_values.JxW(q);


                 /*[M   0   F   D]
                    0   0   D   0
                    F   D   0   0
                    D   0   0   0   */
                 local_matrix(i,j) += local_00_MM_matrix(i, j)+local_02_FF_matrix(i, j)+local_03_DD_matrix(i, j)+
                                                               local_12_DD_matrix(i, j)+
                                      local_20_FF_matrix(i, j)+local_21_DD_matrix(i, j)+local_22_MM_matrix(i, j)+
                                      local_30_DD_matrix(i, j);


                 /*This is not very efficient
                   [S   0   0   0]
                    0   K   0   0
                    0   0   0   0
                    0   0   0   M]   */

                 local_pre_matrix(i,j) += local_11_FF_pre_matrix(i, j)+
                                          local_22_MFF_pre_matrix(i, j)+
                                          local_33_MM_pre_matrix(i, j);



             }


            /*Creating RHS
             [v
              p
              l
              m] */


            local_rhs(i) +=
                            velocity_field_control_values[q]*
                            component_v_phi_i*
                            fe_values.JxW(q);

           }


       }
           cell->get_dof_indices (local_dof_indices);
           matrix_constraints.distribute_local_to_global (local_matrix,
                                                          local_rhs,
                                                          local_dof_indices,
                                                          system_matrix,
                                                          system_rhs);





           preconditioner_constraints.distribute_local_to_global (local_pre_matrix,
                                                          local_dof_indices,
                                                          preconditioner_matrix
                                                          );




     }

   sub_matrix_H1.block(0,0).add(1.0, preconditioner_matrix.block(0,0));
   sub_matrix_H1.block(0,1).add(sqrt(EquationData::beta_hat), system_matrix.block(2,1));
   sub_matrix_H1.block(1,0).add(sqrt(EquationData::beta_hat), system_matrix.block(3,0));

   sub_matrix_H2.block(0,0).add(1.0, preconditioner_matrix.block(0,0));
   sub_matrix_H2.block(0,1).add(sqrt(EquationData::beta_hat), system_matrix.block(2,1));
   sub_matrix_H2.block(1,0).add(sqrt(EquationData::beta_hat), system_matrix.block(3,0));

  if(SCALED==0){

   system_matrix.block(0,2) *=EquationData::beta_hat;
   system_matrix.block(0,3) *=EquationData::beta_hat;
   system_matrix.block(1,2) *=EquationData::beta_hat;
   }

  if(SCALED==1){
      system_matrix.block(0,2) *=sqrt(EquationData::beta_hat);
      system_matrix.block(0,3) *=sqrt(EquationData::beta_hat);
      system_matrix.block(1,2) *=sqrt(EquationData::beta_hat);

      system_matrix.block(2,0) *=sqrt(EquationData::beta_hat);
      system_matrix.block(3,0) *=sqrt(EquationData::beta_hat);
      system_matrix.block(2,1) *=sqrt(EquationData::beta_hat);
  }

  system_matrix.block(0, 2) *=-1.0;
  system_matrix.block(0, 3) *=-1.0;
  system_matrix.block(1, 2) *=-1.0;

  //system_rhs *=EquationData::beta;

     system_matrix.compress(VectorOperation::add);

     preconditioner_matrix.compress(VectorOperation::add);
     sub_matrix_H1.compress(VectorOperation::add);
     sub_matrix_H2.compress(VectorOperation::add);
     system_rhs.compress(VectorOperation::add);


     cout<<"system Assembled..."<<endl;


 }

template <int dim>
void OptimalControl<dim>::solve ()
{

        /*set the Preconditioner */
        const LinearSolvers::InverseMatrix<TrilinosWrappers::SparseMatrix, TrilinosWrappers::PreconditionAMG> k_inverse_1 (preconditioner_matrix.block(0,0),*amg_preconditioner_1, Iterations::AMG,ToleranceLimits::inner_solver_amg);
        const LinearSolvers::InverseMatrix<TrilinosWrappers::SparseMatrix, TrilinosWrappers::PreconditionAMG> k_inverse_2 (preconditioner_matrix.block(1,1),*amg_preconditioner_2, Iterations::AMG,ToleranceLimits::inner_solver_amg);

        const LinearSolvers::InverseMatrix<TrilinosWrappers::SparseMatrix, TrilinosWrappers::PreconditionChebyshev> Mp_inverse_1 (preconditioner_matrix.block(3,3),*cb_preconditioner_1, Iterations::CHEBYCHEV,ToleranceLimits::inner_solver_chb);

        BlockHPreconditioner<TrilinosWrappers::PreconditionAMG, TrilinosWrappers::PreconditionChebyshev>
                block_H1_preconditioner (
                                         sub_matrix_H1,
                                         Mp_inverse_1,
                                         k_inverse_1,
                                         k_inverse_2,
                                         0,
                                         n_v, n_p);
        BlockHPreconditioner<TrilinosWrappers::PreconditionAMG, TrilinosWrappers::PreconditionChebyshev>
                block_H2_preconditioner (
                                         sub_matrix_H2,
                                         Mp_inverse_1,
                                         k_inverse_1,
                                         k_inverse_2,
                                         0,
                                         n_v, n_p);


        /*This is how the preconditioner looks like
          [M   H_2]
           H_1   S  */
        const BlockPreconditioner<TrilinosWrappers::PreconditionAMG, TrilinosWrappers::PreconditionChebyshev, TrilinosWrappers::PreconditionBlockwiseDirect> preconditioner (system_matrix,
                                                                                                                              sub_matrix_H1,
                                                                                                                              sub_matrix_H2,
                                                                                                                              preconditioner_matrix,
                                                                                                                              block_H1_preconditioner,
                                                                                                                              block_H2_preconditioner,
                                                                                                                              Mp_inverse_1,
                                                                                                                              k_inverse_1,
                                                                                                                              k_inverse_2,
                                                                                                                              n_v, n_p);





        double tolerance_level = system_rhs.l2_norm()*ToleranceLimits::outer_solver;

        /*Initialize the SolverControl */
        SolverControl solver_control (Iterations::outer_solver, tolerance_level ,false,false);
        SolverFGMRES<TrilinosWrappers::BlockVector> fgmres (solver_control);
         SolverGMRES<TrilinosWrappers::BlockVector>  gmres (solver_control, SolverGMRES<TrilinosWrappers::BlockVector>::AdditionalData(1000));

        solution = 0;
        double time=0;
        try{
            if(solver_type==SolverType::FGMRES){
            timer.restart();
            fgmres.solve(system_matrix , solution, system_rhs, preconditioner);

            time=timer.wall_time();
            }else  if(solver_type==SolverType::GMRES){
                timer.restart();
                gmres.solve(system_matrix , solution, system_rhs, preconditioner);
                time=timer.wall_time();
            }

            cout<<"FGMRES ... done "<<endl;


            matrix_constraints.distribute (solution);
           // solution.block(0) *=1.0/EquationData::beta;
           // solution.block(1) *=1.0/EquationData::beta;
            solution.block(2) *= 1.0/sqrt(EquationData::beta_hat);
            solution.block(3) *= sqrt(EquationData::beta_hat);

       }catch (std::exception &e){
           Assert(true, ExcMessage(e.what()));
       }

        if(solver_control.last_step() !=0.0){

         double KKT_residual = solver_control.last_value();

         cout << "   "
              << KKT_residual
              << " is the final residual"
              << std::endl
              << solver_control.last_step() //<<"("<<LinearSolvers::cb_it<<"/"<<LinearSolvers::amg_it<<")"
              << " GMRES iterations for system."
              << std::endl
              << EquationData::inner_fgmres_iterations_H1/(solver_control.last_step()+1)
              << " avg inner fgmres iterations for system."
              << std::endl
              << EquationData::inner_fgmres_iterations_H2/(solver_control.last_step()+1)
              << " avg inner fgmres iterations for system."
              << std::endl
              << LinearSolvers::amg_it/(solver_control.last_step()+1)
              << " avg inner amg iterations for system."
              << std::endl
              << LinearSolvers::cb_it/(solver_control.last_step()+1)
              << " avg inner chebyshev solver iterations for system."
              << std::endl
              << "time "<<time //<<"("<<LinearSolvers::cb_timer_in_sec<<"/"<<LinearSolvers::amg_timer_in_sec<<")"
              << std::endl
              << "done ...."
              << std::endl;

         cout<<" is the max element of v is "<<*std::max_element(solution.block(0).begin(), solution.block(0).end())<<endl
             <<" is the min element of v is "<<*std::min_element(solution.block(0).begin(), solution.block(0).end())<<endl
             <<" is the max element of l is "<<*std::max_element(solution.block(2).begin(), solution.block(2).end())<<endl
             <<" is the min element of l is "<<*std::min_element(solution.block(2).begin(), solution.block(2).end())<<endl
              <<endl;

        compute_errors ();


        process_solution(table, solver_control.last_step(), KKT_residual, time);

    }
}







template <int dim>
void OptimalControl<dim>::output_results () const
{
  std::ofstream output1;
  output1.open ("Mv.txt");
  system_matrix.block(0,0).print(output1);
  output1.close();


  output1.open ("Kv.txt");
  system_matrix.block(2,0).print(output1);
  output1.close();


  output1.open ("D.txt");
  system_matrix.block(3,0).print(output1);
  output1.close();

  output1.open ("Kp.txt");
  preconditioner_matrix.block(1,1).print(output1);
  output1.close();

  output1.open ("Mp.txt");
  preconditioner_matrix.block(3,3).print(output1);
  output1.close();

  output1.open ("H1.txt");
  sub_matrix_H1.block(0,0).print(output1);
  output1.close();


  output1.open ("v_rhs.txt");
  system_rhs.block(0).print(output1);
  output1.close();


  output1.open ("p_rhs.txt");
  system_rhs.block(1).print(output1);
  output1.close();

  output1.open ("l_rhs.txt");
  system_rhs.block(2).print(output1);
  output1.close();

  output1.open ("m_rhs.txt");
  system_rhs.block(3).print(output1);
  output1.close();

  output1.open ("p_sol.txt");
  solution.block(1).print(output1);
  output1.close();

}


    template <int dim>
    void OptimalControl<dim>::output_results_vtk () const
    {
        std::vector<std::string> solution_names;
        solution_names.push_back ("vi");
        solution_names.push_back ("vj");
        solution_names.push_back ("p");
        solution_names.push_back ("li");
        solution_names.push_back ("lj");

        solution_names.push_back ("m");


        std::vector<DataComponentInterpretation::DataComponentInterpretation> data_component_interpretation;

        data_component_interpretation.push_back (DataComponentInterpretation::component_is_part_of_vector);
        data_component_interpretation.push_back (DataComponentInterpretation::component_is_part_of_vector);
        data_component_interpretation.push_back (DataComponentInterpretation::component_is_scalar);
        data_component_interpretation.push_back (DataComponentInterpretation::component_is_part_of_vector);
        data_component_interpretation.push_back (DataComponentInterpretation::component_is_part_of_vector);

        data_component_interpretation.push_back (DataComponentInterpretation::component_is_scalar);


        DataOut<dim> data_out;
        data_out.attach_dof_handler (system_dof_handler);
        data_out.add_data_vector (solution, solution_names,
                                  DataOut<dim>::type_dof_data,
                                  data_component_interpretation);
        data_out.build_patches ();
        std::ostringstream filename;
        filename << "solution"
                 << ".vtk";
        std::ofstream output (filename.str().c_str());
        data_out.write_vtk (output);

    }






template <int dim>
void OptimalControl<dim>::initialize_preconditioner(){
        /*Defing the AMG Preconditioner */
    TrilinosWrappers::PreconditionAMG::AdditionalData Amg_data_1;
    TrilinosWrappers::PreconditionAMG::AdditionalData Amg_data_2;

    std::vector<std::vector<bool> > constant_modes;
    FEValuesExtractors::Vector velocity_components(0);
    DoFTools::extract_constant_modes (system_dof_handler_block_H1,
    system_fe_block_H1.component_mask(velocity_components), constant_modes);
    Amg_data_1.constant_modes=constant_modes;

    Amg_data_1.higher_order_elements = true;

    Amg_data_1.elliptic = true;
    Amg_data_1.n_cycles = 1;
    Amg_data_1.smoother_sweeps = 2;
    Amg_data_1.aggregation_threshold = 0.8;
    Amg_data_1.smoother_type = "symmetric Gauss-Seidel";

    Amg_data_2.elliptic = true;
    Amg_data_2.n_cycles = 1;
    Amg_data_2.smoother_sweeps = 2;
    Amg_data_2.aggregation_threshold = 0.8;
    Amg_data_2.smoother_type = "symmetric Gauss-Seidel";



    cout<<"coarse type is "<<Amg_data_1.coarse_type<<endl;
    ///this is for velocity
    amg_preconditioner_1 = std_cxx1x::shared_ptr<TrilinosWrappers::PreconditionAMG> (new TrilinosWrappers::PreconditionAMG());
    amg_preconditioner_1->initialize(preconditioner_matrix.block(0,0), Amg_data_1);
    //this is for pressure
    amg_preconditioner_2 = std_cxx1x::shared_ptr<TrilinosWrappers::PreconditionAMG> (new TrilinosWrappers::PreconditionAMG());
    amg_preconditioner_2->initialize(preconditioner_matrix.block(1,1), Amg_data_2);
    //this is redundant


    /*defining IC */
    cb_preconditioner_1 = std_cxx1x::shared_ptr<TrilinosWrappers::PreconditionChebyshev> (new TrilinosWrappers::PreconditionChebyshev());
    cb_preconditioner_1->initialize(preconditioner_matrix.block(3,3));


}

template <int dim>
void OptimalControl<dim>::run ()
{


    int beta_values_length =beta_values.size();
    //int inner_tolerance_length =inner_tolerance.size();
    int refinements_length =refinements.size();
    LinearSolvers::error_list.clear();
    table.clear();
    table_for_solution_data.clear();
    set_table_labels();


    for (unsigned int i=0;i<beta_values_length;i++)
    //for (unsigned int i=0;i<inner_tolerance_length;i++)
        for (unsigned int j=0;j<refinements_length;j++){

        n_refs=double(refinements[j]);
        EquationData::beta = double(beta_values[i]);
        EquationData::beta_hat=EquationData::beta/(1.0+EquationData::beta*EquationData::omega*EquationData::omega);

        LinearSolvers::beta_value=EquationData::beta;
        LinearSolvers::n_refs=n_refs;


        h = std::pow(0.5, (n_refs));
        cout << "mesh size: " << h<< std::endl<<
                "number of refinements: " <<n_refs<< std::endl<<
                "beta: " <<EquationData::beta<< std::endl<<
                "beta_hat: " <<EquationData::beta_hat<< std::endl<<
                "h/beta: "<<(h/EquationData::beta)<<std::endl;

     make_grid_and_dofs (n_refs);
     assemble_constant_matrix_equation ();

     initialize_preconditioner();
     solve ();

     output_results ();
     output_results_vtk ();

     triangulation.clear();
     amg_preconditioner_1->clear();
     amg_preconditioner_2->clear();
     cb_preconditioner_1->clear();


     LinearSolvers::cg_it=0;
     LinearSolvers::cb_it=0;
     LinearSolvers::amg_it=0;
     EquationData::inner_fgmres_iterations_H1=0;
     EquationData::inner_fgmres_iterations_H2=0;
     }




    table.set_tex_table_caption(tex_table_caption);
    MiscUtilities::print_tex_tables(tex_file_name, solver_type, table);
    MiscUtilities::print_tex_tables_for_solution_data(table_for_solution_data, "solution_data");
    MiscUtilities::print_table_data_for_h_blocks  (text_table_file_name, beta_values_length, refinements_length, table_data_list);
    table_data_list.clear();

}

template <int dim>
void OptimalControl<dim>::set_table_labels(){


   if(Stokes::p_type==Stokes::PreconditionerType::B_FACTORIZATION){
        std::stringstream ss;
        //ss << std::scientific << std::setprecision(1) << ToleranceLimits::h_block_solver;
        ss << std::scientific << std::setprecision(1) << EquationData::omega;
        string caption ="Problem("+std::to_string(ConvectionDiffusion::solve_problem_type)+"): "+"$P_{F}:\\omega="+ss.str()+"$"+" : H iter="+std::to_string(Iterations::h_block);
        tex_table_caption=caption;

        tex_file_name="block_factorization";
        text_table_file_name="block_factorization";
        vtk_tile_name="B_FACTORIZATION";
      }
}


template <int dim>
void OptimalControl<dim>::process_solution(TableHandler &table, unsigned int iterations, double tolerance, double time){



    MiscUtilities::TableData td;
    td.dofs=system_dof_handler.n_dofs();
    td.beta=EquationData::beta;
    td.beta_hat=EquationData::beta_hat;
    td.iterations=iterations;

    td.h1_iterations=EquationData::inner_fgmres_iterations_H1/(iterations+1);
    td.h2_iterations=EquationData::inner_fgmres_iterations_H2/(iterations+1);


    td.k_iterations= Iterations::AMG*4;
    td.m_iterations= Iterations::CHEBYCHEV*2;

    td.time=time;
    table_data_list.push_back(td);


    table.add_value("dofs", n_v+n_l+n_m+n_p);
    table.add_value("ref", n_refs);
    table.add_value("$\\beta$",EquationData::beta);
    table.add_value("$\\widetilde{\\beta}$",EquationData::beta_hat);

    table.add_value("iter",iterations);
    string H_blocks=std::to_string(td.h1_iterations)+"+"+std::to_string(td.h2_iterations);
    string AMG_M_blocks=std::to_string(td.k_iterations)+"+"+std::to_string(td.m_iterations);
    table.add_value("$\\hat{M}$",H_blocks);
    table.add_value("$\\hat{S}$",AMG_M_blocks);
    table.add_value("$|u|_{2}$",u_l2_norm);
    table.add_value("$\|u\|_{\\infty}$",solution.block(2).linfty_norm());
    table.add_value("$\|y-\\hat{y}\|$",y_yd_l2_norm);
    table.add_value("$\|y-\\hat{y}\|/|\\hat{y}\|$",rel_y_yd_l2_norm);
    table.add_value("$J$",cost_functional_J);
    table.add_value("Tol",tolerance);
    table.add_value("time",time);

    table_for_solution_data.add_value("dofs", n_v+n_l+n_m+n_p);
    table_for_solution_data.add_value("$p_{max}$", *std::max_element(solution.block(1).begin(), solution.block(1).end()));
    table_for_solution_data.add_value("$p_{min}$", *std::min_element(solution.block(1).begin(), solution.block(1).end()));
    table_for_solution_data.add_value("$\|p\|_{\\infty}$", solution.block(1).linfty_norm());
    table_for_solution_data.add_value("$m_{max}$", *std::max_element(solution.block(3).begin(), solution.block(3).end()));
    table_for_solution_data.add_value("$m_{min}$", *std::min_element(solution.block(3).begin(), solution.block(3).end()));
    table_for_solution_data.add_value("$\|m\|_{\\infty}$", solution.block(3).linfty_norm());
    table_for_solution_data.add_value("$|u|_{2}$",u_l2_norm);
    table_for_solution_data.add_value("$\|u\|_{\\infty}$",solution.block(2).linfty_norm());
    table_for_solution_data.add_value("$|y|_{2}$",solution.block(0).l2_norm());
    table_for_solution_data.add_value("$\|y\|_{\\infty}$",solution.block(0).linfty_norm());

}



template <int dim>
void OptimalControl<dim>::compute_errors ()
{
    const ComponentSelectFunction<dim> y_mask(std::make_pair(0, 1), 6);
    Stokes::ExactVelocityFieldControlValues<dim> desired_solution(6);

    unsigned int n_cells=triangulation.n_active_cells();
    Vector<double> cellwise_errors (n_cells);
    //QTrapez<1> q_trapez;
    QGauss<dim-1> q_trapez(degree+1);
    QIterated<dim> quadrature (q_trapez, degree+2);


   VectorTools::integrate_difference (system_dof_handler,
                                       solution,
                                       desired_solution,
                                       cellwise_errors,
                                       quadrature,
                                       VectorTools::L2_norm,
                                       &y_mask);
    y_yd_l2_norm= cellwise_errors.l2_norm();

    VectorTools::integrate_difference (system_dof_handler,
                                       zero_vector,
                                       desired_solution,
                                       cellwise_errors,
                                       quadrature,
                                       VectorTools::L2_norm,
                                       &y_mask);


   cout<<"cellwise "<<cellwise_errors.l2_norm()<<endl;
   rel_y_yd_l2_norm =y_yd_l2_norm/cellwise_errors.l2_norm();
   u_l2_norm=solution.block(2).l2_norm();


    cost_functional_J =0.5*(y_yd_l2_norm*y_yd_l2_norm)+0.5*EquationData::beta*(u_l2_norm*u_l2_norm);
    cout<<"cost functional J = "<<cost_functional_J<<endl<<
          "||y-yd||       = "<< y_yd_l2_norm<<endl<<
          "||y-yd||/yd    = "<< rel_y_yd_l2_norm<<endl<<
          "||u||          = "<<u_l2_norm<<endl;

}

template <int dim>
void OptimalControl<dim>::start(){
   beta_values = {pow(10,-2), pow(10,-3), pow(10,-4), pow(10,-5), pow(10,-6), pow(10,-7), pow(10,-8), pow(10,-9), pow(10,-10)};
   refinements =  {4, 5, 6, 7};


    //beta_values = {pow(10, -10)};
    //beta_values = {2*pow(10,-2), 2*pow(10,-3), 2*pow(10,-4), 2*pow(10,-5), 2*pow(10,-6), pow(10,-7), 2*pow(10,-8), 2*pow(10,-9), 2*pow(10,-10)};
    //refinements =  {4};
    EquationData::omega=pow(10.0, -4);

    SCALED=0;
    //Stokes::solve_problem_type=Stokes::Problem_Type::LID_DRIVEN_CAVITY;
    Stokes::solve_problem_type=Stokes::Problem_Type::VELOCITY_TRACKING_1;
    cout<<"problem type is "<<Stokes::solve_problem_type<<endl;
    total_time.restart();

    Stokes::p_type=Stokes::PreconditionerType::B_FACTORIZATION;
    solver_type=SolverType::GMRES;
    run ();


    /*unsigned int error_list=LinearSolvers::error_list.size();
    if( error_list>0){
        cout<<endl;
        for(int i=0;i<error_list;i++){
            PreconditionerError p=((PreconditionerError)LinearSolvers::error_list[i]);
            cout<<p.n_refs<<" "<<p.beta_value<<" "<<p.preconditioner_name<<" "<<p.solver_last_value<<" "<<p.target_tolerance<<endl;
        }
    }*/

    cout<<"ALL COMPUTATIONS ENDED "<<total_time.wall_time()/60.0<<endl;


}

int main (int argc, char *argv[])
{
  Utilities::MPI::MPI_InitFinalize mpi_initialization(argc, argv);
  std::ofstream logfile("deallog");
  deallog.attach(logfile);
  deallog.depth_console(1);

  //deallog.depth_console(0);
  OptimalControl<2> p_control(1);
  p_control.start();

  return 0;
}

