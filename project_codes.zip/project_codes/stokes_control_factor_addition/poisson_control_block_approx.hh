
template <class PreconditionerA, class PreconditionerB>
class PoissonControlBlockPreconditioner : public Subscriptor
{
  public:
    PoissonControlBlockPreconditioner(const TrilinosWrappers::BlockSparseMatrix  &S,
                         const LinearSolvers::InverseMatrix<TrilinosWrappers::SparseMatrix, PreconditionerB> &preconditioner_inv,
                         const LinearSolvers::InverseMatrix<TrilinosWrappers::SparseMatrix, PreconditionerA> &amg_1,
                         const LinearSolvers::InverseMatrix<TrilinosWrappers::SparseMatrix, PreconditionerA> &amg_2
                         );

    void vmult (TrilinosWrappers::BlockVector &dst,
                const TrilinosWrappers::BlockVector &src) const;

    /*void implement_reduced_preconditioner(TrilinosWrappers::BlockVector &dst,
                           const TrilinosWrappers::BlockVector &src) const;*/

    void implement_reduced_preconditioner_petia(TrilinosWrappers::BlockVector &dst,
                                           const TrilinosWrappers::BlockVector &src) const;

    void implement_pmhss(TrilinosWrappers::BlockVector &dst,
                                           const TrilinosWrappers::BlockVector &src) const;
    void implement_unscaled_norm_based(TrilinosWrappers::BlockVector &dst,
                                           const TrilinosWrappers::BlockVector &src) const;

    void implement_scaled_norm_based(TrilinosWrappers::BlockVector &dst,
                                           const TrilinosWrappers::BlockVector &src) const;

    void implement_pearson_diagonal_preconditioner(TrilinosWrappers::BlockVector &dst,
                           const TrilinosWrappers::BlockVector &src) const;

    void implement_reduced_preconditioner(TrilinosWrappers::BlockVector &dst, const TrilinosWrappers::BlockVector &src) const;

  private:
    const SmartPointer<const TrilinosWrappers::BlockSparseMatrix> preconditioner_matrix;
    const SmartPointer<const LinearSolvers::InverseMatrix<TrilinosWrappers::SparseMatrix, PreconditionerB> > m_inv;
    const SmartPointer<const LinearSolvers::InverseMatrix<TrilinosWrappers::SparseMatrix, PreconditionerA> > amg_1;
    const SmartPointer<const LinearSolvers::InverseMatrix<TrilinosWrappers::SparseMatrix, PreconditionerA> > amg_2;

    mutable TrilinosWrappers::Vector y, u, p, b1, b2;
    mutable TrilinosWrappers::Vector g1, g2, g3;
    mutable TrilinosWrappers::Vector tmp1, tmp2, tmp3;
    mutable TrilinosWrappers::BlockVector bv;

};

template <class PreconditionerA, class PreconditionerB>
PoissonControlBlockPreconditioner<PreconditionerA, PreconditionerB>::
PoissonControlBlockPreconditioner(const TrilinosWrappers::BlockSparseMatrix  &S,
                    const LinearSolvers::InverseMatrix<TrilinosWrappers::SparseMatrix, PreconditionerB> &_m_inv,
                    const LinearSolvers::InverseMatrix<TrilinosWrappers::SparseMatrix, PreconditionerA> &_amg_1,
                    const LinearSolvers::InverseMatrix<TrilinosWrappers::SparseMatrix, PreconditionerA> &_amg_2)
                :
                preconditioner_matrix   (&S),
                m_inv                   (&_m_inv),
                amg_1                   (&_amg_1),
                amg_2                   (&_amg_2),
                g1                      (preconditioner_matrix->block(0,0).m()),
                g2                      (preconditioner_matrix->block(0,0).m()),
                g3                      (preconditioner_matrix->block(0,0).m()),
                b1                      (preconditioner_matrix->block(0,0).m()),
                b2                      (preconditioner_matrix->block(0,0).m()),
                tmp1                    (preconditioner_matrix->block(0,0).m()),
                tmp2                    (preconditioner_matrix->block(0,0).m()),
                tmp3                    (preconditioner_matrix->block(0,0).m()),
                y                       (preconditioner_matrix->block(0,0).m()),
                u                       (preconditioner_matrix->block(0,0).m()),
                p                       (preconditioner_matrix->block(0,0).m())
{}

template <class PreconditionerA, class PreconditionerB>
void PoissonControlBlockPreconditioner<PreconditionerA, PreconditionerB >::vmult (
  TrilinosWrappers::BlockVector &dst,
  const TrilinosWrappers::BlockVector &src) const
{

   /* if(p_type==PreconditionerType::P1_UNSCALED_NORM_BASED)
       implement_unscaled_norm_based(dst, src);


    if(p_type==PreconditionerType::P2_PEARSON)
       implement_pearson_diagonal_preconditioner(dst, src);


    if(p_type==PreconditionerType::P3_MAYA){
        //implement_reduced_preconditioner(dst, src);
        implement_reduced_preconditioner_petia(dst, src);
}*/



}


//preconditioner P5=[M  -beta*K ]
//                   K        M ]   S_hat=



template <class PreconditionerA, class PreconditionerB>
void PoissonControlBlockPreconditioner<PreconditionerA, PreconditionerB >::implement_scaled_norm_based(TrilinosWrappers::BlockVector &dst,
                                       const TrilinosWrappers::BlockVector &src) const
{


    /*g1   = 0;
    g2   = 0;

    amg_2->vmult(g1,src.block(0));
    amg_2->vmult(g2,src.block(1));
    dst.block(0) =  g1;
    dst.block(1) =  g2;*/

}

template <class PreconditionerA, class PreconditionerB>
void PoissonControlBlockPreconditioner<PreconditionerA, PreconditionerB >::implement_unscaled_norm_based(TrilinosWrappers::BlockVector &dst,
                                       const TrilinosWrappers::BlockVector &src) const
{


    g1   = 0;
    g2   = 0;


    amg_1->vmult(g1,src.block(0));
    amg_2->vmult(g2,src.block(1));
    g2 *=EquationData::beta;

    dst.block(0) =  g1;
    dst.block(1) =  g2;

}


template <class PreconditionerA, class PreconditionerB>
void PoissonControlBlockPreconditioner<PreconditionerA, PreconditionerB >::implement_pearson_diagonal_preconditioner(TrilinosWrappers::BlockVector &dst,
                                       const TrilinosWrappers::BlockVector &src) const
{
    y = 0;
    p = 0;

    g1=0;
    g2=0;

    m_inv->vmult(y, src.block(0));
    amg_2->vmult(g1,src.block(1));
    preconditioner_matrix->block(0,0).vmult (g2, g1);
    amg_2->vmult(p, g2);

    dst.block(0) = y;
    dst.block(1) = p;

}

template <class PreconditionerA, class PreconditionerB>
void PoissonControlBlockPreconditioner<PreconditionerA, PreconditionerB >::implement_reduced_preconditioner_petia(
                                                                                TrilinosWrappers::BlockVector &dst,
                                                                                const TrilinosWrappers::BlockVector &src) const
 {

    double zeps=1.0/sqrt(EquationData::beta);
    tmp1 = src.block(0);
    tmp1 *= zeps;
    tmp2 = tmp1;
    tmp2 += src.block(1);
    amg_2->vmult (g1, tmp2);
    tmp2 = 0;

    preconditioner_matrix->block(0,0).vmult (tmp2, g1);
    tmp2 *= -1.0;
    tmp1 +=tmp2;
    amg_2->vmult(g2, tmp1);
    dst.block(1) = g2;
    dst.block(1) *= -1;
    g2 *=(1.0/zeps);
    g1 *=(1.0/zeps);
    dst.block(0) = g2;
    dst.block(0) += g1;

    /*TrilinosWrappers::Vector q_1(src.block(0).size());
    TrilinosWrappers::Vector w_1(src.block(0).size());
    TrilinosWrappers::Vector w_2(src.block(0).size());
    TrilinosWrappers::Vector g_v1(src.block(0).size());
    TrilinosWrappers::Vector g_v2(src.block(0).size());

    g_v1 = src.block(0);
    g_v2 = src.block(1);
    g_v1*= zeps;
    q_1   =g_v1;
    q_1 += g_v2;

    amg_2->vmult (y, q_1);

    //
    preconditioner_matrix->block(0,0).vmult (w_1, y);
    w_2  = g_v1;
    w_2 *= -1.0;
    w_2 += w_1;

    amg_2->vmult(p, w_2);

    dst.block(1) = p;

    dst.block(0) = p;
    dst.block(0) = -1.0;
    dst.block(0)+= y;

    dst.block(0) *= 1.0/zeps;*/




}
template <class PreconditionerA, class PreconditionerB>
void PoissonControlBlockPreconditioner<PreconditionerA, PreconditionerB >::implement_reduced_preconditioner(
                                                                                TrilinosWrappers::BlockVector &dst,
                                                                                const TrilinosWrappers::BlockVector &src) const
{
        y    = 0;
        tmp1 = 0;
        tmp2 = 0;
        g1   = 0;
        g2   = 0;
        b1   = 0;
        b2   = 0;

        double zeps=sqrt(EquationData::beta);


        //Step:1
        b1=0;

        b1 +=src.block(1);
        b1 *=zeps;
        b1 +=src.block(0);

        //Step:2

        amg_2->vmult (g1, b1);
        //m_inv->vmult (y, g1);
        //Step:3
        //conmution Ag
        preconditioner_matrix->block(0,0).vmult(tmp1, g1);
        tmp2=0;
        tmp2 +=src.block(0);
        tmp2 -=tmp1;
        //tmp2 *=-1;
        //b2  +=tmp1;
        //b2  +=tmp2;

        //Step:4
        amg_2->vmult (b2, tmp2);

        //Step:5
        y = 0;
        y+=g1;
        y+=b2;

        p =0;
        p+=b2;
        p *=-1/zeps;
        dst.block(0) = y;
        dst.block(1) = p;

        //dst.block(1) *= -1;


    }
