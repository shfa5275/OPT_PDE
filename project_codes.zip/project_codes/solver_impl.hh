#include <deal.II/base/function.h>

#include <deal.II/lac/solver_cg.h>
#include <deal.II/lac/solver_gmres.h>
#include <deal.II/lac/solver_minres.h>
#include <deal.II/lac/constraint_matrix.h>
#include <deal.II/lac/block_sparsity_pattern.h>
#include <deal.II/lac/trilinos_block_vector.h>
#include <deal.II/lac/trilinos_sparse_matrix.h>
#include <deal.II/lac/trilinos_block_sparse_matrix.h>



/*Vector and Matrix tools */
#include <deal.II/numerics/vector_tools.h>
#include <deal.II/numerics/matrix_tools.h>


#include <fstream>
#include <iostream>
#include <string>
#include <deal.II/numerics/data_out.h>
#include <deal.II/lac/lapack_full_matrix.h>


/*for iterative inverse*/
#include <deal.II/lac/iterative_inverse.h>

/* The timer class header */
#include <deal.II/base/timer.h>


#include <typeinfo>
class PreconditionerError{
public : string preconditioner_name;
         double beta_value;
         double n_refs;
         double solver_last_value;
         double target_tolerance;

};

enum SolverType{
    GMRES  =1,
    FGMRES =3,
    MINRES =2
};

namespace ToleranceLimits
{
  double inner_solver_amg = 1.0e-16;
  double inner_solver_chb = 1.0e-16;

  const double outer_solver   = 1.0e-10;
  const double h_block_solver = 1.0e-10;
}

namespace Iterations
{
  const unsigned int AMG=1;
  const unsigned int CHEBYCHEV=20;
  const unsigned int h_block=4;
  const unsigned int inner_solver_ric = 2;
  const unsigned int outer_solver     = 500;
}

using namespace dealii;
////////////////////////linear solver////////////////////////////////////
namespace LinearSolvers
{
     unsigned int cg_it=0;
     unsigned int cb_it=0;
     unsigned int amg_it=0;
     Timer cb_timer;
     Timer amg_timer;
     double cb_timer_in_sec=0;
     double amg_timer_in_sec=0;
     double beta_value;
     unsigned int n_refs;

     const std::string preconditioner_is_amg("AMG");
     const std::string preconditioner_is_cb("Chebyshev");
     std::vector<PreconditionerError> error_list;

    template <class Matrix, class Preconditioner>
    class InverseMatrix : public Subscriptor
    {
     public:

        InverseMatrix (const Matrix &m,
                       const Preconditioner &preconditioner,
                       const unsigned int  iterations,
                       const double absolute_tolerance_limit
                       );


        void vmult (TrilinosWrappers::Vector &dst,
                    const TrilinosWrappers::Vector &src) const;

        mutable unsigned int last_step;


      private:
        const SmartPointer<const Matrix> matrix;
        const Preconditioner  &preconditioner;
        const unsigned int  iterations;
        const double absolute_tolerance_limit;
    };

    template <class Matrix, class Preconditioner>
    InverseMatrix<Matrix, Preconditioner>::
    InverseMatrix (const Matrix &m,
                   const Preconditioner &_preconditioner,
                   const unsigned int  _iterations,
                   const double _absolute_tolerance_limit)
                    :
                    matrix (&m),
                    preconditioner  (_preconditioner),
                    iterations (_iterations),
                    absolute_tolerance_limit(_absolute_tolerance_limit)
    {}

    /*implementation of vmult*/
    template <class Matrix, class Preconditioner>
    void
    InverseMatrix<Matrix, Preconditioner>::
    vmult (TrilinosWrappers::Vector &dst,
           const TrilinosWrappers::Vector &src) const
    {

        string s = typeid(preconditioner).name();
        std::size_t is_amg= s.find(preconditioner_is_amg);
        std::size_t is_cb = s.find(preconditioner_is_cb);

        double relative_tolerance=absolute_tolerance_limit*src.l2_norm();

        SolverControl solver_control(iterations,
                                     relative_tolerance,
                                     false,
                                     false);

       //SolverGMRES<TrilinosWrappers::Vector> gmres (solver_control);
       SolverCG<TrilinosWrappers::Vector> cg (solver_control);

       dst.reinit(src);
       dst=0;


       try{
           // gmres.solve (*matrix, dst, src, preconditioner);

           cg.solve (*matrix, dst, src, preconditioner);

           //cout<<"are we here as well "<<s<<endl;
           /*if(is_amg!=string::npos){

           gmres.solve (*matrix, dst, src, preconditioner);
           //cout<<"amg iteration... "<<iterations<<" "<<s<<" "<<relative_tolerance<<" "<<solver_control.last_value()<<endl;
           }
           else if(is_cb!=string::npos){
           cg.solve (*matrix, dst, src, preconditioner);

           }*/

       }catch (std::exception &e){
           //cout<<"breaking in inner preconditioner... "<<s<<" "<<solver_control.last_value()<<endl;
           //cout<<"breaking in inner preconditioner... "<<s<<" "<<e.what()<<endl;
           PreconditionerError er;
           er.preconditioner_name=s;
           er.n_refs=n_refs;
           er.beta_value  =beta_value;
           er.solver_last_value=solver_control.last_value();
           er.target_tolerance =relative_tolerance;
           error_list.push_back(er);
           //cout<<"breaking the preconditioner"<<endl;
           //Assert(false, ExcMessage(e.what()));

       }       
       if(is_amg!=string::npos){
       amg_it = amg_it + solver_control.last_step();
      // cout<<"amg iteration... "<<" "<<" "<<solver_control.last_step()<<" "<<solver_control.last_value()<<endl;
       }
       if(is_cb!=string::npos){
       cb_it = cb_it + solver_control.last_step();
       //cout<<"cb iteration... "<<" "<<" "<<solver_control.last_step()<<" "<<solver_control.last_value()<<endl;
       }
       cg_it = cg_it + solver_control.last_step();
    }
  }
